# LangChain\&LangGraph面试题

## 1\.1\. **LangChain解决什么问题？**

LangChain诞生的核心驱动力，在于原生大语言模型（LLM）在实际应用中存在三个根本性的局限：

1. **信息孤岛问题**

LLM的知识受限于其训练数据的截止时间，无法获取训练时点之后的信息，也无法访问企业的私有数据（如内部文档、数据库、邮件等）。这意味着仅靠模型本身，无法回答需要实时数据或内部知识的问题。

2. **行动能力缺失问题**

LLM本质上是一个文本生成器，只能“说”而不能“做”。它无法主动查询数据库、调用API、发送邮件或执行代码，这些将模型能力转化为实际业务动作的关键步骤，原生模型都不支持。

3. **上下文断裂问题**

原生LLM调用是无状态的，每次对话都是独立的。要实现多轮连贯对话、记住用户偏好、在长对话中保持上下文，开发者需要自己管理状态和记忆，而这在实际业务中非常复杂。

正是在这种背景下，LangChain于2022年10月诞生，LangChain通过一套模块化、可组合的架构，将上述复杂问题标准化，让开发者能像“搭积木”一样快速构建LLM应用。一句话总结：**LangChain解决的核心问题是如何将大语言模型从“只会聊天的文本生成器”，变成能够连接外部世界、具备行动能力、拥有记忆的智能应用系统。**

LangChain特点：

4. **统一的模型接口**

各大模型提供商（OpenAI、Anthropic、Google、DeepSeek等）都有各自不同的API接口、参数规范和响应格式。LangChain通过统一的API抽象层，使开发者可以无缝切换不同模型而无需重写大量代码，加速了实验和创新周期。

5. **标准化的工具调用**

LangChain提供了@tool装饰器和标准化的工具接口，让开发者可以将任意Python函数封装为LLM可调用的工具。通过bind\_tools\(\)方法将工具绑定到模型上，LLM就能在需要时自动生成工具调用请求。Agent基于ReAct（Reasoning \+ Acting）范式，在“思考→调用工具→观察结果→再思考”的循环中自主解决问题。

6. **模块化与可组合性**

LangChain采用高度模块化的架构，将复杂的大模型应用分解为可复用的构建块：模型（Models）、提示模板（Prompts）、记忆（Memory）、链（Chains）、智能体（Agents）和工具（Tools）。

7. **记忆管理机制**

LangChain通过检查点（Checkpointer）机制实现短期记忆（线程级状态持久化），通过存储（Store）机制实现长期记忆（跨会话的用户偏好和知识积累）。这使得Agent能够参考之前的对话内容，提供连贯和个性化的体验。

## 1\.2\. **LangChain\&LangGraph定位区别？**

8. **先介绍两者是什么**

LangChain 和 LangGraph 不是两个互相替代的框架，而是处在不同抽象层级。

LangChain是**面向Agent和大模型应用开发的高层框架**，提供统一的模型接口、Prompt、Retriever、Tool、结构化输出、Middleware和Agent等能力，适合快速构建RAG、聊天机器人、结构化信息处理和标准工具调用Agent。

LangGraph是面向长时间运行、**有状态Agent的低层编排框架和运行时**。以GraphAPI为例，它通过State、Node和Edge显式描述执行过程，支持条件分支、循环、并行、状态持久化、断点恢复和Human\-in\-the\-loop等复杂场景。

9. **再回答两者核心区别**

两者核心区别：

两者分层关系：

![YCu9vzfJ\.jpg](图片和附件/YCu9vzfJ.jpg)

10. **最后谈两者关系互补**

二者的关系是互补的。当前 LangChain 的 create\_agent 是高层 Agent 入口，底层基于 LangGraph 构建。因此，简单场景可以优先使用 LangChain；当需要对 Agent 的执行流程和状态进行精细控制时，可以直接使用 LangGraph。**实际生产项目中，通常是用 LangChain 提供模型和工具能力，用 LangGraph 编排整个业务流程。**

实际工作场景中，两者经常组合使用:LangChain 提供模型、工具、Retriever 和高层 Agent 能力，LangGraph 负责复杂工作流的状态管理与执行编排。

## 1\.3\. **聊天模型初始化方式？**

LangChain中初始化聊天模型主要有两种方式。**第一种是直接使用Provider专用的ModelClass**，例如ChatOpenAI、ChatAnthropic、ChatDeepSeek和ChatOllama。这种方式比较直观，适合固定使用某个Provider，或者需要配置Provider专有参数和能力的场景。

**第二种是使用LangChain1\.x提供的统一工厂函数init\_chat\_model**，通过model="provider:model\-name"，或者通过model和model\_provider分别指定模型和供应商。它适合配置驱动、多模型切换和模型路由场景。

```Plain Text
#使用 Model Class 创建聊天模型# 创建DeepSeek LLMdeepseek_llm = ChatDeepSeek(api_key=DEEPSEEK_API_KEY,api_base=DEEPSEEK_BASE_URL,model="deepseek-v4-flahs",)
#使用init_chat_model创建聊天模型deepseek_llm: BaseChatModel = init_chat_model(model="deepseek-chat",model_provider="deepseek",api_key=DEEPSEEK_API_KEY,base_url=DEEPSEEK_BASE_URL,)
```

在实际团队项目中，更推荐使用init\_chat\_model作为默认初始化入口，因为它可以降低业务代码与具体Provider类之间的耦合，也便于统一管理APIKey、BaseURL、模型名称和运行参数。此外，使用ModelClass创建的模型在Agent中可能出现结果结构错误，这样还需要针对这种情况特别处理，比较麻烦，**所以建议使用init\_chat\_model来作为统一聊天模型的入口**。

## 1\.4\. **批量调用模型时，如何保证返回消息的顺序？**

batch\(\)/abatch\(\): 等待所有请求处理完毕，按原始输入顺序返回结果列表，通常保留输入顺序。

batch\_as\_completed\(\)/abatch\_as\_completed\(\)：允许应用在收到第一个结果后立即开始后续处理，而不必等待最慢的那个请求，也就是说batch\_as\_completed\(\) 每个请求完成后立即 yield 结果，结果可能乱序，但包含索引信息。

所以**为了保证批量调用模型返回消息的顺序可以使用batch\(\)/abatch\(\)**，**如果输入列表很大或单个模型调用耗时差异显著时，可以使用batch\_as\_completed\(\)/abatch\_as\_completed\(\)**，这种方式中哪个请求先完成，就先处理哪个结果，但需要根据索引归位。

在使用batch\_as\_completed\(\)/abatch\_as\_completed\(\)中更建议使用业务request\_id做最终关联（非必须），即每个请求都对应一个业务ID，根据索引归位后，将模型回复结果中也保留这个业务request\_id。

```Plain Text
from init_llm import deepseek_llm_flash


def main() -> None:"""使用 DeepSeek v4 Flash 演示批量调用结果的顺序恢复。"""# 每个业务请求都绑定唯一 request_id
    requests = [
        {
            "request_id": "req-001",
            "question": "20个字解释为什么鹦鹉的羽毛是彩色的？",
        },
        {
            "request_id": "req-002",
            "question": "20个字解释飞机是如何飞行的？",
        },
        {
            "request_id": "req-003",
            "question": "20个字解释什么是量子计算？"
        },
    ]

    # 模型的输入列表
    model_inputs = [request["question"] for request in requests]

    # 记录实际完成顺序
    completed_order: list[str] = []

    # 按输入长度预先创建结果槽位
    ordered_results = [None] * len(model_inputs)

    # batch_as_completed 按任务完成顺序返回# index 是该结果在原始输入列表中的索引for index, result in deepseek_llm_flash.batch_as_completed(
        model_inputs,
        config={
            "max_concurrency": 3,
        }
    ):

        # 根据 index 找到request_id ，对应起来
        request_id = requests[index]["request_id"]

        # 记录实际完成顺序
        completed_order.append(request_id)

        # 按输入索引归位，不能直接 append
        ordered_results[index] = result

    print("\n实际完成顺序：")
    print(completed_order)

    print("\n按照原始输入顺序输出：")
    for request, result in zip(requests,ordered_results,):
        request_id = request["request_id"]
        print(f"[{request_id}] {result.content}")


if __name__ == "__main__":
    main()
```

以上运行结果如下：

![ZuyP99k4\.jpg](图片和附件/ZuyP99k4.jpg)

## 1\.5\. **模型结构化输出方式**

结构化输出是指让模型返回符合预定义 Schema 的结果，而不是任意自然语言。在 LangChain 中，可以使用如下三种方式定义输出结构的Schema：Pydantic 模型、TypedDict、JSON Schema，调用大模型时，三种方式都可通过“with\_structured\_output”方法来返回结构化结果。

11. **Pydantic 模型（推荐）**

**Pydantic 模型是使用 Python 的 Pydantic 库定义强类型数据模型,支持复杂嵌套结构。适合需要严格数据验证和复杂结构的场景，如生成 API 响应。**

Pydanitc是一个基于 Python 类型注解的库，它通过在运行时强制执行类型提示，确保数据的正确性和一致性，定义这种类型时需要创建一个继承自BaseModel的类，使用类型提示（如 str, int）和 Field函数来声明每个字段的名称、类型、默认值和描述。

示例：

```Plain Text
"""
使用 Pydantic 定义嵌套结构
"""from pydantic import BaseModel, Field
from typing import List# 1. 定义嵌套的 Pydantic 模型class Actor(BaseModel):
    name: str = Field(description="演员姓名")
    role: str = Field(description="饰演的角色")

class Movie(BaseModel):
    title: str = Field(description="电影标题")
    year: int = Field(description="上映年份")
    director: str = Field(description="导演")
    cast: List[Actor] = Field(description="演员列表")  # 定义列表字段
    rating: float = Field(description="评分")

# 2. 初始化模型并绑定输出结构
structured_model = deepseek_llm.with_structured_output(Movie)

# 3. 调用模型，直接获取 Movie 实例
response = structured_model.invoke("请介绍电影《盗梦空间》")

# 4. 访问嵌套数据print(f"电影名: {response.title}")
print(f"上映年份: {response.year}")
print(f"导演: {response.director}")
print(f"演员列表: {response.cast}")
print(f"评分: {response.rating}")
```

12. **TypedDict**

TypedDict 是 Python 3\.8\+ 引入的一种类型提示工具，它允许为字典对象定义固定的键名和对应的值类型。TypedDict是使用 Python 的 TypedDict来定义带有类型提示的字典结构，无需额外依赖，适合需要快速定义字典结构且无需 Pydantic 重量级功能的场景。

示例：

```Plain Text
from typing import TypedDict, List, Annotated

from init_llm import deepseek_llm

# 使用TypedDict定义嵌套结构class Actor(TypedDict):
    name: Annotated[str, "演员姓名"]
    role: Annotated[str, "饰演的角色"]

class Movie(TypedDict):
    title: Annotated[str, "电影标题"]
    year: Annotated[int, "上映年份"]
    director: Annotated[str, "导演"]
    cast: Annotated[List[Actor], "演员列表"]  # 嵌套列表定义
    rating: Annotated[float, "评分"]

# 设置模型结构化输出
model_with_structure  = deepseek_llm.with_structured_output(Movie)

# 调用模型并获取结构化输出
resp:Movie = model_with_structure.invoke("给我介绍下电影《盗梦空间》")

# 访问嵌套数据print(f"电影名: {resp['title']}")
print(f"上映年份: {resp['year']}")
print(f"导演: {resp['director']}")
print(f"演员列表:{resp['cast']}")
print(f"评分: {resp['rating']}")
```

13. **JSON Schema**

JSON Schema是提供一个标准的 JSON Schema 字典来定义结构。适合需要与多种编程语言交互或进行复杂数据约束定义的场景。

```Plain Text
"""
使用 JSON Schema 定义嵌套结构
"""# 1. 定义嵌套的 JSON Schema
project_schema = {
    "title": "MovieInfo",
    "description": "包含电影标题、上映年份、导演、演员和评分的电影对象",
    "type": "object",
    "properties": {
        "title": {"type": "string", "description": "电影标题"},
        "year": {"type": "integer", "description": "上映年份"},
        "director": {"type": "string", "description": "导演"},
        "cast": {  # 定义嵌套数组"type": "array",
            "description": "演员列表",
            "items": {
                "type": "object",
                "properties": {
                    "name": {"type": "string", "description": "演员姓名"},
                    "role": {"type": "string", "description": "演员角色"}
                },
                "required": ["name", "role"]
            }
        },
        "rating": {"type": "number", "description": "评分（10分制）"}
    },
    "required": ["title", "year", "director", "cast", "rating"]
}

# 绑定 JSON Schema 到模型
structured_model = deepseek_llm.with_structured_output(project_schema)

# 调用模型
response = structured_model.invoke("生成一个关于《星际穿越》的电影信息，包含导演、演员、评分")
print(response)
```

三种Schema定义方式对比：

特别注意：对于Agent结构化输出，当前LangChain可以通过response\_format配置结构化输出；直接传入Schema时，LangChain会根据模型能力尝试选择ProviderStrategy或ToolStrategy。

## 1\.6\. **LangChain中Tool和普通函数区别？**

**当前LangChain支持将普通Python函数直接传给model\.bind\_tools\(\)，也支持直接放入create\_agent\(tools=\[\.\.\.\]\)，不要求必须使用@tool**。框架会根据函数名、类型注解、默认值和docstring自动推断工具名称、描述和参数Schema。

如果使用bind\_tools\(\)，它只是把工具定义绑定给模型，模型返回tool\_calls后，需要开发者自己执行对应函数并把结果返回给模型；如果使用create\_agent\(\)，Agent会自动完成模型判断、工具执行、ToolMessage回传和最终回复。

```Plain Text
# 1. 普通 Python 函数def query_order(order_id: str) -> str:
...

model.bind_tools([query_order])


# 2. 使用 @tool 装饰器@tooldef query_order(order_id: str) -> str:"xxx"
...

agent = create_agent(
    model=model,
    tools=[query_order],
)
```

@tool的作用不是让普通函数获得“能被调用”的唯一资格，而是把普通函数显式转换成LangChainTool，方便自定义工具名称、描述、参数Schema、返回格式以及Runtime运行时能力，例如：可以配合ToolRuntime访问Agent的State、Context和Store。

需要注意，无论是将普通函数还是加了@tool的函数作为工具，必须提供清晰的类型注解和docstring，否则LangChain无法准确生成工具Schema，模型也可能不知道何时调用工具以及如何填写参数。

## 1\.7\. **请解释 Agent 核心执行流程中的 ReAct 框架**

**ReAct 是 Reasoning and Acting 的缩写，即推理与行动。它的核心是让 Agent 在解决问题时，不是一次性生成最终答案，而是交替进行任务分析、工具调用和结果观察**。模型首先根据用户问题判断是否需要调用工具，如果需要，就生成工具名称和参数；Agent 执行工具后，将结果以 ToolMessage 的形式返回给模型，模型再结合工具结果决定下一步行动，直到不再产生工具调用，最后生成最终答案。

在当前 LangChain 中，create\_agent\(\) 已经封装了这个模型—工具循环：模型返回 tool\_calls 时进入工具节点，工具执行结束后再次调用模型；当模型不再返回 tool\_calls 时，Agent 输出最终结果。LangGraph 则可以将这个过程显式建模为 model 节点、tool 节点和条件边，从而进一步控制状态、分支、循环、人工审批和持久化。

![nsEraPve\.jpg](图片和附件/nsEraPve.jpg)

## 1\.8\. **LLM、LLM\+工具调用、Agent 的对比**

如下对比LLM、LLM工具调用和Agent工具调用三者的区别：

## 1\.9\. **Workflow 与 Agent 的区别**

**Workflow和Agent的主要区别在于执行路径由谁决定**。Workflow的流程路径和节点顺序主要由开发者通过代码预先定义，适合订单处理、审批、ETL等规则明确、确定性较强的业务。Agent则以大模型为决策核心，由模型根据用户目标、当前状态和工具返回结果动态选择工具、决定调用顺序，并循环执行直到任务完成，适合智能客服、研究分析和开放式任务。

![xvQnPRQN\.jpg](图片和附件/xvQnPRQN.jpg)

Workflow的优点是可预测、可审计、容易控制；Agent的优点是灵活，能够处理事先无法完全确定步骤的任务，但需要通过工具白名单、最大迭代次数、超时、重试和人工审批控制风险。

**实际生产项目通常不是二选一，而是外层使用Workflow控制业务边界，在其中某个步骤嵌入Agent处理开放式决策。LangGraph同时适合编排确定性Workflow和Agent流程。**

## 1\.10\. **Agent如何实现动态模型和动态提示词设置？**

**LangChainAgent可以通过Middleware实现动态模型和动态提示词。**

动态模型使用@wrap\_model\_call，在每次模型调用前，根据用户等级、问题复杂度、延迟要求或成本预算选择不同模型，并通过request\.override\(model=selected\_model\)将模型传递给后续处理链。

动态提示词使用@dynamic\_prompt，根据运行时上下文生成不同的系统提示词。创建Agent时通过context\_schema定义上下文结构，调用agent\.invoke时通过context传入用户等级、问题类型等数据，中间件通过request\.runtime\.context读取。

例如，普通用户的简单问题使用快速模型和简洁提示词，VIP用户或复杂问题使用高质量模型和更详细的提示词。这样不需要每次重新创建Agent，只需要在运行时动态修改模型和提示词即可。

## 1\.11\. **如何处理Agent工具参数校验和运行异常？**

**一、利用 Pydantic 模型进行“调用前校验”**

在 LangChain 中，最优雅、最强大的方式是使用 Pydantic 模型（BaseModel） 作为工具的 args\_schema。

- 基础校验（类型与枚举）:利用 Field 和 Literal，我可以精确限定参数类型和取值范围。例如，工单状态必须严格限定为 "open"、"closed"。

- 业务逻辑校验（自定义清洗）:利用 @field\_validator 做“防呆设计”。例如，大模型传进来的 ticket\_id 经常是小写（tk001），而数据库存的是大写（TK001）。在校验器里强制转为大写（return v\.upper\(\)），这提前消除了大小写不一致带来的查询空结果，让 Agent 少走一次弯路。

**代码示例：使用Pydantic模型定义工具示例\(查询工单Agent\)：**

```Plain Text
from langchain.agents import create_agent
from pydantic import BaseModel, Field, field_validator
from typing import Literal, Optionalfrom langchain_core.tools import tool
import json
from init_llm import deepseek_llm


# 1.定义复杂的工单查询参数模型class TicketQueryInput(BaseModel):"""工单查询输入参数 - 支持多种筛选条件"""
    ticket_id: Optional[str] = Field(
        default=None,
        description="工单ID"
    )
    assigner: Optional[str] = Field(
        default=None,
        description="负责人姓名"
    )
    status: Optional[Literal["open", "in_progress", "resolved", "closed"]] = Field(
        default=None,
        description="工单状态: open(待处理), in_progress(处理中), resolved(已解决), closed(已关闭)"
    )
    priority: Optional[Literal["low", "medium", "high", "urgent"]] = Field(
        default=None,
        description="优先级: low(低), medium(中), high(高), urgent(紧急)"
    )

    @field_validator("ticket_id")def convert_ticket_id_to_upper(cls, v: Optional[str]) -> Optional[str]:"""将工单ID转换为大写"""return v.upper() if v else None# 2. 使用@tool装饰器定义工具，并通过args_schema指定参数模型@tool(args_schema=TicketQueryInput)def query_tickets(
        ticket_id: Optional[str] = None,
        assigner: Optional[str] = None,
        status: Optional[str] = None,
        priority: Optional[str] = None,
) -> str:"""
    查询工单系统，支持多条件筛选。

    此工具用于从工单管理系统中检索符合特定条件的工单信息。
    至少需要提供一个筛选条件，否则返回最近创建的工单。
    """try:
        # 模拟一个简单的工单数据库
        mock_tickets_db = [
            {"ticket_id": "TK2025012001", "assigner": "张三", "title": "登录页面加载缓慢", "status": "open", "priority": "low"},
            {"ticket_id": "TK2025012002", "assigner": "李四", "title": "用户头像上传失败", "status": "open", "priority": "medium"},
            {"ticket_id": "TK2025011901", "assigner": "张三", "title": "支付成功通知未发送", "status": "resolved", "priority": "high"},
            {"ticket_id": "TK2025011902", "assigner": "马六", "title": "订单查询接口返回空值", "status": "closed", "priority": "high"},
        ]

        filtered_tickets = mock_tickets_db

        if ticket_id:
            filtered_tickets = [t for t in filtered_tickets if t["ticket_id"] == ticket_id]

        if assigner:
            filtered_tickets = [t for t in filtered_tickets if t["assigner"] == assigner]

        if status:
            filtered_tickets = [t for t in filtered_tickets if t["status"] == status]

        if priority:
            filtered_tickets = [t for t in filtered_tickets if t["priority"] == priority]

        if not filtered_tickets:
            return "未找到符合条件的工单"# 格式化返回结果
        result = {
            "total_count": len(filtered_tickets),
            "tickets": filtered_tickets
        }

        return json.dumps(result, ensure_ascii=False, indent=2)

    except Exception as e:
        return f"查询工单时发生错误: {str(e)}"# 3.创建智能体
agent = create_agent(
    model=deepseek_llm,
    tools=[query_tickets],
    system_prompt="你是一个助手，你可以查询工单系统的工单信息。",
)

# 4. 测试智能体# 4.1 测试基本功能# response1 = agent.invoke({"messages": [{"role": "user", "content": "请帮我查一下TK2025012001工单的详细信息"}]})# print("response1 content", response1["messages"][-1].content)## response2 = agent.invoke({"messages": [{"role": "user", "content": "请帮我查一下张三负责的工单"}]})# print("response2 content", response2["messages"][-1].content)## response3 = agent.invoke({"messages": [{"role": "user", "content": "请帮我查一下所有高优先级的工单"}]})# print("response3 content", response3["messages"][-1].content)## response4 = agent.invoke({"messages": [{"role": "user", "content": "请帮我查一下所有关闭工单"}]})# print("response4 content", response4["messages"][-1].content)# 4.2 测试 Pydantic 参数验证
response5 = agent.invoke({"messages": [{"role": "user", "content": "请帮我查一下tk2025012001工单的详细信息"}]})
print(response5)
print("response5 content", response5["messages"][-1].content)
```

以上代码注意如下问题：

1. 这种方式定义工具，通过 @tool\(args\_schema=PydanticModelCls\)将这个 Pydantic 模型与工具函数关联。

2. PydanticModelCls 需要继承自 BaseModel的类，使用类型提示（如 str, int）和 Field函数来声明每个字段的名称、类型、默认值和描述。每个字段的 description参数至关重要，它直接影响大模型理解参数含义的能力。

3. 可以利用 Pydantic 的类型系统进行参数验证，当大模型需要调用工具前，Pydantic 会自动验证参数的类型和有效性。

4. 在 convert\_ticket\_id\_to\_upper方法中的 cls，代表的是 这个 Pydantic 模型类本身，在这里也就是 TicketQueryInput这个类。@field\_validator装饰器将对应方法标记为类方法，类方法的第一个参数约定俗成地命名为 cls，它指向类而不是类的实例。这样，在验证逻辑中如果需要访问类的其他属性或方法，就可以通过 cls来操作。

5. json\.dumps\(\)是 Python 标准库 json模块中的函数，用于将 Python 对象（如字典、列表）序列化成一个 JSON 格式的字符串。

\(1\) ensure\_ascii=False: 这个参数默认值为 True，表示所有非 ASCII 字符（如中文）会被转换成 \\uXXXX形式的转义序列。设置为 False后，中文、表情符号等字符就能在 JSON 字符串中正常显示，而不是一堆乱码。

\(2\) indent=2: 这个参数用于美化输出，使生成的 JSON 字符串具有可读性。数字 2表示使用两个空格作为缩进层级，让结构清晰可见。如果不需要格式化，可设为 None。

**二、利用 @wrap\_tool\_call 中间件处理“运行时异常”**

参数校验分两种，一种是格式校验（Pydantic 搞定），另一种是业务/系统校验（如“数据库连接超时”、“工单ID不存在”）。对于后者，可以使用 @wrap\_tool\_call 中间件进行分级兜底：

- 捕获并转化：工具内主动 raise ToolException\("工单ID不存在"\)，中间件捕获后转化为用户友好的 ToolMessage。

- 重试 vs 终止：对于 ConnectionError（瞬时故障），我会在中间件里结合 retry 逻辑，让模型“稍后重试”；对于 PermissionError（权限不足），直接返回“请联系管理员”，严禁无意义地反复重试导致死循环。

当Agent调用工具异常时，我们可以使用@wrap\_tool\_call中间件来灵活处理调用工具发生的异常错误，如下：

```Plain Text
from langchain.agents import create_agent
from langchain.agents.middleware import wrap_tool_call
from langchain.messages import ToolMessage


@wrap_tool_calldef handle_tool_errors(request, handler):"""使用自定义消息处理工具执行错误"""try:
        return handler(request)
    except Exception as e:
        # 向模型返回自定义错误消息return ToolMessage(
            content=f"调用工具错误:请检查输入参数并重试. ({str(e)})",
            tool_call_id=request.tool_call["id"]
        )

agent = create_agent(
    model="gpt-4o",
    tools=[search, get_weather],
    middleware=[handle_tool_errors]
)
```

## 1\.12\. **Agent response\_format 支持哪些Schema？**

**LangChain Agent 的 response\_format 支持四种基础 Schema：Pydantic、Dataclass、TypedDict 和 JSON Schema**。结构化输出结果保存在 Agent 状态的 structured\_response 字段中。

Pydantic 支持严格的运行时校验和自定义校验，适合 Python 后端业务，通常是首选；Dataclass 比较轻量，适合内部数据对象；TypedDict 适合需要普通字典结果的轻量场景；JSON Schema 适合已有标准 Schema 或跨语言接口的场景。

Agent 结构化输出有 ProviderStrategy 和 ToolStrategy 两种主要策略。ProviderStrategy 使用模型提供商的原生结构化输出能力，ToolStrategy 通过工具调用生成结构化结果。对于企业中的项目，建议显式使用 ToolStrategy\(Schema\)。

## 1\.13\. **Agent支持的流式输出模式及对比**

Agent默认输出模式是“模型思考\-工具调用”ReAct循环调用，最终输出大模型结果，除了这种输出模式外，Agent还支持如下输出模式：**values、updates（默认）、messages、custom、checkpoints、tasks、debug**，这些模式都是通过“Agent\.stream\(\.\.\.,stream\_mode=指定模式，默认为None,\.\.\.\)”来指定。

LangChain Agent输出模式对比：

我们可以根据不同的目标来选择不同的输出模式，例如：实现实时对话交互，优先选择message模式；观察Agent的思考与执行步骤，优先选择update模式；需要查看每一步状态优先选择values/tasks/debug模式；在工具执行时输出自定义业务日志优先选择custom模式。

此外，以上这些模式还可以组合使用，例如，可以同时指定stream\_mode=\[“tasks”，“updates”\],这样在同一个循环里既能查看Agent task任务执行内容，又能显示Agent每步的更新。

## 1\.14\. **LangChain 短期记忆和长期记忆区别**

短期记忆和长期记忆的核心区别是作用范围不同。

**短期记忆是线程级记忆，主要保存当前会话的消息、工具结果和任务状态**，在 LangChain Agent 中通过 State 管理，并使用 Checkpointer 按 thread\_id 保存和恢复。相同的 thread\_id 可以继续之前的对话，不同的 thread\_id 则是新的会话。

**长期记忆是用户级、租户级或应用级记忆，例如用户偏好、用户画像和历史业务事实**。在 LangGraph 中通常使用 Store 保存，通过 user\_id、order\_id 等业务标识建立 namespace，可以跨不同 thread\_id 读取。长期记忆不会自动进入模型上下文，通常需要通过工具、节点或 Middleware 显式读取。

![ZpNE3lmW\.jpg](图片和附件/ZpNE3lmW.jpg)

**实际项目中，使用 Checkpointer 保存当前会话状态，使用 Store 保存需要跨会话复用的用户信息**。测试环境可以使用 InMemorySaver 和 InMemoryStore，生产环境需要替换为持久化后端，并增加记忆的权限、过期、删除和隐私控制。

短期记忆和长期记忆区别：

## 1\.15\. **state和context区别**

LangChain Agent中进行调用时可以传入初始state或者context（上下文），如下：

```Plain Text
... ...
config = {"configurable": {"thread_id": "1"}}
agent.invoke(
    {
        "messages": [{"role": "user", "content": "你的问题"}],
        "state_key1": "state_value1",
        "state_key2": "state_value2",
    },
    config=config,
    context={
        "context_key1": "context_value1",
        "context_key2": "context_value2",
    }
)
... ...
```

以上传递的state内容和context内容都可以在Agent中工具或者中间件中进行获取使用，那么两者有什么区别？

- state:state用于管理Agent的短期记忆，决定了一个会话线程（thread）中，Agent可以记住哪些自定义的业务数据，其值可以在单次会话的生命周期内，通过工具（Tools）或中间件（如 @before\_model, @after\_model）进行读取和更新。

- context:context用于定义传递Agent的静态或半静态的上下文信息，这些信息更像对话发生的“背景板”或“环境变量”，在会话开始时设定，在会话过程中通常保持不变。

两者核心区别总结如下：

## 1\.16\. **Agent如何实现自定义摘要？**

Custom Strategies 自定义策略可以针对特定业务需求来解决对话超出LLM上下文长度问题，该方式可以解决标准方案（如消息截断、删除、摘要）无法覆盖的复杂场景（如一些场景中对话历史中包含文本、图片、文件多种信息时，需要根据需要动态保留哪些内容）。

**Custom Strategies 自定义策略可以通过中间件@before\_model/@after\_model/@wrap\_model\_call 来实现，三种中间件都可以对对话历史消息messages进行处理修改，从而达到自定义保留消息效果。**

如下案例中，通过@after\_model中间件实现自定义摘要策略，保留最近2条消息，并对最近2条消息之前的所有消息进行摘要，摘要时使用“通义千问”模型。特别注意的是保留的最近2条消息中需要保证完整工具链调用，避免工具调用链截断导致逻辑错误。

```Plain Text
from langchain.agents import create_agent, AgentState
from langchain.agents.middleware import after_model, before_model
from langchain_core.messages import RemoveMessage, ToolMessage
from langchain_core.tools import tool
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph.message import REMOVE_ALL_MESSAGES
from langgraph.runtime import Runtime
from langchain_core.messages import SystemMessage

from init_llm import deepseek_llm, tongyi_llm


@tooldef get_weather(city: str) -> str:"""
    获取指定城市的天气
    Args:
        city (str): 要查询天气的城市名称

    Returns:
        str: 包含城市天气信息的字符串
    """return f"{city}的天气是晴朗的，温度是25摄氏度"@before_modeldef print_before_model_state(state: AgentState, runtime: Runtime) -> dict | None:# 打印当前消息print("before_model_state：", state)

    messages = state["messages"]

    return {"messages": messages}


@after_modeldef custom_summarizer(state: AgentState, runtime) -> dict | None:"""自定义摘要逻辑，保留最近N条消息，并对N条消息前的所有消息进行摘要
        最后保留的最近N条消息中要保证包含完整调用工具链
    """# 打印当前消息print("after_model_state：", state)

    messages = state["messages"]
    # 触发摘要的阈值
    threshold = 5# 保留最近N条消息
    max_retain = 2# 如果 messages 条数达到触发摘要的阈值，那么就进行摘要处理，否则直接返回 Noneif len(messages) <= threshold:
        return None# 最近保留N条消息的集合
    recent_messages = messages[-max_retain:]

    # 遍历最近保留N条消息，判断第1条消息是否是 ToolMessage, 如果是那么多往前保留1条消息, 直到第1条消息不是 ToolMessage 为止while True:
        # 获取最近保留消息中的第1条消息，判断是不是ToolMessageif isinstance(recent_messages[0], ToolMessage):
            # 如果是那么多往前保留1条消息
            max_retain += 1
            recent_messages = messages[-max_retain:]
        else:
            # 如果第一条消息不是 ToolMessage 那么就跳出循环break

    early_messages = messages[:-max_retain]  # 保留最近N条消息前的所有消息# 准备摘要提示
    summary_prompt = f"""
        请将以下对话内容总结成一段简洁的摘要，保留重要信息和细节：
  
        对话历史：
        {"".join([f"{msg.type}: {msg.content}" for msg in early_messages])}
  
        摘要要求：
        1. 保留人物、地点、关键事件等重要信息
        2. 保持第三人称叙述
        3. 长度不超过200字
        4. 使用中文总结
  
        """try:
        # 调用模型生成摘要
        summary_response = tongyi_llm.invoke(summary_prompt)
        summary_content = f"对话摘要: {summary_response.content}"# 创建摘要消息
        summary_message = SystemMessage(content=summary_content)

        # 组合新消息列表：摘要 + 最近消息
        new_messages = [summary_message] + recent_messages

        return {
            "messages": [
                RemoveMessage(id=REMOVE_ALL_MESSAGES),
                *new_messages
            ]
        }

    except Exception as e:
        print(f"摘要生成失败: {e}")
        return None


agent = create_agent(
    model=deepseek_llm,
    tools=[get_weather],
    middleware=[print_before_model_state, custom_summarizer],
    checkpointer=InMemorySaver(),
)

config = {"configurable": {"thread_id": "session_001"}}

# 模拟对话
response1 = agent.invoke({"messages": [{"role": "user", "content": "你好，我是张三"}], }, config=config)
print(response1["messages"][-1].content)

print("***" * 20)
response2 = agent.invoke({"messages": [{"role": "user", "content": "今天北京天气好吗？"}]}, config=config)
print(response2["messages"][-1].content)

print("***" * 20)
response3 = agent.invoke({"messages": [{"role": "user", "content": "我的名字叫什么？"}]}, config=config)
print(response3["messages"][-1].content)
```

以上代码运行结果如下：

![mNhrriVM\.jpg](图片和附件/mNhrriVM.jpg)

以上代码注意点如下：

1. 在@after\_model中间件中，保留最近N条消息时，特别要注意保留完整的“AIMessage→ToolMessage\.\.\.→AIMessage”工具链调用，避免截断导致逻辑断裂。例如，将“ToolMessage→AIMessage”传递给大模型时，由于工具链逻辑断裂，会导致报错。

2. 对话摘要组织成SystemMessage传递给大模型使用，也可以组织成HumanMessage。

3. @after\_model中间件方法最终返回最终的messages消息中，REMOVE\_ALL\_MESSAGES表示清空整个对话历史，\*new\_messages展开为新的消息列表，即最终返回了“摘要消息\+保留的最近消息”。

## 1\.17\. **如何降低SummarizationMiddleware摘要细节丢失？**

**SummarizationMiddleware 摘要无法保证完全不丢失细节。降低细节丢失的正确方案不是要求摘要保存所有内容，而是对信息进行分层：最近消息保留原文、过程信息进入摘要、关键事实进入结构化状态、原始数据存外部系统。**

4. **最近消息保留原文**

摘要只处理旧消息，最近消息保留原文，建议按照token保留，而不是简单设置keep=\(“messages”,20\)。

```Plain Text
SummarizationMiddleware(
    model=summary_model,
    trigger=("tokens", 12000), # 达到 12000Token时触发摘要
    keep=("tokens", 4000), #保留最近4000 Token的原文
)
```

5. **过程消息进入摘要**

默认摘要可能把对话压缩成一段自然语言，容易丢失关键信息，可以自定义 summary\_prompt，通过 summary\_prompt 明确规定必须保留的内容，并禁止模型推测。

```Plain Text
BUSINESS_SUMMARY_PROMPT = """
你是客服对话记忆压缩器。

只能根据原始消息进行总结，禁止补充、推测或修改事实。

必须按照以下结构输出：

## 用户目标
记录用户当前要解决的问题。

## 关键实体
保留订单号、用户ID、商品ID、文件ID等精确值。

## 精确数据
保留金额、数量、日期、时间、状态和错误码，不得改写。

## 已确认内容
记录用户明确确认的条件和方案。

## 已否决内容
记录用户拒绝或取消的方案，避免后续重复推荐。

## 已执行操作
记录已经调用的工具、操作结果和是否成功。

## 待办事项
记录尚未完成的任务和下一步操作。

## 资料引用
保留文件ID、页码、段落ID、工具结果ID等引用信息。

如果同一个字段出现新旧值，使用最新值，
同时说明旧值发生过变更。

待摘要消息：

{messages}
"""
```

6. **关键事实进入结构化状态**

订单号、金额、审批状态和已执行操作等关键业务事实单独存入 Agent State，用户偏好存入 Store，大文件和工具结果存入外部存储，摘要只保存结论和引用 ID。

7. **原始数据存外部系统**

摘要是有损的，所以原始对话不能因为摘要完成就永久删除。可以保存到日志系统或者外部数据库，需要排查问题或重新生成摘要时，再从原始归档读取。

![d5nQ4flv\.jpg](图片和附件/d5nQ4flv.jpg)

总体回答如下：

SummarizationMiddleware本质上是有损压缩，不能保证完全不丢失细节。因此不要把摘要作为唯一事实来源，而是采用分层记忆。

第一，通过 keep=\("tokens", N\) 保留最近消息原文，避免当前任务信息被摘要。

第二，通过自定义 summary\_prompt，要求摘要按照用户目标、关键实体、精确数据、已确认内容、已否决内容、已执行操作和待办事项等固定结构生成，并禁止模型推测。

第三，订单号、金额、审批状态和已执行操作等关键业务事实单独存入 Agent State，用户偏好存入 Store，大文件和工具结果存入外部存储，摘要只保存结论和引用 ID。

第四，原始对话需要独立归档，便于审计和重新生成摘要。

还需要避免 trim\_tokens\_to\_summarize（生成摘要时，摘要中允许的最大 token 数，超出部分会被截断，默认4000。） 设置过小，并且摘要模型不能过弱。对于长会话，要注意反复摘要会产生累计信息损失，因此应该定期根据原始会话重建摘要。核心原则是：摘要负责压缩语义，State 保存准确事实，Store 保存长期信息，外部系统保存原始数据。

## 1\.18\. **HITL执行恢复流程**

HITL 中间件的完整执行生命周期可以分为五个阶段：

1. 模型调用：Agent调用LLM生成响应，模型返回的内容可能包含工具调用。

2. HumanInTheLoopMiddleware中间件拦截：该中间件中在after\_model钩子中检查模型响应，如果存在需要审批的工具调用，则构建一个HITLRequest对象，其中包含操作列表（action\_requests）和审批配置（review\_configs）。

3. 发出中断：调用interrupt\(\)函数，Agent 执行暂停，当前图状态通过检查点持久化保存。

4. 等待决策：Agent 进入等待状态，直到外部通过Command\(resume=\.\.\.\)传入人工决策。

5. 恢复执行：收到HITLResponse后，中间件根据决策类型执行不同操作：

> - approve：原样执行工具调用。
> 
> - edit：使用修改后的参数执行工具调用。
> 
> - reject：不执行工具，合成一个带有反馈消息的ToolMessage返回给模型。
> 
> - respond：不执行工具，将人工回复直接作为ToolMessage返回给模型。
> 
> 

整个生命周期中，中间件从不需要关心"谁来审批"以及"审批流程怎么走"——只负责发出中断信号并处理结果。实际的审批流程（如通过 Web 界面、命令行工具）完全由外部系统实现，这与 LangChain Middleware 的解耦设计理念一脉相承。

## 1\.19\. **响应中断reject和respond决策有什么区别？**

reject 和 respond 都不会执行原始工具，但它们传递给模型的语义不同。

**reject 表示人工拒绝了该工具调用，框架会返回一条 status="error" 的 ToolMessage，明确告诉模型工具没有执行**。模型后续应该换方案、询问用户或者结束，不能无意义地重复调用该工具。它适合拒绝退款、删除文件、执行 SQL 等高风险操作。

**respond 表示人工不执行工具，但直接提供一份工具结果或补充信息。框架会返回一条 status="success" 的 ToolMessage，模型会把人工回复当作工具成功结果，并基于这份信息继续推理**。它适合补充退款原因、人工确认库存、人工提供线下核实结果等场景。

![d76J92fz\.jpg](图片和附件/d76J92fz.jpg)

简单说：reject 是“操作被拒绝”，respond 是“人工代替工具给出了结果”。

## 1\.20\. **如何实现同一个工具动态的HITL**

HumanInTheLoopMiddleware 的核心逻辑是"工具名匹配 → 触发中断"，它的审批条件是静态的，即：某个工具要么每次都中断，要么永远不中断。现实业务中，审批条件往往是动态的，如：数据操作工具exec\_sql中，select查询放行，update/delete/drop操作中断，这种场景中静态的审批不再适合，这时候需要根据工具参数的值来动态决定是否审批时，就需要自定义 HITL。

**自定义HITL中需要使用after\_model中间件**，因为该中间件运行在 LLM 输出工具调用之后、工具执行之前，这正是 HITL 拦截的正确位置，在该中间件中实现自定义HITL的逻辑，步骤如下：

1. 从state中提取工具调用信息。after\_model中间件中自带state参数，该参数中可以获取调用工具相关信息，以便判断是否需要进行中断。

2. 编写动态审批条件。当获取到AIMessage中要调用需要人工介入的工具时，根据业务规则来判断是否需要中断。

3. 调用interrupt\(\)发出中断并处理返回值。interrupt\(\) 是LangGraph 的原语，调用后图执行暂停，外部通过 Command\(resume=\.\.\.\) 恢复。传入的参数格式决定恢复后拿到什么。例如：

```Plain Text
review_result = interrupt({
    "action_requests": [{
        "name": 工具名称,
        "args": 工具参数,
        "description": 工具中断描述,
    }],
    "review_configs": [{
        "action_name": 工具名称,
        "allowed_decisions": ["approve", "reject"],
    }],
})
# interrupt() 停在这里，等外部调用 Command(resume={...})# 恢复后 review_result = {"decisions": [{"type": "approve"}]}

decision = review_result["decisions"][0]
```

4. 根据决策类型返回不同结果

在after\_model中间件中根据不同的的决策类型返回不同的值来控制工具是否执行。

案例：当退款金额大于500时触发人工介入确认，否则自动进行退款。

如下代码中对“process\_refund”工具在after\_model中自定义HITL，当退款金额大于500时触发人工介入确认，否则直接执行工具。

```Plain Text
"""
案例：自定义 HITL 逻辑 —— 按金额阈值动态人工介入
功能：退款金额 > 500 才触发人工介入确认；≤ 500 自动放行。
"""from langchain.agents import create_agent
from langchain.agents.middleware import after_model, AgentState
from langchain.tools import tool
from langchain_core.messages import ToolMessage
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.types import interrupt, Command
from langgraph.runtime import Runtime

from init_llm import deepseek_llm

# ===== 1. 模拟订单数据库 =====

ORDERS = {
    "ORD001": {"user": "张三", "amount": 200,   "status": "已付款"},
    "ORD002": {"user": "李四", "amount": 3000,  "status": "已付款"},
    "ORD003": {"user": "王五", "amount": 15000, "status": "已发货"},
}


# ===== 2. 定义工具 =====@tooldef query_order(order_id: str) -> str:"""
    查询订单信息
    Args：
      order_id: 订单编号，如 ORD002
    Returns：
      订单信息
    """
    order = ORDERS.get(order_id)
    if not order:
        return f"订单 {order_id} 不存在"return (f"订单 {order_id}：用户 {order['user']}，"f"金额 ¥{order['amount']}，状态 {order['status']}")


@tooldef process_refund(order_id: str) -> str:"""
    执行退款操作
    Args：
      order_id: 订单编号，如 ORD002
    Returns：
      退款成功消息
    """
    order = ORDERS.get(order_id)
    if not order:
        return f"订单 {order_id} 不存在，无法退款"return (f"订单 {order_id}（{order['user']}）已退款，退款金额{order['amount']}")



# ===== 3. 自定义 HITL 中间件：按金额阈值动态人工介入审批 =====# 使用 @after_model 中间件，在 LLM 生成工具调用之后、工具实际执行之前运行，# 检查模型是否调用了 process_refund 工具，若退款金额 > 500 则触发人工审批。@after_modeldef human_in_the_loop(state: AgentState, runtime: Runtime) -> dict | None:"""
    人工介入审批中间件。

    逻辑：
      - 检查模型是否调用了 process_refund
      - 若退款金额 ≤ 500，则返回 None，自动放行
      - 若退款金额 > 500，则调用 interrupt() 暂停，等待人工介入确认
        · approve：返回 None，工具正常执行
        · reject：返回含拒绝消息的 ToolMessage，工具不执行
    """# print("state:", state)
    last_message = state["messages"][-1] if state.get("messages") else Noneif not last_message or not hasattr(last_message, "tool_calls"):
        return None  # 没有工具调用，放行for tool_call in last_message.tool_calls:
        if tool_call["name"] != "process_refund":
            continue  # 只关心退款操作

        order_id = tool_call.get("args", {}).get("order_id", "")
        order = ORDERS.get(order_id)

        # 如果订单金额 ≤ 500，则自动放行if order["amount"] <= 500:
            print(f"\n[自定义HITL] 订单 {order_id} 金额 {order['amount']} ≤ 500，自动放行")
            return None# 如果订单金额 > 500，则触发中断，等待人工介入确认print(f"\n[自定义HITL] 订单 {order_id} 金额 {order['amount']} > 500，触发人工审批！")

        # interrupt() 是 LangGraph 原语，在这里调用会暂停整个图的执行
        review_result = interrupt({
            "action_requests": [{
                "name": tool_call["name"],
                "args": tool_call["args"],
                "description": (f"退款审批：订单 {order_id}，用户 {order['user']}，订单金额 {order['amount']}"),
            }],
            "review_configs": [{
                "action_name": tool_call["name"],
                "allowed_decisions": ["approve", "reject"],
            }],
        })

        # 处理审批结果，根据用户输入的决策来继续执行退款或拒绝退款# 当用户输入 approve/reject时，review_result中会包含一个决策对象print("review_result:", review_result)
        decision = review_result["decisions"][0]

        if decision["type"] == "approve":
            print(f"   >>> 审批通过，继续执行退款")
            return None  # 放行，工具正常执行elif decision["type"] == "reject":
            reason = decision.get("message", "退款申请被拒绝")
            print(f"   >>> 已拒绝：{reason}")
            # 不放行，返回一条合成 ToolMessage，# 模型会看到"工具被拒绝了"，不会继续执行退款return {
                "messages": [ToolMessage(
                    content=reason,
                    tool_call_id=tool_call["id"],
                )]
            }

    return None  # 没有需要审批的操作，放行# ===== 4. 创建智能体（传入自定义 人工介入处理 中间件）=====

agent = create_agent(
    model=deepseek_llm,
    tools=[query_order, process_refund],
    middleware=[human_in_the_loop],  # 自定义中间件替代 HumanInTheLoopMiddleware
    checkpointer=InMemorySaver(),
    system_prompt=(
        "你是电商助手，可以回答用户关于订单的问题。"
    ),
)

config = {"configurable": {"thread_id": "session_01"}}


# ===== 5. 对话测试 =====while True:
    user_input = input("\n你: ").strip()

    if user_input.lower() in ("exit", "quit", "q"):
        print("再见！")
        breakif not user_input:
        continue# 本次对话的输入，首次是普通消息，中断后会被替换为 Command(resume=(decisions))
    next_input = {"messages": [{"role": "user", "content": user_input}]}

    # 内层循环：处理同一轮对话中的多次中断while True:
        print("[Agent 回复]: ", end="", flush=True)

        interrupted = False # 本轮 stream 是否因中断而跳出for chunk in agent.stream(
            next_input,
            config=config,
            stream_mode=["updates", "messages"],
            version="v2",
        ):
            if chunk["type"] == "messages":
                token_data = chunk["data"]
                # token_data 是 (token_chunk, metadata) 元组
                token_chunk = token_data[0]
                if token_chunk.content:
                    print(token_chunk.content, end="", flush=True)

            elif chunk["type"] == "updates":
                update_data = chunk["data"]
                if "__interrupt__" in update_data:
                    interrupted = Trueprint("=" * 60)
                    print("Agent中断已触发！Agent 等待人工确认…")
                    print("=" * 60)

                    # 提取中断详情
                    interrupt_raw = update_data["__interrupt__"]
                    action_requests = interrupt_raw[0].value["action_requests"]
                    review_configs = interrupt_raw[0].value["review_configs"]

                    print(f"\n  本次中断包含 {len(action_requests)} 个待审批操作：")
                    for i, req in enumerate(action_requests):
                        cfg = review_configs[i]
                        print(f"    [{i}] {req['name']}  |  参数: {req['args']}  |  允许: {cfg['allowed_decisions']}")

                    # 按顺序逐个收集决策（多工具同时中断时，顺序必须一致）
                    decisions = []
                    for i, req in enumerate(action_requests):
                        cfg = review_configs[i]
                        allowed = cfg["allowed_decisions"]

                        print(f"\n  ———— 操作 [{i}]：工具：{req['name']} ————")
                        for k, v in req.get("arguments", {}).items():
                            print(f"     参数：{k}: {v}")
                        print(f"   允许: {allowed}")

                        while True:
                            decision = input(f"   >>> 请输入 ({'/'.join(allowed)}): ").strip().lower()
                            if decision in allowed:
                                breakprint(f"   只允许: {allowed}")

                        if decision == "approve":
                            decisions.append({"type": "approve"})
                            print(f"   已批准: 按原参数执行")
                        elif decision == "reject":
                            reason = input(f"   拒绝原因: ").strip() or "操作被拒绝"
                            decisions.append({"type": "reject", "message": reason})
                            print(f"   已拒绝：{reason}")

                    # 构造恢复命令，替换下一轮 stream 的输入
                    next_input = Command(resume={"decisions": decisions})
                    break  # 跳出 for，回到内层 while 顶部# ── 判断去向 ──if not interrupted:
            # for 循环正常结束 → 本轮对话完成，跳出内层 while，回到外层等下一句print()  # 末尾换行break       # 跳出内层 while，回到外层等下一个用户输入else:
            # for 循环被 break（有中断）→ 内层 while 回到顶部，用 next_input 恢复执行# 打印一个空行作为中断→恢复执行分割标志print("\nAgent正在恢复执行…\n")
            # 继续内层循环，用 Command(resume=...) 调用 agent.stream
```

以上代码运行后，进行如下对话，可以看到工具动态进行人工介入：

![BHsQAANz\.jpg](图片和附件/BHsQAANz.jpg)

![WCNURaNy\.jpg](图片和附件/WCNURaNy.jpg)

![R9Hsnj5d\.jpg](图片和附件/R9Hsnj5d.jpg)

以上代码注意如下几点：

1. @after\_model 在 LLM 生成工具调用之后、工具实际执行之前运行。

2. interrupt\(\) 是 LangGraph 原语，在这里调用会暂停整个图的执行，返回值的格式与 HumanInTheLoopMiddleware 完全一致，这样 Command\(resume=\{\.\.\.\}\) 可以无缝兼容。

3. 组织的interrupt中的形式要符合HumanInTheLoopMiddleware中间件中断信息，形式如下：

```Plain Text
interrupt({
        "action_requests": [{
                "name": 工具名字,
                "args": 工具参数,
                "description": 中断描述,
        }],
        "review_configs": [{
                "action_name": 工具名字,
                "allowed_decisions": ["approve", "reject"],
        }],
})
```

4. 涉及到返回ToolMessage时，返回的 ToolMessage 中 tool\_call\_id 必须与模型输出的 tool\_call\["id"\] 一致，否则 LangChain 无法将返回消息挂接到正确的对话上下文中。

## 1\.21\. **PIIMiddleware 支持哪四种处理策略**

PII（Personally Identifiable Information，个人身份信息）检测是合规场景下的核心需求，尤其在医疗、金融等受监管行业中。LangChain 提供了内置的 PII 检测中间件\(PIIMiddleware\)，能够自动识别和处理电子邮件、信用卡号、IP 地址等常见敏感信息。

以下示例展示了如何在 Agent 中同时使用多种 PII 检测，分别对邮件地址做脱敏处理、对信用卡做掩码处理、对 API Key 做阻断处理：

```Plain Text
... ...
agent = create_agent(
    model="gpt-5.4",
    tools=[customer_service_tool, email_tool],
    middleware=[
        # 对用户输入中的邮件地址做脱敏
        PIIMiddleware(
            pii_type="email",
            strategy="redact",
            apply_to_input=True,
            apply_to_output=False,
            apply_to_tool_results=False,
        ),
        # 对用户输入中的信用卡号做掩码
        PIIMiddleware(
            pii_type="credit_card",
            strategy="mask",
            apply_to_input=True,
        ),
        # 对 API Key 做阻断处理
        PIIMiddleware(
            pii_type="api_key",
            detector=r"sk-[a-zA-Z0-9]{32}",
            strategy="block",
            apply_to_input=True,
        ),
    ],
)

result = agent.invoke({
    "messages": [{
        "role": "user",
        "content": "我的邮箱是 zs@example.com ,信用卡是 5105-1051-0510-5100"
    }]
})
... ...
```

关于PIIMiddleware中间件的配置参数如下：

关于pii\_type参数，PII 中间件内置支持 email（邮箱）、credit\_card（信用卡，含 Luhn 校验）、ip（IP 地址）、mac\_address（MAC 地址）、url（URL）五种类型。同时，你也可以通过 detector 参数传入自定义检测函数或正则表达式来扩展识别能力。

关于strategy 处理策略支持如下四种：

## 1\.22\. **介绍Guardrails安全护栏架构**

**Guardrails 是 Agent 的安全防护体系，用于约束输入、模型调用、工具调用和最终输出。**

单一“防护栏”很难覆盖所有安全需求，LangChain允许将多个Middleware叠加到同一个Agent上，按顺序执行，形成分层防御体系。一个典型的组合策略是从外到内排列：先做轻量的确定性检查（关键词过滤、PII 脱敏），再做人工审批，最后用模型做二次校验。

如下代码示例：

```Plain Text
from langchain.agents import create_agent
from langchain.agents.middleware import (
    PIIMiddleware, HumanInTheLoopMiddleware,
    before_agent, after_agent
)

# 定义各个“防护栏”函数# ...

agent = create_agent(
    model="gpt-5.4",
    tools=[search_tool, send_email_tool],
    middleware=[
        # 第1层：确定性输入过滤（before agent，速度快）
        content_input_filter,

        # 第2层：PII 保护（工具调用层面）
        pii_redact_middleware,

        # 第3层：敏感操作人工审批
        HumanInTheLoopMiddleware(interrupt_on={"send_email": True}),

        # 第4层：模型驱动的安全校验（after agent，兜底检查）
        content_output_review,
    ],
)
```

Middleware 的执行顺序与声明顺序一致。在这个例子中，一个用户请求会依次经过：

1. 关键词过滤：快速拦截明显违规的请求

2. PII 脱敏：确保模型看不到也不会泄露敏感信息

3. 人工审批：涉及敏感操作时暂停，等真人确认

4. 安全校验：用模型对最终输出做语义级审查

这种分层设计的好处在于：每一层只关注一个维度的安全问题，职责单一、易于测试和独立迭代。一般原则是轻量级在前、重量级在后，即确定性检查先执行（速度快、成本低），人工审批和模型驱动审核在后（成本较高）。

如下案例模拟银行客服系统，支持用户查询账户余额、交易记录，以及执行转账、冻结账户等敏感操作，使用**四层安全护栏架构**来确保回复合规。

1. 第1层（before\_agent）：输入关键词过滤——拦截明显违规的请求（如洗钱、诈骗关键词）。

2. 第2层（PIIMiddleware）：敏感信息脱敏——自动脱敏身份证号、手机号。

3. 第3层（HITL）：高危操作人工审批——转账 \> 5000元、冻结账户等操作须主管审批。

4. 第4层（after\_agent）：输出内容安全审核 —— 用模型对最终回复做合规性兜底检查。

```Plain Text
from typing import Anyfrom langchain.agents import create_agent
from langchain.agents.middleware import (
    PIIMiddleware,
    HumanInTheLoopMiddleware,
    before_agent,
    after_agent,
    AgentState,
)
from langchain.tools import tool
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.runtime import Runtime
from langgraph.types import Command

from init_llm import deepseek_llm


# =============================================================================# 0. 模拟银行数据库# =============================================================================

ACCOUNT_DATABASE = {
    "622021234567890": {
        "name": "张三",
        "balance": 158000.00, # 余额"phone": "13812345678",
        "id_card": "110101199001011234",
        "status": "正常",
    },
    "622029876543210": {
        "name": "李四",
        "balance": 3200.50, # 余额"phone": "13987654321",
        "id_card": "320102198505052345",
        "status": "正常",
    },
}

# =============================================================================# 1. 定义业务工具# =============================================================================@tooldef query_balance(account_no: str) -> str:"""
    查询账户余额
    Args:
        account_no: 银行卡号
    """
    account = ACCOUNT_DATABASE.get(account_no)
    if not account:
        return f"卡号 {account_no} 不存在，请核实后重新查询。"return (f"账户 {account_no}（户名：{account['name']}，手机号：{account['phone']}，身份证号：{account['id_card']}）"f"当前余额：¥{account['balance']:,.2f}，状态：{account['status']}。")


@tooldef query_transactions(account_no: str, count: int = 5) -> str:"""
    查询最近 N 笔交易记录
    Args:
        account_no: 银行卡号
        count: 查询最近几笔交易，默认5笔
    """
    account = ACCOUNT_DATABASE.get(account_no)
    if not account:
        return f"卡号 {account_no} 不存在。"# 模拟交易记录
    sample = [
        ("2026-06-09", "超市消费", -156.80),
        ("2026-06-08", "工资入账", 15000.00),
        ("2026-06-07", "美团外卖", -45.00),
        ("2026-06-06", "京东购物", -899.00),
        ("2026-06-05", "滴滴出行", -32.50),
    ]
    lines = [f"账户 {account_no} 最近 {min(count, len(sample))} 笔交易："]
    for date, desc, amount in sample[:count]:
        direction = "收入" if amount > 0 else "支出"
        lines.append(f"  {date}  {desc}  {direction} {abs(amount)}元")
    return "\n".join(lines)


@tooldef transfer_funds(from_account: str, to_account: str, amount: float, note: str = "") -> str:"""
    账户转账
    Args:
        from_account: 转出卡号
        to_account: 转入卡号
        amount: 转账金额
        note: 转账备注
    """# payer 转出方，payee 转入方
    payer = ACCOUNT_DATABASE.get(from_account)
    payee = ACCOUNT_DATABASE.get(to_account)
    if not payer:
        return f"转出卡号 {from_account} 不存在。"if not payee:
        return f"转入卡号 {to_account} 不存在。"if payer["balance"] < amount:
        return f"余额不足！当前余额 {payer['balance']}元，无法转出 {amount}元。"# 执行转账
    payer["balance"] -= amount
    payee["balance"] += amount
    return (
        f"转账成功！从 {from_account}（{payer['name']}）向 {to_account}（{payee['name']}）"f"转入 {amount}元。备注：{note or '无'}。"f"转出方余额：{payer['balance']}元，转入方余额：{payee['balance']}元。"
    )


@tooldef freeze_account(account_no: str, reason: str) -> str:"""
    冻结指定账户
    Args:
        account_no: 要冻结的银行卡号
        reason: 冻结原因
    """
    account = ACCOUNT_DATABASE.get(account_no)
    if not account:
        return f"卡号 {account_no} 不存在。"if account["status"] == "已冻结":
        return f"账户 {account_no} 已经是冻结状态，无需重复操作。"
    account["status"] = "已冻结"return f"账户 {account_no}（户名：{account['name']}，手机号：{account['phone']}，身份证号：{account['id_card']}）已冻结，原因：{reason}。"@tooldef get_investment_advice() -> str:"""
    获取用户的投资建议
    """return f"基于你的账户信息，建议您投资于股票高风险的金融产品。"# =============================================================================# 2. 第1层：Before Agent —— 违禁词输入过滤（确定性守卫）# =============================================================================

BANNED_KEYWORDS = ["洗钱", "诈骗", "套现", "盗刷"]


@before_agent(can_jump_to=["end"])def input_content_filter(state: AgentState, runtime: Runtime) -> dict[str, Any] | None:"""
    输入内容过滤器 —— 第1层防护
    在模型处理之前快速拦截包含金融违规关键词的请求。
    命中后直接终止流程，连模型调用都不触发。
    """# 取本轮用户输入（多轮对话时取最后一条 human 消息）
    last_message = state["messages"][-1]
    if last_message.type != "human":
        return None# 检查用户输入是否包含违禁关键词
    content = last_message.content

    for keyword in BANNED_KEYWORDS:
        if keyword in content:
            print(f"\n{'=' * 60}")
            print(f"[第1层·输入过滤] 检测到违规关键词[{keyword}]，已拦截")
            print(f"{'=' * 60}")
            return {
                "messages": [{
                    "role": "assistant",
                    "content": (
                        f"您的请求包含违规内容，涉及[{keyword}]相关操作。"f"根据监管要求，本系统无法处理此类请求。如有疑问请联系客服。"
                    ),
                }],
                "jump_to": "end",
            }

    print(f"[第1层·输入过滤] 通过，未检测到违禁关键词")
    return None# =============================================================================# 3. 第2层：PIIMiddleware —— 敏感信息脱敏（内置守卫）# =============================================================================# PIIMiddleware 在模型调用前、工具返回结果后、最终输出后 三个节点自动脱敏# 这里配置两种敏感信息类型：身份证号、手机号# =============================================================================# 4. 第3层：HumanInTheLoop —— 高危操作人工审批# =============================================================================# HITL 配置：转账和冻结需要审批，查询操作自动放行# 转账金额 > 5000 时需要额外确认（在描述中提示）# =============================================================================# 5. 第4层：After Agent —— 输出内容安全审核（模型驱动守卫）# =============================================================================@after_agent(can_jump_to=["end"])def output_compliance_review(state: AgentState, runtime: Runtime) -> dict[str, Any] | None:"""
    输出合规审核器 —— 第4层防护
    用模型对 Agent 的最终回复做合规性检查，确保：
    - 不包含投资建议或收益承诺
    - 措辞符合金融监管要求
    """

    last_message = state["messages"][-1]


    # 只审核 AI 生成的回复if last_message.type != "ai":
        return None

    review_prompt = f"""你是一名金融合规审查员。请判断以下客服回复是否合规，只回复[合规]或[不合规]。

                    审查标准：
                    1. 回复中不得包含任何投资建议、收益承诺或理财产品推荐
                    2. 回复不得引导客户进行任何高风险操作
                    3. 回复语气应专业、客观，不得夸大或误导
  
                    客服回复内容：
                    {last_message.content}
  
                    审查结果（合规/不合规）："""

    review_result = deepseek_llm.invoke([
        {"role": "user", "content": review_prompt}
    ])

    if "不合规" in review_result.content:
        print(f"\n{'=' * 60}")
        print(f"[第4层·输出审核] 模型回复未通过合规审查，已替换为安全兜底回复")
        print(f"  审核模型判定：{review_result.content}")
        print(f"{'=' * 60}")
        last_message.content = (
            "抱歉，当前回复内容未能通过合规审核。""请您换个方式描述问题，或拨打我行客服热线咨询。"
        )
    else:
        print(f"[第4层·输出审核] 通过合规审查")

    return None# =============================================================================# 6. 创建 Agent —— 四层防护叠加# =============================================================================

agent = create_agent(
    model=deepseek_llm,
    tools=[query_balance, query_transactions, transfer_funds, freeze_account, get_investment_advice],
    middleware=[
        # 第1层：确定性输入过滤（最快，最早执行）
        input_content_filter,

        # 第2层：PII 自动脱敏（三个节点：before_model / after_tool / after_model）
        PIIMiddleware(
            pii_type="phone_number",           # 自定义 PII 类型名，检测手机号
            strategy="mask",                   # 掩码：138****5678
            detector=r"1[3-9]\d{9}",           # 自定义检测正则：11位手机号
            apply_to_input=True,
            apply_to_tool_results=True,
            apply_to_output=True,
        ),
        PIIMiddleware(
            pii_type="id_card_number",         # 自定义 PII 类型名，检测身份证号
            strategy="mask",                   # 掩码：110101********1234
            detector=r"\d{17}[\dXx]",          # 自定义检测正则：18位身份证号
            apply_to_input=True,
            apply_to_tool_results=True,
            apply_to_output=True,
        ),

        # 第3层：高危操作人工审批
        HumanInTheLoopMiddleware(
            interrupt_on={
                "query_balance": False,       # 查询余额 —— 自动放行"query_transactions": False,  # 查询交易 —— 自动放行# 转账操作需审批"transfer_funds": {
                    "allowed_decisions": ["approve", "reject"],
                    "description": (
                        "转账操作需审批。请核实转出/转入账户及金额是否正确，确认无误后批准执行。"
                    ),
                },
                # 冻结账户需审批"freeze_account": {
                    "allowed_decisions": ["approve", "reject"],
                    "description": (
                        "账户冻结属极高风险操作，请谨慎操作。确认冻结原因合理后方可批准。"
                    ),
                },
            },
            description_prefix="高危操作需要人工审批",
        ),

        # 第4层：模型驱动的输出合规审核（兜底）
        output_compliance_review,
    ],
    checkpointer=InMemorySaver(),
    system_prompt=(
        "你是某银行的智能客服助手[银小助]，为用户提供账户查询、转账、账户管理等服务，可以给用户一些投资建议。\n""工作规范：\n""1. 回复简洁专业，使用[您]称呼客户。\n""2. 涉及金额时精确到分，格式为 1,234.56 元。\n"
    ),
)


# =============================================================================# 7. 中断处理函数（处理第3层 HITL 审批）# =============================================================================def handle_interrupts(result, agent, config):"""
    处理一轮或多轮中断，直到 Agent 不再触发中断为止。

    返回值：最终的 GraphOutput（此时 result.interrupts 为空）
    """while result.interrupts:
        interrupt_data = result.interrupts[0].value
        action_requests = interrupt_data["action_requests"]
        review_configs = interrupt_data["review_configs"]

        # 展示所有待人工介入操作print(f"\n{'─' * 60}")
        print(f" Agent中断 —— {len(action_requests)} 个操作需要人工介入")
        print(f"{'─' * 60}")

        for i, req in enumerate(action_requests):
            cfg = review_configs[i]
            print(f"\n  [{i}] 工具名称 : {req['name']}")
            print(f"      参数    : {req['args']}")
            print(f"      允许决策 : {cfg['allowed_decisions']}")

        # 逐个收集决策（决策顺序 == action_requests 顺序）
        decisions = []

        print(f"\n{'·' * 40}")
        print("请按顺序对以上操作做出决策：")
        print(f"{'·' * 40}")

        for i, req in enumerate(action_requests):
            allowed = review_configs[i]["allowed_decisions"]

            print(f"\n 操作 [{i}] {req['name']}")
            # 展示当前参数供人工介入参考if req.get("args"):
                for k, v in req["args"].items():
                    print(f"     参数: {k} = {v}")

            # 可用的决策类型及说明
            hint_map = {
                "approve": "批准，按原参数执行工具",
                "edit":    "修改参数后执行工具",
                "reject":  "拒绝执行，附带反馈说明",
                "respond": "跳过工具执行，直接返回人工回复",
            }
            print("     可选操作：")
            for a in allowed:
                print(f"       > {a} — {hint_map.get(a)}")

            # 等待有效输入while True:
                decision = input(f"      >>> 输入操作 ({'/'.join(allowed)}): ").strip().lower()
                if decision in allowed:
                    breakprint(f"      无效输入，该操作只允许: {allowed}")

            # 根据决策类型构建决策对象if decision == "approve":
                decisions.append({"type": "approve"})
                print(f"      已批准 —— 工具将按原参数执行")

            elif decision == "edit":
                print(f"      请输入修改后的参数（直接回车保留原值）：")
                new_args = {}
                for k, v in req["args"].items():
                    new_val = input(f"         {k} [原值: {str(v)}]: ").strip()
                    if new_val == "":
                        new_args[k] = v  # 保留原值else:
                        # 直接使用用户输入的字符串
                        new_args[k] = new_val
                decisions.append({
                    "type": "edit",
                    "edited_action": {"name": req["name"], "args": new_args},
                })
                print(f"      已修改参数: {new_args}")

            elif decision == "reject":
                reason = input(f"      请输入拒绝原因: ").strip()
                if not reason:
                    reason = "操作被人工拒绝"
                decisions.append({"type": "reject", "message": reason})
                print(f"      已拒绝:{reason}")

            elif decision == "respond":
                reply = input(f"      请输入回复内容: ").strip()
                if not reply:
                    reply = "已确认，没有补充信息。"
                decisions.append({"type": "respond", "message": reply})
                print(f"      已回复:{reply}")

        # 提交决策，恢复执行print(f"\n{'─' * 60}")
        print(f"提交决策列表:{decisions}")
        print(f"{'─' * 60}")

        result = agent.invoke(
            Command(resume={"decisions": decisions}),
            config=config,
            version="v2",
        )

    return result


# =============================================================================# 8. 测试入口# =============================================================================if __name__ == "__main__":
    print("=" * 60)
    print("  金融客服系统[银小助]—— 四层安全护栏演示")
    print("=" * 60)
    print(" 四层防护：")
    print("  第1层：输入关键词过滤（before_agent）")
    print("  第2层：敏感信息自动脱敏（PIIMiddleware）")
    print("  第3层：高危操作人工审批（HITLMiddleware）")
    print("  第4层：输出合规审核（after_agent）")
    print()
    print(" 可用操作：")
    print("  - 查询余额 / 查交易记录 / 转账 / 冻结账户")
    print("  - 输入 exit 退出")
    print("=" * 60)

    config = {"configurable": {"thread_id": "session_01"}}

    while True:
        user_input = input("\n 客户: ").strip()

        if not user_input:
            continueif user_input.lower() in ("exit", "quit", "q"):
            print("  感谢使用银小助，再见！")
            breakprint("[银小助思考中...]")

        result = agent.invoke(
            {"messages": [{"role": "user", "content": user_input}]},
            config=config,
            version="v2",
        )

        # 处理人工审批中断
        result = handle_interrupts(result, agent, config)

        print("result",result)

        # 输出最终回复
        final_msg = result.value["messages"][-1]
        print(f"\n银小助: {final_msg.content}")
```

以上代码运行后，输入如下内容进行测试：

```Plain Text
帮我查一下卡号622021234567890的余额

我想咨询一下怎么用信用卡套现

从我的卡622021234567890转8000块给李四的卡622029876543210，备注是借款还款

从622021234567890转2000到622029876543210，备注借款还款

查询卡号622021234567890的交易记录

把我的账户冻结，我的卡丢了

基于我的账户给我一些投资建议
```

结果如下：

![UYNxL5WH\.jpg](图片和附件/UYNxL5WH.jpg)

![8uRsRmVs\.jpg](图片和附件/8uRsRmVs.jpg)

![PkadZAbF\.jpg](图片和附件/PkadZAbF.jpg)

![owo1RmmR\.jpg](图片和附件/owo1RmmR.jpg)

![uEafZJAT\.jpg](图片和附件/uEafZJAT.jpg)

![IwddLodO\.jpg](图片和附件/IwddLodO.jpg)

![g18bhosH\.jpg](图片和附件/g18bhosH.jpg)

## 1\.23\. **Agent多层Guarails失效排查思路**

Agent 已部署多层 Guardrails，但仍发生账户信息泄露，如何分析防护失效点？一般四层Guradrails如下：

```Plain Text
第1层：before_agent 关键词过滤
第2层：PIIMiddleware 脱敏
第3层：HITL 审批高风险工具
第4层：after_agent 输出审核
```

安全防护失效通常有以下原因：

排查步骤如下：

5. **第一步：倒推定位——从泄露点往前追溯**

拿到泄露的账户信息后，打印泄露发生前后 state\["messages"\] 中每条消息的内容和类型，找到敏感数据第一次出现的位置，先看泄露内容出现在哪里？是最终输出（AIMessage）还是工具返回（ToolMessage）？

- 如果在 AIMessage 泄露，说明第2层（PII脱敏）和第4层（输出审核）都失效了。第2层失效 = PII检测没识别出该格式的数据；第4层失效 = 审核模型漏判了含敏感信息的输出

- 如果在 ToolMessage 泄露，说明第2层（PII脱敏）对工具结果没生效。检查 apply\_to\_tool\_results=True 是否配置；检查该数据格式是否被 detector 识别。

6. **第二步：根因分析，逐层检查失效原因**

第1层（before\_agent 输入过滤）：

- 检查用户输入日志，攻击者是否用了同义改写（如“套现”改成“怎么把信用额度变成现金”）或间接指令。

- 加固方案：增加小模型语义分类器，判断是否为注入攻击或违规意图

第2层（PII脱敏）：

- 检查泄露数据的格式，是否超出内置 pii\_type 覆盖范围

- 加固方案：补充自定义 detector，并在工具调用和工具结果两个节点都开启检测

第3层（HITL审批）：

- 检查泄露操作是否触发了审批规则

- 加固方案：如果审批条件是静态工具名匹配，改为自定义 HITL 按参数值动态触发

第4层（after\_agent 输出审核）：

- 检查审核模型的 Prompt 是否覆盖了该泄露场景

- 加固方案：补充审核规则，如“输出不得包含任何银行卡号、身份证号、手机号”等

7. **第三步：分层加固，每层补充对应防护**

第1层：在 @before\_agent 中增加小模型语义分类器，检测提示注入攻击（如“忽略先前指令”、“输出系统提示”等模式）

第2层：扩展 PII 检测范围，增加 detector 覆盖业务特有敏感字段，并确保 apply\_to\_tool\_results=True

第3层：对于“查询所有用户”类操作也触发 HITL，或通过 RBAC 限制只能查询当前用户

第4层：优化审核 Prompt，增加具体禁止输出项，并降低审核模型温度减少漏判

8. **第四步：验证回归**

用泄露事件的原始输入做回归测试，确认修复后不再泄露，此外维护安全测试用例集，每次 Agent 变更时自动执行，防止回归

## 1\.24\. **Runtime和ToolRuntime区别？**

Runtime 和 ToolRuntime 都是 LangGraph 在执行 Agent 时自动注入的运行时对象，区别主要在使用位置和提供的信息范围。

\*\*Runtime 主要用于 Middleware 和 LangGraph 节点，常用于读取本次调用的 context、长期记忆 store、流式写入器以及部署执行信息。\*\*Middleware 中的短期状态不放在 Runtime 中，而是通过第一个 state 参数传入。

**ToolRuntime 主要用于工具函数，它除了具备 context、store 和流式能力外，还额外包含 state、config、tool\_call\_id 和当前工具集合等工具调用信息**。

两者对比如下：

## 1\.25\. **LangChain上下文工程分为哪些层面？**

LangChain将Agent的上下文分为三个层面，每个层面控制Agent循环中的不同环节：

三种上下文注意点：模型上下文的所有变更（如临时裁剪消息列表、动态替换提示词、动态替换工具集）只影响当次模型调用，不会写入 State。而工具上下文和生命周期上下文所做的修改（如工具写入状态、摘要中间件替换历史消息）是会涉及到state保存的，后续所有的Agent步骤都能看到这些变更。

这些上下文的数据来源有三种：

总结：

上下文工程核心任务就是**在Agent循环的每个环节，决定从哪个数据源读取什么信息，以什么格式提供给模型或工具，并在何时将结果回写到哪个数据源。**

上下文工程管理就是决定**什么信息可以给模型，什么信息只能给工具，什么信息保存到 State 或 Store，什么时候摘要和清理，人需要提前设计这些规则。**

上下文工程的目标就是**让模型在正确的时候看到正确的信息，让工具在正确的时候拿到正确的数据，让记忆在正确的时候被保存和召回，从而实现成本可控、精准高效的 Agent 行为。**

## 1\.26\. **什么是MCP？解决了什么问题？**

MCP 全称是：Model Context Protocol（模型上下文协议），MCP 是一套开放协议，用于标准化 AI 应用与外部工具、数据源和能力服务之间的通信。规定了：

```Plain Text
如何发现工具
如何描述工具参数
如何调用工具
如何返回工具结果
如何访问资源
如何提供提示模板
```

MCP解决的是AI 应用如何以统一方式连接外部工具和数据源。

![FLfSpTLp\.jpg](图片和附件/FLfSpTLp.jpg)

没有MCP之前，开发者每接入一个外部服务，就要写一套适配代码：定义工具 Schema、处理认证、解析返回值、写工具描述让LLM理解怎么用。100个工具 × 3个Agent = 300次重复劳动，这个场景被称为 "N×M 问题"。

MCP把复杂度从N×M降到了N\+M。每个服务只实现一次MCP服务器，所有支持MCP的客户端都能直接使用。换个角度说：写一次工具，到处可用。

MCP解决以下两个痛点：

1. 工具复用：一个MCP服务器写好之后，可以被多个Agent共享，不需要在每个项目里重新定义工具。

2. 工具与Agent解耦：工具提供方（比如后端团队）只维护MCP服务器，Agent开发者只负责组装和使用——职责边界清楚

MCP 采用 Host、Client、Server 架构。

通常一个 MCP Client 与一个 MCP Server 建立连接。一个 Host 可以同时管理多个 Client，从而连接多个 MCP Server。

## 1\.27\. **MCP提供核心能力有哪些？**

MCP 最核心的能力可以概括为三类原语：Tools、Resources 和 Prompts。

- Tools 是可执行的外部函数，例如查询数据库、调用 API 和创建工单；

- Resources 是应用可以读取的外部数据和上下文，例如文件、文档和代码仓库；

- Prompts 是服务端提供的可复用提示模板，例如合同总结和代码审查。

简单来说就是：Tools 负责做事情，Resources 负责提供资料，Prompts 负责提供模板。

## 1\.28\. **MCP支持哪几种传输方式？各自适用场景**

MCP当前主要支持两种标准传输方式：stdio和StreamableHTTP。

stdio是客户端启动MCPServer子进程，通过标准输入和标准输出传递JSON\-RPC消息，不需要端口和网络，适合本地脚本、IDE插件、桌面应用和简单单机Agent。

StreamableHTTP是远程服务传输方式，MCPServer独立部署，通过HTTP POST/GET通信，可以处理多个客户端连接，并支持认证请求头，适合生产环境、容器化部署和多个Agent共享统一业务服务。

注意：早期的 HTTP\+SSE 传输方式已经被 Streamable HTTP 替代，新项目不建议再使用独立的 SSE 传输

在LangChain中，本地服务配置transport="stdio"，远程服务通常配置transport="http"并填写MCP Endpoint。然后通过MultiServerMCPClient\.get\_tools\(\)加载工具，传递给create\_agent\(\)。选择原则是：本机单应用使用stdio，远程服务化和多客户端共享使用StreamableHTTP。

## 1\.29\. **MCP Tool 和 LangChain @Tool 有什么区别？**

LangChain Tool 是一个框架内的工具定义方式，MCP Tool 是一个跨框架的工具标准协议，两者对比如下：

使用LangChain Tool场景：工具逻辑简单，与 Agent 运行在同一进程即可；工具只有在本项目中用，不需要被其他 AI 应用消费。

使用MCP Tool场景：工具需要被多个 AI 应用共享（如公司统一的订单查询服务）；工具有独立的认证、权限、限流要求。

在实际项目中，两者往往不是非此即彼的关系。一个常见的模式是：

- 将通用业务能力封装为 MCP Server（订单服务、库存服务、通知服务）

- 将特定 Agent 逻辑保留为普通 LangChain Tool（格式化输出、Prompt 构建、内部状态读写）

这样既获得了 MCP 的标准化和跨平台能力，又保留了 LangChain 框架的开发灵活性。

## 1\.30\. **MCP 安全认证流程？**

MCP（Model Context Protocol）的认证机制主要用于 HTTP 传输层的安全保护。当 MCP 服务器通过 HTTP/SSE 对外暴露时，必须确保只有经过授权的客户端才能调用其中的工具和资源。FastMCP 和 MCP Python SDK 共同提供了一套基于 OAuth 2\.0 和 JWT（JSON Web Token）标准的认证体系，支持从简单的 Bearer Token 验证到完整的 OAuth 2\.0 授权服务器等多种认证模式。

OAuth 2\.0是一个"授权委托"协议，解决的核心问题是：如何让第三方应用在不知道用户密码的情况下，以用户的身份访问受保护资源。OAuth2\.0定义了四个角色：

**Owner登录Client后想要访问Resource Server中的资源，核心流程为：Client 首先去找 Authorization Server 拿 Token，然后带着 Token 访问 Resource Server，Resource Server 验证 Token 后放行。**

JWT（JSON Web Token）是一种紧凑、自包含的 Token 格式，即Token 的“身份证”格式。它的结构是三段 Base64 编码的字符串，用 \. 分隔：

```Plain Text
Header.Payload.Signature
eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJhZ2VudC0wMDEi.签名内容
```

- Header：描述签名算法（如 RS256）。

- Payload：存放"声明"（Claims），即 Token 里写了什么信息，例如谁签发的（iss）、给谁用的（aud）、谁持有的（sub）、有什么权限（scope）、什么时候过期（exp）。

- Signature：用私钥对前两部分做的数字签名，只能用对应的公钥来验证。签名保证了 Token 内容没有被篡改过。

JWT 的关键特性是无状态——服务器不需要存任何 Session，拿到 Token 后用公钥验证签名即可知道它是否合法。

下图清晰地展示了MCP认证全流程，该图包含完整的 MCP 认证序列图，展示了 Client、MCP Server、Authorization Server三者之间的交互流程。

![bV2OLe7f\.jpg](图片和附件/bV2OLe7f.jpg)

以上各个角色的职责如下：

1. Authorization Server（授权服务器 / Token 签发者）

- 持有私钥（Private Key），用来给 JWT 签名。

- 决定给谁发 Token、Token 里写什么权限（scopes）、Token 有效期多长。

- 在企业中通常是自建认证服务，也可以是一个简单的自建签发脚本。

2. MCP Server（资源服务器）

- 持有公钥（Public Key），用来验证 JWT 的数字签名，MCP Server 从不接触私钥，它只负责验证。

- 配置 JWTVerifier（或更高级的 OAuthProvider），对每个请求自动执行认证。

- 验证 Token 的签名、签发方（issuer）、接收方（audience）、过期时间（exp）、权限范围（scopes）。

- 认证通过后，将用户身份信息注入到请求上下文中，供工具函数使用。

3. MCP Client（AI Agent）

- 从授权服务器获取 JWT Token。

- 在建立 HTTP 连接时，通过 headers 参数将 Token 作为 Authorization: Bearer \<token\> 传入。

- 无需理解 Token 的内部结构，只需持有并传递即可。

**MCP 认证流程分为三个核心阶段：**

阶段一：认证发现（步骤 ①\~④）——Client 第一次访问 MCP Server 时，Server 返回 401 并告知"你应该去找哪个授权服务器拿 Token"。Client 通过标准化的 \.well\-known 路径自动发现授权服务器的端点。

阶段二：获取 Token（步骤 ⑤\~⑥）——Client 向授权服务器发起 OAuth 的授权码流程，拿到一个有时限的 JWT Access Token。

阶段三：携带 Token 访问（步骤 ⑦\~⑨）——Client 把 Token 放在 HTTP 请求头 Authorization: Bearer \<token\> 中发给 MCP Server，Server 用公钥验证 Token 合法后提供工具服务。

特别提示：以上是 MCP 规范的完整 OAuth 流程，适合多用户、需要动态授权的场景。在实际企业内部的机器对机器（M2M）场景中，流程可以大大简化——授权服务器直接为 Agent 签发 Token，Client 拿到 Token 后直接访问 MCP Server 即可（跳过步骤 ①\~④）。

## 1\.31\. **MCP 工具拦截器解决了什么问题？**

MCP Tool Interceptor 是 langchain\-mcp\-adapters 提供的客户端扩展能力，它位于 LangChain Agent 发起工具调用和 MCP Server 接收请求之间，主要解决 MCP Server 与 Agent 运行时隔离，以及认证注入、参数处理、日志、限流、缓存、重试等横切逻辑重复的问题。

拦截器的核心能力如下：

工具拦截器是一个异步函数，在LangChain 应用（MCP Client端）中实现，接收 MCPToolCallRequest 和 handler，在调用工具前后做自定义操作，使用示例如下：

```Plain Text
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_mcp_adapters.interceptors import MCPToolCallRequest

... ...
async def logging_interceptor(request: MCPToolCallRequest, handler):"""记录每次工具调用的入参和返回结果"""print(f"[MCP] 调用工具: {request.name}, 参数: {request.args}")
    result = await handler(request)       # 调用下一个拦截器或实际工具print(f"[MCP] 工具返回: {result}")
    return result


client = MultiServerMCPClient(
    {"math": {"transport": "stdio", "command": "python", "args": ["server.py"]}},
    tool_interceptors=[logging_interceptor],  # 传入拦截器列表
)
... ...
```

当 MCP 工具在 create\_agent 中使用时，拦截器可以通过 request\.runtime 访问四种运行时信息，这些信息来自 LangChain Agent 进程内部——MCP Server 本身是拿不到的。

拦截器不仅可以读取状态，还可以写入状态和控制执行流，这通过返回 Command 对象实现。

Command 的核心用法：

注意：goto="node\_name" 需要图中存在对应节点，create\_agent 构建的标准图只有 model 和 tools 两个节点，所以非 **end** 的跳转仅在自定义图中有意义。日常最常用的是 update 更新状态和 goto="end" 提前终止。

## 1\.32\. **MCP 的 Elicitation解决了什么问题？**

Elicitation 是 MCP 协议 2025\-11\-25 版本引入的能力——允许 MCP 服务器在工具执行过程中，主动向用户请求额外信息。传统工具调用是单向的：Agent 给参数，服务器返回结果。如果服务器发现自己缺少某些信息，只能返回错误、让 Agent 重新调用——来回好几轮。

Elicitation 把这个问题从"多轮对话"变成了"单次调用内的交互"。服务器可以通过 ctx\.elicit\(\) 向客户端发出一个带 Schema 的请求，客户端（或用户）响应后，工具继续执行。

**Elicitation用法如下：**

```Plain Text
from fastmcp import FastMCP, Context

mcp = FastMCP("Demo")

@mcp.tool()async def create_profile(name: str, ctx: Context) -> str:
    result = await ctx.elicit(
        message=f"请填写 {name} 的以下信息：",
        response_type=UserDetails,   # Pydantic 模型，定义需要哪些字段
    )
    if result.action == "accept" and result.data:
        return f"已创建 {name} 的档案"if result.action == "decline":
        return f"已创建最简档案（用户拒绝提供信息）"return "操作已取消"
```

Client端通过在Callbacks中指定on\_elicitation回调处理询问：

```Plain Text
from mcp.types import ElicitRequestParams, ElicitResultasync def on_elicitation(mcp_context, params, context) -> ElicitResult:
    # 真实场景：弹窗让用户填写，返回用户输入
    return ElicitResult(action="accept", content={"email": "...", "age": 25})

client = MultiServerMCPClient({...}, callbacks=Callbacks(on_elicitation=on_elicitation))
```

Server端ctx\.elicit\(参数\.\.\.\) 常见参数说明如下：

Client端回调函数中必须返回ElicitResult对象，该对象中包含两个字段：action（用户相应给Server端的动作）、content（提交给Server的数据）。

action可以填写的值如下：

只有当action=“accept”时，content才需要返回用户填写的内容，内容格式取决于Server端response\_type的类型：

注意： 不管 response\_type 是什么，FastMCP 都帮你包装，Server 端工具里直接 [result\.data](http://result.data/) 拿到解包后的值，在 on\_elicitation 回调里构造 ElicitResult 时，必须按对应格式塞 content。

## 1\.33\. **介绍MessagesState状态归并器**

MessagesState对象是 LangGraph 预置的状态类型，其作用就是存储LangGraph中的状态信息。其默认定义如下（源码langgraph/graph/[message\.py](http://message.py/)）：

```Plain Text
class MessagesState(TypedDict):
    messages: Annotated[list[AnyMessage], add_messages]
```

这个定义中的“messages:Annotated\[list\[AnyMessage\], add\_messages\]”告诉 LangGraph：当多个节点都向 messages 写入数据时，使用 add\_messages 函数（归并器）来合并新旧数据，而不是直接覆盖。

在 LangGraph 中，状态中的每个字段都可以指定一个归并器（Reducer），它决定了"收到新数据时如何与旧数据合并"。常用的归并器包括：

- add\_messages：LangGraph 专为消息列表设计的归并器。它不仅做追加，还支持按消息 ID 去重和更新（同 ID 的新消息会替换旧消息），并能把 dict 形式的消息自动转换为 Message 对象（\{"role":"user","content":"hi"\} → HumanMessage）。内置MessagesState使用的就是它。

- operator\.add：Python 标准库的加法操作，对列表就是纯拼接。适合累积日志、结果列表等不需要去重语义的场景。

- 不指定归并器：新值直接覆盖旧值。适合布尔标记、当前步骤名等标量值。

- 自定义函数：根据业务需求自定义合并逻辑。

add\_messages 和 operator\.add 在"追加消息"这个基本行为上表现一致，但前者多了 ID 去重和格式转换能力。

```Plain Text
class MessagesState(TypedDict):
    messages: Annotated[list[AnyMessage], operator.add]
    llm_calls: int   # 额外字段：记录 LLM 调用次数，未指定归并器 → 覆盖语义
```

注意这里的 llm\_calls 字段：它没有指定归并器，因此每次节点返回新值时直接覆盖旧值。一个状态中可以同时混用不同归并策略的字段——消息用追加，计数器用覆盖。

## 1\.34\. **Command的goto参数和 add\_conditional\_edges 在路由控制上有什么区别？**

Command\.goto：在节点函数内部直接指定下一步去向，路由逻辑和节点逻辑放在一起，代码更内聚。适合路由逻辑简单、与节点输出强相关的场景（如分类节点根据结果决定去 A 还是 B）。这种方式的优点是State更新和路由控制可以一次完成。

add\_conditional\_edges：在图构建层面单独定义路由函数，适合路由逻辑复杂、需要独立维护的场景。这种方式优点是节点逻辑和路由逻辑分离，图的整体拓扑清晰，更容易阅读和维护。

特别注意：两者不能混用，如果一个节点已经用 Command 指定了 goto，就不需要在外层再用 add\_conditional\_edges 声明。

Command goto用法：

```Plain Text
from typing import Literalfrom langgraph.types import Command


def classify_node(
    state,
) -> Command[
    Literal[
        "presale",
        "aftersale",
    ]
]:"""
    在节点内部完成分类、状态更新和路由。
    """if "价格" in state["text"]:
        return Command(
            update={
                "intent": "presale",
            },
            goto="presale",
        )

    return Command(
        update={
            "intent": "aftersale",
        },
        goto="aftersale",
    )
```

add\_conditional\_edges用法：

```Plain Text
builder.add_conditional_edges(
    "classify",
    route_by_intent,
    {
        "presale": "presale",
        "aftersale": "aftersale",
    },
)
... ...
def route_by_intent(state):"""
    根据State中的意图返回路由标签。
    """if state["intent"] == "presale":
        return "presale"return "aftersale"
```

## 1\.35\. **LangGraph 有几种工作流模式？**

LangGraph 提供了五种工作流模式，每种模式对应一类特定的控制流形状，解决了某一种典型的编排需求，知道有这些模式存在，遇到类似的业务时可以直接对号入座，方便构思图的拓扑结构。

4. **工作流模式一：提示链（Prompt Chaining）**

提示链（Prompt Chaining）：每个 LLM 调用处理上一个 LLM 调用的输出，像工厂流水线，每一步对半成品做一道工序。

适用场景：任务可以分解为多个有序的子步骤，且每步的输出是下一步的输入。例如：文档翻译（翻译→校对→润色）、内容生成（大纲→正文→标题）、代码生成（需求分析→方案设计→代码编写→代码审查）。

![XwVKGJKs\.jpg](图片和附件/XwVKGJKs.jpg)

示例：**产品文案流水线（生成→字数判断→扩写→润色）**

![azzZhcif\.jpg](图片和附件/azzZhcif.jpg)

5. **工作流模式二：并行化（Parallelization）**

并行化（Parallelization）：多个 LLM 调用同时执行，互不依赖，多个独立子任务并行（提高速度）。

适用场景：内容需要从多个维度同时处理，或需要多个独立视角交叉验证。例如：文档审核（一个检查语法、一个检查事实准确性）、多语言翻译（同时翻译为英文、日文、法文）。

在 Graph API 中，并行化的实现方式是：从同一个源节点出发，向多个不同节点添加边——这些节点会在同一步并行执行。所有并行节点完成后，在汇聚节点（aggregator）合并结果。

![yb94T7bm\.jpg](图片和附件/yb94T7bm.jpg)

**示例：商品评论多维分析（情感分析、关键词提取、垃圾检测）三路并行，最后汇总：**

![fROhZ68i\.jpg](图片和附件/fROhZ68i.jpg)

6. **工作流模式三：路由（Routing）**

路由（Routing）：一个分类步骤将输入分配到不同的专用处理流程，每个流程只处理自己擅长的子任务。

适用场景：输入的类型多样化，每种类型需要不同的处理逻辑。例如：客服工单分发（退款/技术/咨询走不同流程）、代码审查（按语言类型分配给不同的审查子流程）。

![IcwnEYcZ\.jpg](图片和附件/IcwnEYcZ.jpg)

**示例：客服工单自动分发系统，根据用户不同问题进行分类（退款、技术、一般咨询），然后通过不同的节点进行处理不同类别的问题。**

![zGjDiWJY\.jpg](图片和附件/zGjDiWJY.jpg)

7. **工作流模式四：编排者\-工作者（Orchestrator\-Worker）**

编排者\-工作者（Orchestrator\-Worker）:编排器（Orchestrator）将大任务拆分为子任务，动态分配给工作者（Worker）并行执行，最后合并结果。

适用场景：子任务数量在运行前不可预知。例如：多文件代码更新（每个文件一个 Worker）、多章节报告生成（每个章节一个 Worker）。

该模式与并行化的区别：并行化的子任务是预定义的（图中固定有 N 个节点），而编排器\-工作者的子任务是动态生成的（根据输入内容运行时决定创建多少个 Worker）。

LangGraph 的 Send API 专为这个模式设计——编排器的条件边函数返回一个 Send 对象列表，框架自动为每个 Send 创建一个 Worker 实例并行执行，每个 Worker 拿到自己专属的输入。

![aJbB8heK\.jpg](图片和附件/aJbB8heK.jpg)

**示例：产品发布公告生成。该案例中首先由大模型生成指定产品的发布公告组成模块，然后针对每个模块动态派发Worker撰写，最后将多个Worker输出结果进行合并输出。**

![4cN1T7Ci\.jpg](图片和附件/4cN1T7Ci.jpg)

8. **工作流模式五：评估器\-优化器（Evaluator\-Optimizer）**

评估器\-优化器（Evaluator\-Optimizer）:一个 LLM 生成内容，另一个 LLM 评估质量，如果评估不合格，带上反馈重新生成，循环直到达标。

适用场景：输出质量有明确标准但需要迭代才能满足。例如：文案撰写（生成→打分→修改重来）、代码优化（生成→审查→重构）、翻译质量（翻译→校对→修正）。

![OsDJV56r\.jpg](图片和附件/OsDJV56r.jpg)

**示例：AI 文案审核系统。首先生成文案，再进行评估，如果超过3次则接受文案。**

![TOSJVKcE\.jpg](图片和附件/TOSJVKcE.jpg)

## 1\.36\. **LangGraph多个并行节点更新同一个状态为什么报错？**

LangGraph 中多个并行节点同时写入同一个 State 字段时，必须给该字段定义 Reducer，否则 LangGraph 不知道如何合并多个更新，会抛出 InvalidUpdateError。

如果多个节点都要向列表追加结果，可以使用 Annotated\[list, operator\.add\]；如果更新的是消息列表，应使用 add\_messages；如果是数值累加，可以使用 operator\.add；如果是字典合并，则需要自定义 Reducer，并明确字段冲突策略。

在动态 Send Worker 场景中，所有 Worker 写入同一个字段时同样需要 Reducer。核心原则是：并行节点共享字段必须定义合并规则，结果顺序必须由业务字段显式控制。

## 1\.37\. **LangGraph Checkpointer持久化模式有几种？**

持久化模式控制在图执行过程中，checkpoint 数据何时写入存储后端。LangGraph 提供了三种模式，在性能和可靠性之间提供不同的权衡。

持久化使用方式：

```Plain Text
# 指定持久化模式
graph.invoke(input_data, config, durability="sync")
```

持久化三种模式对比如下：

案例：演示三种模式使用。

```Plain Text
"""三种持久化模式 —— 观察 checkpoint 数量差异"""from langgraph.graph import StateGraph, START, END, MessagesStatefrom langgraph.checkpoint.memory import InMemorySaverfrom langchain_core.messages import AIMessage, HumanMessagedef echo_node(state: MessagesState):
    """简单回显节点"""return {"messages": [AIMessage(content="处理完成")]}


builder = StateGraph(MessagesState)
builder.add_node("echo_node", echo_node)
builder.add_edge(START, "echo_node")
builder.add_edge("echo_node", END)

graph = builder.compile(checkpointer=InMemorySaver())

if __name__ == "__main__":
    # ---- exit 模式：仅退出时保存 ----config_exit = {"configurable": {"thread_id": "thread_001"}}
    graph.invoke(
        {"messages": [HumanMessage(content="测试")]},
        config_exit,
        durability="exit",
    )

    # ---- async 模式：每步同步保存 ----config_async = {"configurable": {"thread_id": "thread_002"}}
    graph.invoke(
        {"messages": [HumanMessage(content="测试")]},
        config_async,
        durability="async",
    )

    # ---- sync 模式：每步同步保存 ----config_sync = {"configurable": {"thread_id": "thread_003"}}
    graph.invoke(
        {"messages": [HumanMessage(content="测试")]},
        config_sync,
        durability="sync",
    )


    # ---- 对比 ----exit_history = list(graph.get_state_history(config_exit))
    async_history = list(graph.get_state_history(config_async))
    sync_history = list(graph.get_state_history(config_sync))

    print(f"\nexit 模式: 只有 1 个（step=1），中间 step=-1 和 step=0 被丢弃")
    for s in exit_history:
        print(f"  step={s.metadata['step']}, next={s.next}")

    print(f"\nasync 模式: 3 个（step=-1, step=0, step=1），完整保留")
    for s in async_history:
        print(f"  step={s.metadata['step']}, next={s.next}")

    print(f"\nsync 模式: 3 个（step=-1, step=0, step=1），完整保留")
    for s in sync_history:
        print(f"  step={s.metadata['step']}, next={s.next}")
```

以上代码运行结果如下：

![LmfGfB7g\.jpg](图片和附件/LmfGfB7g.jpg)

以上代码注意如下几点：

1. exit模式中间状态全部丢弃，意味着 get\_state\_history 只能看到最后一个 checkpoint，时间旅行、容错恢复都无从谈起。

2. 对InMemorySaver来说，sync和async几乎没有性能差异（内存写入都是同步的），区别在 PostgreSQL 等远程后端上才会体现。

3. 生产环境建议不要用 exit，除非你的图是纯无状态的批处理任务且你确定永远不需要查看中间状态，对时效性要求高的用"async"，金融等关键业务用"sync"。

## 1\.38\. **Store命名空间如何设计？**

LangGraph Store 的 Namespace 是一个元组（tuple），用于对记忆进行逻辑分组，类似于文件系统中的文件夹：

```Plain Text
# Namespace 是元组形式namespace = ("user_001", "memories")
```

Namespace 可以是任意长度，但不应无限扩展，每一层代表一个层级，设计 Namespace 的核心目标是：数据隔离 \+ 高效检索。设计原则有如下三个：

**原则1：按权限边界分层（隔离性优先）**

Namespace 的层级结构应当直接映射权限模型，第一级通常是用户ID或组织ID，确保不同用户/租户的数据天然隔离。注意：第一级应放数据的最大隔离范围，例如租户 ID、部门 ID、项目 ID 或组织 ID，具体取决于业务权限模型。

```Plain Text
# 推荐：第一级是租户ID，天然隔离namespace = ("tenant_123", "preferences")
namespace = ("org_456", "memories")

# 不推荐：所有用户混在一起namespace = ("memories",)  # 无法区分数据属于谁
```

**原则2：层级清晰、语义明确**

第二级及以后用语义化的分类名，如 "memories"、"preferences"、"orders"、"profile" 等。

```Plain Text
# 典型的两级结构namespace = ("user_001", "memories")      # 用户001的记忆namespace = ("user_001", "preferences")   # 用户001的偏好设置namespace = ("user_001", "orders")        # 用户001的订单历史# 三级结构（更细粒度）namespace = ("org_001", "dept_a", "projects")
```

**原则3：Namespace 标签的字符限制。**

LangGraph 的 Namespace 标签禁止包含句点（\.），因为句点有特殊含义。

```Plain Text
# 错误：包含句点
namespace = ("user@email.com", "memories")  # 会报错# 正确：替换句点为下划线def sanitize_namespace_label(label: str) -> str:return label.replace(".", "_")

namespace = (sanitize_namespace_label("user@email.com"), "memories")
# 结果：("user@email_com", "memories")
```

## 1\.39\. **介绍LangGraph节点容错机制？**

LangGraph 为节点级容错提供了三种可组合的机制：重试（Retry）、超时（Timeout）和错误处理（Error Handling）。

它们按固定顺序协作：节点执行时可能被超时中断\(抛 NodeTimeoutError\)；节点抛异常后,重试策略决定是否重试；重试耗尽后,错误处理器接管,执行对应路由。

![k1e8onmw\.jpg](图片和附件/k1e8onmw.jpg)

4. **重试策略 \(RetryPolicy\)**

RetryPolicy 的核心作用是：当一个节点因异常而失败时，自动重新执行该节点。它是抵御临时性故障（如网络抖动、服务暂时不可用）的第一道防线

配置方式：在 add\_node 时通过 retry\_policy 参数配置。

5. **超时策略 \(TimeoutPolicy\)**

重试策略解决的是“失败”问题，但无法处理“卡住”的问题。如果一个节点因为死循环或外部服务挂起而永不返回，重试机制不会被触发。TimeoutPolicy 正是为此设计的。

配置方式：在 add\_node 时通过 timeout 参数配置。

6. **错误处理 \(Error Handler\)**

当重试和超时都无法解决问题时（例如，所有重试机会已用完），error\_handler 提供了最后的兜底机会。它是一个在节点失败且重试耗尽后执行的函数。

配置方式：在 add\_node 时通过 error\_handler 参数配置。

错误处理器可以接收当前状态和 NodeError 对象（包含失败节点名和异常），并可以通过返回 Command 对象来更新状态或路由到其他节点，从而实现优雅的降级或补偿逻辑

**协同工作流程**：这三种机制按照固定顺序协作：

1. 节点执行时，如果超过了 run\_timeout 或 idle\_timeout，会被强制中断并抛出 NodeTimeoutError。

2. 节点抛出任何异常（包括超时异常）后，RetryPolicy 会根据 retry\_on 规则判断是否应该重试。

3. 如果重试策略耗尽后节点仍然失败，error\_handler 将被执行，进行最终处理。

以下是一个组合使用三种容错机制的节点配置示例：

```Plain Text
from langgraph.graph import StateGraph
from langgraph.types import RetryPolicy, TimeoutPolicy
from langgraph.errors import NodeError
from langgraph.types import Command

# ... 假设已定义 State 和异步节点函数 async def fetch_data(state) ...def my_error_handler(state: State, error: NodeError) -> Command:"""重试耗尽后的兜底处理"""print(f"节点 '{error.node}' 最终失败: {error.error}")
    # 更新状态并路由到补偿节点return Command(update={"status": "失败"}, goto="compensate_node")

builder = StateGraph(State)
builder.add_node(
    "fetch_data",
    fetch_data,
    # 1. 配置重试策略：最多尝试3次
    retry_policy=RetryPolicy(max_attempts=3),
    # 2. 配置超时策略：最多运行5秒
    timeout=TimeoutPolicy(run_timeout=5),
    # 3. 配置错误处理器
    error_handler=my_error_handler,
)
# ... 后续添加边并编译图
```

为了方便，LangGraph 还提供了 set\_node\_defaults 方法，可以为图中后续注册的所有节点统一设置默认的容错策略，避免在每个节点上重复配置：

```Plain Text
builder.set_node_defaults(retry_policy=RetryPolicy(max_attempts=2),timeout=TimeoutPolicy(run_timeout=30),error_handler=default_error_handler,)# 此后 add_node 的节点将继承上述默认配置
```

## 1\.40\. **LangGraph 的 v1 、v2、v3流式格式有什么区别？**

LangGraph的流式输出目前有三个版本：v1、v2、v3。它们代表了从原始格式到统一格式再到类型化事件流的演进路径。

4. **v1（默认，传统格式）**

v1是LangGraph的默认流式格式。

核心问题：输出格式不统一，随配置变化而变化：

- 单模式：返回裸数据 \{"node\_name": \{"field": "value"\}\}

- 多模式：返回 \(mode, data\) 元组

- 含子图：返回 \(namespace, data\) 元组

三种场景三种格式，消费端代码需要针对不同情况做分支处理，维护成本高。v1的invoke\(\)返回的是普通字典（dict），中断信息混在输出中，通过\_\_interrupt\_\_字段访问。

5. **v2（统一格式，LangGraph 1\.1引入）**

v2是LangGraph 1\.1版本引入的格式，核心改进是统一输出格式 \+ 类型安全。统一输出格式：无论单模式、多模式还是子图，每个chunk都是固定结构的StreamPart字典：

```Plain Text
{
    "type": "values" | "updates" | "messages" | "custom" | "checkpoints" | "tasks" | "debug",
    "ns": (),  # 命名空间元组，子图事件才有内容"data": ...,  # 实际内容，类型随 stream_mode 变化# values模式下还有 interrupts 字段
}
```

类型安全：每个模式都有对应的TypedDict——ValuesStreamPart、UpdatesStreamPart、MessagesStreamPart等，可以从langgraph\.types导入。支持完整的类型收窄（type narrowing）。

invoke\(\)返回值变化：v2的invoke\(\)返回GraphOutput对象：

```Plain Text
from langgraph.types import GraphOutputresult = graph.invoke({"input": "hello"}, version="v2")
# result 是 GraphOutput，不是 dictresult.value      # 你的输出数据
result.interrupts # 中断信息元组，无中断时为空
```

使用方式：在stream\(\)/astream\(\)中传入version="v2"参数。

```Plain Text
for chunk in graph.stream(input, stream_mode=["updates", "custom"], version="v2"):
    if chunk["type"] == "updates":
        # 处理状态更新elif chunk["type"] == "custom":
        # 处理自定义数据
```

三、v3（事件流式API，LangGraph 1\.2引入）

v3是LangGraph 1\.2引入的事件流式API（Event Streaming），在v2的基础上进一步演进，官方文档明确推荐新应用使用v3。

核心变化：从“chunk流”升级为“类型化投影（Typed Projections）”

v2/v3对比如下：

v3使用示例：

```Plain Text
stream = graph.stream_events(input, version="v3")

# 独立消费LLM token流for message in stream.messages:
    for token in message.text:
        print(token, end="", flush=True)

# 独立消费状态快照for snapshot in stream.values:
    print(snapshot)

# 最终一次性拿结果
final_state = stream.output

# 检查中断if stream.interrupted:
    print(stream.interrupts)
```

注意：v3目前处于实验阶段（experimental），但已是官方推荐新应用使用的方式。

## 1\.41\. **如果一个图中有多个 LLM 节点，如何输出指定LLM输出内容？**

在多 LLM 节点的图中，要精准输出指定节点的内容，本质上是对流式数据进行过滤。LangChain 和 LangGraph 提供了三种从粗到细的过滤方案。

6. **按节点过滤：判断来源是哪个节点，适合"某个节点的 token 全部不要"。**

metadata 里有一个 langgraph\_node 字段，记录着"这条 token 是哪个节点产出的"。消费端只需检查这个字段，只保留目标节点名的 token 即可：

```Plain Text
for chunk in graph.stream(..., stream_mode="messages", version="v2"):
    if chunk["type"] == "messages":
        msg, metadata = chunk["data"]
        if msg.content and metadata.get("langgraph_node") == "write_copy":
            print(msg.content, end="", flush=True)
```

这种方式最简单，不需要在模型初始化时做任何额外配置，但粒度是"节点级"，同一个节点里所有LLM调用共用一个节点名，没法进一步区分，而且节点名是图结构的硬编码，改了节点名就得改消费代码。

7. **按 tags 过滤：给模型实例打标签，按标签区分，适合"同一个节点里多个 LLM 调用有不同去向"。**

给模型实例打标签（tags=\["标签名"\]），消费端按 metadata\["tags"\] 过滤。不同模型实例可以有不同标签，同一个节点里两个 LLM 调用用不同标签模型，就能精确区分到"具体哪次调用"：

```Plain Text
# 初始化时打标签
copy_model = model.with_config({"tags": ["copy"]})
internal_model = model.with_config({"tags": ["internal"]})

# 消费端按标签过滤for chunk in graph.stream(..., stream_mode="messages", version="v2"):
    if chunk["type"] == "messages":
        msg, metadata = chunk["data"]
        if msg.content and metadata.get("tags") == ["copy"]:
            print(msg.content, end="", flush=True)
```

tags 比节点名更灵活，同一模型的不同实例可以打不同标签、标签可以按业务含义命名（"copy" / "internal" / "draft" / "polish"），消费端按标签判断语义更清晰，这也是官方推荐的方案。

8. **nostream 静默：给不需要流出的 LLM 打上 nostream 标签，它的 token 压根不进入 messages 流，消费端什么都不用做。**

如果某个 LLM 的输出完全不需要出现在 messages 流里，比如内部审计用的结构化提取、合规评估，最省事的做法是直接给它打上 nostream 标签。被标记的 LLM 调用仍然正常执行、正常产出结果存入状态，但它的 token 不会进入 messages 流，消费端连过滤都不用做：

```Plain Text
# 内部用途的模型，打上 nostream 标签internal_model = model.with_config({"tags": ["nostream"]})

# 这个模型生成的 token 不会出现在 messages 流里# 但 invoke 结果如果有些如到state，则会正常写入 state
```

## 1\.42\. **LangGraph interrupt使用注意点**

interrupt\(\) 靠抛异常实现暂停、靠"节点从头重跑"实现恢复，这两条底层机制衍生出几条必须遵守的规则。违反它们会导致中断失效、数据错乱或指数级重放。

9. **不要把 interrupt 包在裸 try/except 里。**

interrupt\(\) 通过抛出一个特殊异常来暂停，如果被 except Exception 捕获，中断就不会传回运行时，图会"假装没中断"继续执行。需要捕获异常时，要么把 interrupt\(\) 放在 try 块外，要么只捕获特定异常类型（如 NetworkException），不要用裸 except Exception。

10. **不要重排节点内的 interrupt 调用。**

一个节点里多个 interrupt\(\) 的 resume 值按调用顺序严格匹配。如果某次执行有条件地跳过了某个 interrupt\(\)，顺序就会错位，导致后续中断拿到错误的 resume 值。所以节点内的 interrupt\(\) 调用次数和顺序必须每次执行都一致。

11. **不要传不可序列化的值。**

interrupt\(\) 的载荷和 resume 值要能 JSON 序列化（不同 Checkpointer 对序列化要求不同）。传函数、类实例等复杂对象可能在某些后端上失败。

12. **interrupt 之前的副作用要幂等。**

因为恢复时节点从头重跑，interrupt\(\) 之前的代码会再执行一次。如果那里面有"创建记录""追加列表"这类非幂等操作，重跑就会产生重复数据。正确做法是：把副作用放在 interrupt\(\) 之后，或拆到独立节点，或保证操作本身幂等（如 upsert）。

13. **避免 while True \+ interrupt\(\) 循环。**

虽然while True\+interrupt使用也没有问题（LangGraph内部给每次中断都进行编号，resume后再次执行while True时，编号相同会获取对应resume值继续执行），但当业务逻辑复杂了很容易出现逻辑混乱，甚至死循环。

## 1\.43\. **子图和父图之间有哪些通信模式？**

LangGraph中，子图就是一个被当作节点用在另一个图里的图。父子图之间的通信，本质上是状态（State）如何在两者之间流动的问题。LangGraph官方文档明确定义了两种通信模式。

14. **模式一：子图作为节点（共享状态模式）**

适用场景：父图和子图共享状态字段，子图直接从父图的同一个状态通道（channel）中读写数据。

实现方式：将编译好的子图直接传给父图的 add\_node\(\)，无需任何包装函数。

典型应用：多Agent系统中，各Agent通过共享的 messages 字段进行交流。

```Plain Text
from langgraph.graph import StateGraph, START, END, MessagesState

# ========== 子图：共享 MessagesState ==========sub_builder = StateGraph(MessagesState)
sub_builder.add_node("process", lambda state: {"messages": [AIMessage("处理完成")]})
sub_builder.add_edge(START, "process")
sub_builder.add_edge("process", END)
subgraph = sub_builder.compile()

# ========== 父图：子图作为节点 ==========builder = StateGraph(MessagesState)  # 父图和子图共享 MessagesStatebuilder.add_node("sub_task", subgraph)  # 直接传入编译好的子图
builder.add_edge(START, "sub_task")
builder.add_edge("sub_task", END)
graph = builder.compile()
```

15. **模式二：节点内调用子图（状态转换模式）**

适用场景：父图和子图没有共享字段，状态Schema完全独立。

实现方式：在父图节点函数中手动调用 subgraph\.invoke\(\)，进入子图前做状态转换，子图返回后再做状态转换写回父图。

典型应用：多Agent系统中，每个Agent保持私有消息历史，不与其他Agent共享。

```Plain Text
from typing_extensions import TypedDict

# ========== 子图：独立 Schema ==========class SubgraphState(TypedDict):
    query: strresult: strdef search_node(state: SubgraphState):
    return {"result": f"搜索: {state['query']} 的结果"}

sub_builder = StateGraph(SubgraphState)
sub_builder.add_node("search", search_node)
sub_builder.add_edge(START, "search")
subgraph = sub_builder.compile()

# ========== 父图：独立 Schema ==========class ParentState(TypedDict):
    question: stranswer: strdef call_subgraph(state: ParentState):
    # ① 父图状态 → 子图输入
    sub_input = {"query": state["question"]}
    # ② 调用子图
    sub_output = subgraph.invoke(sub_input)
    # ③ 子图输出 → 父图状态
    return {"answer": sub_output["result"]}

builder = StateGraph(ParentState)
builder.add_node("call_subgraph", call_subgraph)
builder.add_edge(START, "call_subgraph")
graph = builder.compile()
```

两种模式对比：

## 1\.44\. **LangGraph 子图支持哪三种持久化模式？**

子图被调用时，它的内部状态在两次调用之间如何保留？这由子图 compile\(\) 时的 checkpointer 参数决定，有三种模式：

Per\-invocation 适合大多数场景（含多 Agent 中子 Agent 处理独立请求）；per\-thread 用于子 Agent 需要在多轮对话里积累上下文的情况（如逐步建立上下文的研究助手）；stateless 用于纯计算、无状态的子流程。

特别注意：要让子图的持久化特性（中断、状态查看、per\-thread 记忆）真正生效，父图必须也用 Checkpointer 编译，如果父图不带 Checkpointer，子图持久化无从谈起。

案例：子图维护一个私有字段 visit\_count，对比三种模式下的累积情况。

```Plain Text
from typing import TypedDict

from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import StateGraph, START, END


class SubgraphState(TypedDict):"""子图状态：result 与父图共享，visit_count 是子图私有字段"""
    result: str # 子图结果
    visit_count: int # 子图被访问的次数def sub_node(state: SubgraphState) -> dict:"""子图节点：累加私有字段 visit_count，把结果写回共享字段 result"""
    count = state.get("visit_count", 0) + 1return {"visit_count": count, "result": f"第 {count} 次访问"}


# 构建子图
subgraph_builder = StateGraph(SubgraphState)
subgraph_builder.add_node("sub_node", sub_node)
subgraph_builder.add_edge(START, "sub_node")
subgraph_builder.add_edge("sub_node", END)
subgraph = subgraph_builder.compile(checkpointer=None)
# subgraph = subgraph_builder.compile(checkpointer=True)# subgraph = subgraph_builder.compile(checkpointer=False)class ParentState(TypedDict):"""主图状态：仅共享 result 字段"""
    result: str# 构建主图
builder = StateGraph(ParentState)
builder.add_node("consultant", subgraph)
builder.add_edge(START, "consultant")
builder.add_edge("consultant", END)
graph = builder.compile(checkpointer=MemorySaver())


# 连续调用三次主图，观察子图私有字段是否跨调用累积
config = {"configurable": {"thread_id": f"thread001"}}

for i in range(3):
    result = graph.invoke({"result": ""}, config=config)
    print(f"{result}")
```

依次设置“subgraph\_builder\.compile\(checkpointer=None\)”中checkpoint为None、True、False，查看结果如下：

```Plain Text
#Per-invocation：checkpoint =None
{'result': '第 1 次访问'}
{'result': '第 1 次访问'}
{'result': '第 1 次访问'}

#Per-thread：checkpoint=True
{'result': '第 1 次访问'}
{'result': '第 2 次访问'}
{'result': '第 3 次访问'}

#Stateless:checkpoint=False
{'result': '第 1 次访问'}
{'result': '第 1 次访问'}
{'result': '第 1 次访问'}
```

以上代码注意：

1. per\-invocation 下每次都是"第 1 次咨询"，子图每次调用从空白开始；per\-thread 下 visit\_count 跨调用累积，第二次变成"第 2 次咨询"，这就是子 Agent 多轮记忆的实现基础。

2. stateless 与 per\-invocation 在这个例子里的表现一致（visit\_count 每轮都从 0 重算），区别在于 stateless 不支持 interrupt 和持久化，而 per\-invocation 在单次调用内仍支持（子图里可以用 interrupt\(\) 暂停）。

## 1\.45\. **主图子图中如何定义共享变量和各自私有状态变量？**

在 LangGraph 中，子图和父图之间的状态共享基于一个简单规则：字段名（Field Name）是共享的唯一标识。只要父子图的 State Schema 中包含同名字段，该字段就会被共享；反之，仅在一方 Schema 中出现的字段，就是该方的私有字段。

3. **共享变量（Shared Fields）**

在父图和子图的 TypedDict 中都声明了同名字段，这些字段的数据在父子图之间共享，任何一方对它的修改都会影响另一方。

```Plain Text
from typing_extensions import TypedDict

# 父图 Schemaclass ParentState(TypedDict):
    messages: list   # 共享字段：父子图都有 messages
    description: str # 共享字段：父子图都有 description# 子图 Schemaclass SubgraphState(TypedDict):
    messages: list   # 共享字段：与父图 messages 共享
    description: str # 共享字段：与父图 description 共享
    note: str        # 私有字段：父图没有，仅子图内部可见
```

4. **私有变量（Private Fields）**

只在子图 Schema 中声明、父图 Schema 中没有的字段，就是子图私有字段。这些字段的数据不会进入父图状态，也不会出现在父图的最终输出中，仅在子图内部可用。

同样，只在父图 Schema 中声明、子图 Schema 中没有的字段，就是父图私有字段。这些字段的数据不会进入子图状态，也不会出现在子图的最终输出中，仅在父图内部可用。

```Plain Text
# ========== 父图 Schema ==========class ParentState(TypedDict):
shared_field: str        # 共享字段：子图也有  
parent_private: int      # 父图私有：子图没有同名字段# ========== 子图 Schema ==========class SubgraphState(TypedDict):
    shared_field: str        # 共享字段：父图也有
    sub_private: list        # 子图私有：父图没有同名字段
    internal_flag: bool      # 子图私有：父图没有同名字段
```

## 1\.46\. **模型并发限流方案**

**场景**：你有一个批量处理任务（1000条数据），调用的是高并发敏感的推理模型，且服务商仅允许 20 req/min。请设计一套既保证不触发限流，又能兼顾任务执行效率的方案。

该场景可以通过以下方案实现：

5. **计算请求速率**

服务商限制是20 raq/min ，由于服务商的计数窗口、网络延迟和重试请求都可能导致边界超限，所以我们可以设置访问服务商限制为18raq/min。这样每次请求大约间隔3\.33秒（18raq/60s≈0\.3req/s），1000个数据请求理论耗时下限约为55\.6分钟（1000/18≈55\.6分钟）。

6. **设置请求速率**

根据以上分析，可以将模型请求的速率设置为0\.3，LangChain中提供了 InMemoryRateLimiter，可以设置“requests\_per\_second”参数为0\.3，该参数表示每10秒允许3个请求。

7. **设置短时间突发请求**

如果是实时请求，还可以设置“max\_bucket\_size”参数允许短时间突发请求，应对流量小高峰。

8. **设置客户端并发参数**

除了设置“requests\_per\_second”外，在调用大模型时还需要设置“max\_concurrency”参数，该参数限制当前可运行对象的最大并发运行数，防止对API接口或本地资源造成过大压力，调用大模型的并发可以根据如下公式进行大约测算（最好结合实际压测结果调整）：

```Plain Text
所需并发数 ≈ 目标请求速率 × 单次请求耗时
即（本案例中假设单次请求耗时10秒）：
所需并发数 = 18/60 *10 ≈ 3~4
```

9. **并发请求调用及错误处理**

可以使用batch\_as\_completed\(\)处理1000个请求，边完成边处理，可以给每条请求设置索引、输入内容、模型结果、错误次数、重试次数等记录，结果完成后立即落盘，这样任务运行到一半，即使任务停止，根据记录的结果也不需要重新处理。

对于 429（Too Many Requests）、超时和 5xx \(服务端错误\)等临时错误采用指数退避重试，对于参数错误、权限错误等永久错误直接记录失败。

如果服务部署在多个进程或容器中，不能使用单机内存限流器，而应该使用 Redis 等共享存储实现全局限流，确保所有 Worker 合计不超过 18req/min，具体实现如下：

将所有进程、容器和Worker共享同一个Redis限流器。每个Worker在调用模型前，先通过Redis的原子操作申请令牌，Redis以provider:model或账号作为Key，统一记录最近一分钟已经发出的请求数；如果当前计数已达到18，Worker就等待下一个时间窗口再申请，只有成功获取令牌的请求才能调用模型，同时每个Worker仍使用max\_concurrency控制本地并发数，这样，虽然任务分布在多个进程或容器中执行，但所有请求都经过同一个Redis全局计数器，整体请求量不会超过服务商限制。

10. **总体方案流程**

![12wnIjMU\.jpg](图片和附件/12wnIjMU.jpg)

11. **最终代码示例**

```Plain Text
# 服务商限制为 20 req/min，客户端设置为 18 req/min，预留安全余量
rate_limiter = InMemoryRateLimiter(
    requests_per_second=18 / 60, # 每10s允许3个请求
    check_every_n_seconds=0.1, # 每100毫秒检查一次
    max_bucket_size=1, # 允许短时间突发的请求个数，应对流量小高峰
)

# 使用 DeepSeek v4 Flash
model = init_chat_model(
    model="deepseek-v4-flash",
    model_provider="deepseek",
    api_key=DEEPSEEK_API_KEY,
    rate_limiter=rate_limiter,
    extra_body={
        "thinking": {
            "type": "disabled",
        },
    },
)
... ...
model.batch_as_completed(
        pending_inputs,
        config={
            # 控制同时执行的请求数量"max_concurrency": 4,
        },
    )
... ...
```

注意：

1. rate\_limiter 控制的是单位时间内最多发出多少个请求；max\_concurrency 控制的是同时有多少个请求处于执行状态。max\_concurrency 不是用来突破 20 req/min 的，而是用来控制同一时间有多少个请求处于执行状态，避免客户端连接堆积、内存使用增大、CPU飙升问题

2. InMemoryRateLimiter只能在单进程内共享。如果部署多个进程、多个容器或多个 Worker，必须使用Redis等共享存储实现分布式限流，否则每个进程各自限流后，总请求量仍然可能超过 20 req/min。

## 1\.47\. **Agent调用工具死循环问题**

场景：如果Agent陷入死循环（比如问天气，反复调用搜索工具，搜了5次还没有结果），提示词能不能处理？线上如何强制熔断？

提示词中可以设置“最多调用工具N次”，能够降低模型重复调用工具的概率，但不能保证模型一定遵守，因为模型输出本质上是概率性的，工具服务异常、工具返回信息不清晰、模型误判，都可能导致它继续调用工具。

生产环境中对于Agent调用工具死循环问题可以采用如下4层熔断机制：工具调用次数限制\-\>模型调用次数限制\-\>recursion\_limit兜底\-\>超时防卡死。

3. **Agent中设置 ToolCallLimitMiddleware**

LangChain 提供了 ToolCallLimitMiddleware，可以限制全部工具或某个指定工具的调用次数，超过限制会直接抛出 ToolCallLimitExceededError，不会继续让 Agent 循环。

```Plain Text
... ...
create_agent(
        model=deepseek_llm_flash,
        tools=[search_weather],
        middleware=[
            ToolCallLimitMiddleware(
                tool_name="search_weather",
                run_limit=5, #单次运行最大调用次数
                exit_behavior="error",
            ), # 单次运行中，search_weatcher最多执行5次
        ],
        system_prompt=(
            "你是天气查询助手。""如果天气工具返回 not_found，不要重复使用完全相同的参数盲目查询。""最多查询 5 次，达到上限后直接向用户说明暂时无法获取可靠结果。"
        ),
    )

... ...
```

以上这个代码中ToolCallLimitMiddleware参数解释如下：

```Plain Text
ToolCallLimitMiddleware(
    tool_name: str | None = None,        # 限制的特定工具名，None 表示限制所有工具
    thread_limit: int | None = None,     # 线程级最大调用次数
    run_limit: int | None = None,        # 单次运行最大调用次数
    exit_behavior: str = "continue"      # 超限后的处理行为
)
```

exit\_behavior有三种值可选：

注意：如果还希望限制同一个会话中所有轮次的工具调用次数，可以设置 thread\_limit，需要配置checkpointer。

4. **Agent中设置ModelCallLimitMiddleware**

ModelCallLimitMiddleware 是 LangChain v1\.0 引入的一个预置中间件（Pre\-built Middleware），用于限制 Agent 在单个线程（Thread）或单次运行（Run）中对大语言模型（LLM）的调用次数，它的核心目的是防止模型调用次数失控，从而控制成本、避免 API 限流，并防止 Agent 陷入无休止的推理循环。

```Plain Text
... ...
create_agent(
        model=deepseek_llm_flash,
        tools=[search_weather],
        middleware=[
            ToolCallLimitMiddleware(
                tool_name="search_weather",
                run_limit=5, #单次运行最大调用次数
                exit_behavior="error",
            ), # 单次运行中，search_weatcher最多执行5次
            ModelCallLimitMiddleware(
                run_limit=8,
                exit_behavior="error",
            ) #单次运行中模型最多调用8次
        ],
        system_prompt=(
            "你是天气查询助手。""如果天气工具返回 not_found，不要重复使用完全相同的参数盲目查询。""最多查询 5 次，达到上限后直接向用户说明暂时无法获取可靠结果。"
        ),
    )

... ...
```

以上这个代码中ModelCallLimitMiddleware的参数解释如下：

```Plain Text
ModelCallLimitMiddleware(
    thread_limit: int | None = None,    # 线程级最大模型调用次数，None 表示无限制
    run_limit: int | None = None,       # 单次运行最大模型调用次数，None 表示无限制
    exit_behavior: Literal['end', 'error'] = 'end'  # 超限后的处理行为
)
```

exit\_behavior 两种模式如下;

注意：如果还希望限制同一个会话中所有轮次大模型调用次数，可以设置 thread\_limit，需要配置checkpointer。

5. **LangGraph中设置recursion\_limit**

recursion\_limit 是 LangGraph 中的一个安全控制参数，用于限制图（Graph）在单次执行过程中允许执行的最大超级步（Super\-step） 数量\.LangGraph 的核心执行模型可能是循环的：节点执行 → 状态更新 → 路由到下一个节点 → 继续执行。如果没有限制，一个设计不当的图可能永远执行下去（例如：节点 A → 节点 B → 节点 A → 节点 B……）。

recursion\_limit 充当断路器：当图执行的超级步数达到该限制时，LangGraph 会立即抛出 GraphRecursionError 异常，终止执行

LangGraph 的 recursion\_limit 默认值为10007。这意味着，如果一个图在执行了 10007 个超级步后仍未到达 END 节点，就会触发错误。

```Plain Text
result = graph.invoke(
        initial_state,
        config={
            # 这是图的 super-step 限制，不等于工具调用次数
            "recursion_limit": 100
        },
    )
```

注意：一些基于 LangGraph 构建的高级框架中recursion\_limit默认值不同。例如，LangChain中create\_agent中的Agent该参数默认值为9999，create\_deep\_agent中的Agent该参数默认值为9999。

此外，在langgraph中recursion\_limit不等同于调用工具次数，所以如果要精准控制某个工具调用次数还可以维护状态，调用一次工具后状态值累加，然后在条件边中判断如果达到一定次数后路由到END节点，recursion\_limit只作为兜底。

```Plain Text
class State(TypedDict):
    messages: list
search_count: int... ...
def route_after_search(state: State):# 搜索次数达到上限，直接结束if state["search_count"] >= 5:
        return END
    return "agent"
```

6. **设置工具请求超时**

调用次数限制只能防止逻辑死循环，不能解决单次工具请求一直不返回的问题。线上还需要增加任务级超时：

```Plain Text
import asyncio

async def invoke_with_timeout(agent, payload):try:
        return await asyncio.wait_for(
            agent.ainvoke(payload),
            timeout=30,
        )
    except asyncio.TimeoutError:
        return {
            "status": "timeout",
            "message": "Agent 执行超过 30 秒，已自动终止",
        }
```

当然也可以在langgraph中设置工具节点的超时控制：

```Plain Text
# 先设置全局默认值（超时仅适用于异步节点）builder.set_node_defaults(    # 全局默认值：所有节点共享的重试策略和超时策略retry_policy=RetryPolicy(max_attempts=2),    # 全局默认值：所有节点共享的超时策略timeout=TimeoutPolicy(run_timeout=30),    # 全局默认值：所有节点共享的错误处理器error_handler=default_error_handler,  # 全局默认错误处理器)
```

对于Anget调用工具死循环总体处理流程：

![xGKD1nty\.jpg](图片和附件/xGKD1nty.jpg)

代码示例：

```Plain Text
import asyncio
import time
from typing import Anyfrom langchain.agents import create_agent
from langchain.agents.middleware import (
    ModelCallLimitMiddleware,
    ToolCallLimitMiddleware,
)
from langchain.agents.middleware.model_call_limit import (
    ModelCallLimitExceededError,
)
from langchain.agents.middleware.tool_call_limit import (
    ToolCallLimitExceededError,
)
from langchain.tools import tool
from langgraph.errors import GraphRecursionError

from init_llm import deepseek_llm_flash


@tool("search_weather")def search_weather(city: str) -> dict[str, Any]:"""
    查询指定城市的天气信息。
    """# 模拟天气服务没有返回结果。# 真实项目中这里应该调用天气 API，并设置 HTTP 请求超时。
    time.sleep(5)
    return {
        "status": "not_found",
        "city": city,
        "message": "暂时没有找到该城市的可靠天气数据",
    }


def build_agent():"""
    创建带有多层安全限制的 Agent。
    """# 第一层：限制指定工具的调用次数
    tool_call_limit = ToolCallLimitMiddleware(
        tool_name="search_weather",
        run_limit=3,
        exit_behavior="error",
    )

    # 第二层：限制单次运行中的模型调用次数
    model_call_limit = ModelCallLimitMiddleware(
        run_limit=2,
        exit_behavior="error",
    )

    agent = create_agent(
        model=deepseek_llm_flash,
        tools=[search_weather],
        middleware=[
            tool_call_limit,
            model_call_limit,
        ],
        system_prompt=(
            "你是天气查询助手。""当用户询问天气时，可以调用 search_weather 工具。""单次任务最多调用天气工具 1 次。""如果工具返回 status=not_found，""不要使用完全相同的参数重复查询。""如果多次查询仍然没有结果，""直接告诉用户暂时无法获得可靠天气信息。"
        ),
    )

    return agent


async def invoke_agent_with_timeout(
    agent,
    payload: dict[str, Any],
) -> dict[str, Any]:"""
    使用任务级超时调用 Agent。
    """try:
        result = await asyncio.wait_for(
            agent.ainvoke(
                payload,
                config={
                    # 第三层：限制 LangGraph 图执行的最大 super-step 数量# 注意：它不是工具调用次数限制"recursion_limit": 20,
                },
            ),
            timeout=3, #单位是秒
        )

        return {
            "status": "success",
            "result": result,
        }

    except ToolCallLimitExceededError as exc:
        # 第一层熔断：工具调用次数超过限制return {
            "status": "tool_call_limit",
            "message": "天气搜索工具调用次数超过上限，任务已熔断。",
            "tool_name": exc.tool_name,
            "run_count": exc.run_count,
            "run_limit": exc.run_limit,
        }

    except ModelCallLimitExceededError as exc:
        # 第二层熔断：模型调用次数超过限制return {
            "status": "model_call_limit",
            "message": "模型调用次数超过上限，任务已熔断。",
            "run_count": exc.run_count,
            "run_limit": exc.run_limit,
        }

    except GraphRecursionError:
        # 第三层熔断：LangGraph super-step 数量超过限制return {
            "status": "recursion_limit",
            "message": "Agent 图执行步数超过上限，任务已熔断。",
        }

    except asyncio.TimeoutError:
        # 第四层熔断：整个 Agent 任务执行超时return {
            "status": "timeout",
            "message": "Agent 执行超过 30 秒，任务已终止。",
        }


async def main() -> None:
    agent = build_agent()

    payload = {
        "messages": [
            {
                "role": "user",
                "content": "分别依次查询北京、上海、广州今天的天气。",
            }
        ]
    }

    result = await invoke_agent_with_timeout(agent, payload)

    print("任务状态：", result["status"])
    print("任务结果：", result)


if __name__ == "__main__":
    asyncio.run(main())
```

以上代码运行测试：

1. 当 ToolCallLimitMiddleware 设置小于3次时，工具调用次数超过上限，任务会熔断

2. 当 ModelCallLimitMiddleware 设置小于2次时，模型调用次数超过上限，任务会熔断

3. 当 recursion\_limit 设置为比较小的数字时（例如 recursion\_limit=2），图执行步数超过上限，任务会熔断

4. 当在工具中设置sleep 5秒且invoke的时候设置timeout是3秒时，会出现timeout的情况，任务会熔断

## 1\.48\. **Agent上下文超限优化**

**业务场景**：构建了一个Agent助手，该Agent工作模式是用户可以上传多个文件，可以根据这些文件进行多轮对话，对话内容可能涉及到文件内容，也可能不涉及文件内容，现在问题是多轮对话中（超过5轮）经常出现上下文长度超限报错（400 Bad Request \- context\_length\_exceeded），如何优化？

面对该场景，可以从以下几个方面优化上下文。

5. **避免将整个文件读取作为上下文**

整个文件读取后作为上下文很容易撑爆上下文，所以上传的大文件走 RAG（向量检索），用户提问时，先检索相关片段带入上下文。此外，使用模型额外对文件生成全局摘要存储到长期记忆中，对于用户“总结全文”类问题也可以检索到全局内容。

6. **压缩工具返回结果**

如果Agent一些工具返回超大结果集（如：超大 JSON/表格），不直接返回。

7. **场景A：根据工具返回内容的结论回复用户**

这种情况可以在工具中调用轻量模型（如 qwen\-turbo）生成内容摘要/数据统计摘要，把摘要作为消息结果返回。

8. **场景B：获取工具返回的详细内容**

如果用户对话要求返回详细的内容，可以基于场景A的情况下，将详细内容存储到外部文件，然后将内容摘要和存储到的外部文件地址返回给用户。

9. **场景C：工具返回大量数据，后续根据数据进行分析**

对于返回大量数据后续分析的场景，可以改变思路，先处理数据得到相应结果，然后再编写工具，工具只是查询数据分析后的结果，而并不是加载所有数据交给大模型处理。

10. **对于多轮对话设置消息摘要**

消息摘要方式通过 LLM 生成对话历史的浓缩摘要，替代原始的旧消息，既减少了 token 占用，又保留了核心上下文。

Summarize Message（消息摘要）是通过LangChain中的内置SummarizationMiddleware中间件进行完成，该中间件可以自动压缩对话历史，通过生成摘要替代旧消息，在保留关键上下文的同时减少 token 消耗，使用方式如下：

```Plain Text
agent = create_agent(
    model="gpt-4.1",
    tools=[...],
    middleware=[
        SummarizationMiddleware(
            model="gpt-4.1-mini",  # 摘要生成模型
            trigger=("tokens", 4000),  # 触发条件：token ≥4000
            keep=("messages", 20)  # 保留最近20条消息
        ),
    ],
)
```

11. **多轮对话摘要超限**

随着对话轮数增加，摘要信息越来越大，也有可能超过上下文大小，可以考虑将上下文摘要信息定期持久化存储到向量数据库中，可以在@after\_model中每隔一定对话轮数，将摘要信息存储在向量数据库中，然后清空摘要，需要注意ToolMessage和AIMessage的连贯性，后续每次对话可以先根据用户提问匹配向量数据库摘要内容，经过大模型总结后作为上下文信息。

这里涉及到自定义摘要，具体落地示例如下：

12. **维护一个“摘要树”栈（热存储）**

在 Agent 的短期记忆（State）中，维护一个摘要列表 summary\_stack：

第 5 轮结束后，生成摘要 A，放入列表：\[A\]

第 10 轮结束后，生成摘要 B，放入列表：\[A, B\]

第 15 轮结束后，生成摘要 C，放入列表：\[A, B, C\]

触发合并阈值：当列表长度 == 3 时（即 A、B、C 齐全），触发异步合并任务。

13. **合并生成“父摘要”（冷存储入库）**

调用轻量级模型（如 qwen\-turbo），输入提示词如：“请将以下三段对话摘要合并成一段更精炼的全局摘要，保留最关键的人物、事件和结论：\\n摘要A：\.\.\.\\n摘要B：\.\.\.\\n摘要C：\.\.\.”，生成父摘要 D。

将父摘要 D 进行向量化，存入向量数据库，将 summary\_stack 清空，并放入 D 作为新的起点（即列表变为 \[D\]），这样向量库里永远只有少而精的层级节点，用户检索历史时，命中的是高度概括的 D，而不是一堆重复的碎片 A、B、C。

注意：向量数据库中不存 A、B、C 的独立向量，避免向量库里碎片化摘要太多，检索时召回噪音过大。但可以单独将A、B、C进行归档向量化存储，后续检索细节时可以匹配这些摘要信息。

14. **设置长期记忆进行语义缓存**

也可以将每次用户提问问题和回复的结果作为k,v保存在数据库中，新的对话开始后，先匹配用户问题是否与过往对话的key相似，相似就找出之前的回复value，直接经过检索回复，避免调用多轮工具出现上下文过大问题。

注意：这种k,v存储只能保存无状态的纯知识问答（比如“公司退货政策是什么？、产品参数、政策条款”），对于查询类/操作类 Agent，绝对不能缓存用户问题的语义相似结果，可以通过模型语义识别来进行辨别是否查询过往的问题和答案。同时可以对于这种存储设置过期时间，比如1小时，查询不到后再正常Agent查询。

15. **设置多子Agent系统**

如果Agent中对话经常是长上下文，也可以根据业务逻辑拆分Agent为主子Agent系统，子Agent负责某些业务方向查询，主子Agent上下文隔离，子Agent执行完成后返回总结结果给主Agent并自动销毁，这样也可以分散单Agent长对话上下文压力。

## 1\.49\. **如何保证Agent分布式部署一致性**

场景：Agent 服务需要部署在5个Pod 上，每个Pod 都有自己的对话记忆，如何保证用户多端对话的连贯性、一致性？

16. **数据存储一致性：短期/长期记忆存储在数据库中且使用稳定的thread\_id**

多 Pod 部署时，不能把对话记忆只保存在每个 Pod 的内存中，而应该将 Agent 服务设计成无状态。所有 Pod 共用数据库型 Checkpointer，例如 PostgreSQL 或 MySQL，短期会话状态按照 thread\_id 保存，但也要存储在数据库中，不能使用InMemorySaver\(\)/InMemoryStore\(\)。

用户多端打开同一个对话时，服务端根据 tenant\_id（租户ID） \+ user\_id（用户ID） \+ conversation\_id（会话ID） 生成稳定的 thread\_id。无论请求被负载均衡到哪个 Pod，该 Pod 都会从共享 Checkpointer 恢复同一个 Agent State；新建对话则使用新的 conversation\_id 并生成新的thread\_id。

用户偏好等跨会话信息通过共享 Store 按 tenant\_id \+ user\_id 保存，这样多端访问同一个会话时，从共享 Checkpointer 恢复短期记忆；用户进入新会话时，可以从共享 Store 读取用户偏好。

17. **消息处理一致性：多端同时发消息保证消息处理一致性**

共享 Checkpointer 解决了“任意Pod能读取同一状态”，但不能自动解决：“手机端和Web端同时向同一个thread\_id发送消息”情况下可能产生的状态覆盖、消息乱序或重复工具操作。因此同一个thread\_id在同一时间只能有一个Agent任务执行，可以通过 Redis 分布式锁\+按thread\_id分区的消息队列保证同一会话串行执行。

- **为什么需要Redis分布式锁？**

分布式锁常用于在多个服务实例之间对某个资源（比如一个会话或线程）进行互斥访问。假设同一个对话（thread\_id = conversation\-001）当前状态如下：

```Plain Text
版本10
历史消息：用户正在查询订单ORD-001
```

用户同时从两个设备发送如下消息：

```Plain Text
手机端：帮我申请退款
Web端：先不要退款
```

请求被分到不同的Pod中（假设手机端请求发送到Pod\-1中；Web端请求发送到Pod\-3中），如果没有锁，就会出现如下情况：

```Plain Text
Pod-1读取版本10Pod-3也读取版本10Pod-1执行退款并写入版本11Pod-3也基于版本10继续执行并写入版本11
```

这样就会出现消息覆盖、上下文乱序、重复调用退款工具、最终状态和用户意图不一致等各种意外情况。

这种情况，可以针对每个thread\_id创建一个Redis分布式锁（agent:lock:conversation\-001），执行过程就变成如下：

```Plain Text
Pod-1尝试获取conversation-001的锁
→ 获取成功
→ Pod-1执行Agent

Pod-3也尝试获取同一个锁
→ 获取失败
→ 等待或进入队列

Pod-1执行完成
→ Checkpointer保存最新状态
→ Pod-1释放锁

Pod-3获得锁
→ 重新从Checkpointer读取最新状态
→ 此时已经能看到Pod-1的执行结果
→ 再执行下一条消息
```

这样通过redis分布式锁就形成了同一个thread\_id 串行执行，不同的thread\_id并行执行。

特别注意：

1. 分布式锁的粒度必须是thread\_id ,不能是整个Agent服务，否则不同对话无法并行执行。

2. Redis中获取分布式锁时可以执行如下命令

```Plain Text
# agent:lock:conversation-001 表示业务前缀:固定标记:具体thread_id#唯一标识由自己定义，可以设置全局唯一的随机字符串#NX 保证只有第一次设置成功（加锁）#EX 设置过期时间，防止死锁，超时时间是毫秒SET agent:lock:conversation-001 <唯一标识> NX EX <超时时间>
```

3. Redis锁一定要设置超时时间，因为某个pod获取锁之后可能崩溃导致锁无法释放，从而会导致对话无法继续，此外代码中还要实现锁的定期续租，否则锁到期释放会导致相同问题。

![5xbzzG2P\.jpg](图片和附件/5xbzzG2P.jpg)

- **为什么需要按thread\_id分区组织消息队列（FIFO）？**

Redis 锁只保证互斥，不保证严格 FIFO，如果业务要求严格按到达服务端的顺序处理，需要按照thread\_id来组织消息队列，依次执行来获取redis分布式锁并执行。

**3\.幂等操作：高风险操作设置幂等（防重）**

即使使用了分布式锁，Pod 仍可能在执行完成后、返回结果前崩溃，导致请求被重新执行,因此每次请求还要携带唯一request\_id做幂等，避免网络重试导致重复工具操作。在工具中可以使用request\_id 作为幂等键进行数据库幂等操作。

**综合回复如下：**

多 Pod 部署时，不能把对话记忆只保存在每个 Pod 的内存中，而应该将 Agent 服务设计成无状态。所有 Pod 共用数据库型 Checkpointer，例如 PostgreSQL 或 MySQL，短期会话状态按照 thread\_id 保存。

用户多端打开同一个对话时，服务端根据 tenant\_id \+ user\_id \+ conversation\_id 生成稳定的 thread\_id。无论请求被负载均衡到哪个 Pod，该 Pod 都会从共享 Checkpointer 恢复同一个 Agent State；新建对话则使用新的 conversation\_id 和 thread\_id。用户偏好等跨会话信息通过共享 Store 按 tenant\_id \+ user\_id 保存。

共享存储只能解决状态共享，不能解决同一会话并发写入。因此手机端和 Web 端同时向同一个 thread\_id 发消息时，还需要通过 Redis 分布式锁、按 thread\_id 分区的消息队列或数据库版本控制保证同一会话串行执行。每次请求还要携带唯一 request\_id 做幂等，避免网络重试导致重复工具操作。

## 1\.50\. **MCP 工具调用审计日志保存**

场景：你开发了一个 MCP Server 暴露了一些工具，现在需要在不修改Server代码的前提下实现工具调用审计日志（谁、什么时候、调用了什么工具、参数是什么），怎么设计实现？

在不修改 MCP Server 代码的前提下，如果所有调用都经过 LangChain Agent，可以在 MultiServerMCPClient 上配置 tool\_interceptors，实现客户端侧的统一审计。拦截器接收 MCPToolCallRequest 和 handler，调用前记录 [request\.name](http://request.name/)、request\.args、request\.server\_name、调用时间、tool\_call\_id 以及从 request\.runtime\.context 获取的 user\_id、tenant\_id 和 request\_id；调用 handler 后再记录结果状态、异常和耗时。参数需要脱敏后写入 Kafka、Elasticsearch 或审计数据库。

拦截器只负责客户端调用审计，不是最终权限边界，MCP Server 和后端业务系统仍然必须做最终认证授权。

如果远程 MCP Server 还可能被其他客户端直接访问，那么单个 LangChain Client 的拦截器无法覆盖全部调用，此时应在 MCP Server 前增加 API Gateway 或 MCP Proxy，统一记录所有 tools/call 请求。简单来说：LangChain Tool Interceptor 适合审计当前 Agent 的调用，Gateway/Proxy 适合审计远程 MCP Server 的全量调用。

## 1\.51\. **企业Agent应用完整安全防护体系设计**

业务场景：企业级 LangChain Agent \+ MCP 应用如何设计完整的认证、授权与安全访问流程？

构建大模型 Agent 应用时，可以将 Agent 系统的安全架构划分为边界安全、认证、授权、审计、加密五个维度，构建端到端的安全防护体系。其中认证和授权是鉴权核心，边界安全、审计、加密是横向安全能力。

![aBnK148h\.jpg](图片和附件/aBnK148h.jpg)

4. **边界安全（Permeter Security）**

边界安全是第一道防线，但不是唯一防线。边界安全假设“坏人”在外面，但大多数破坏性行为往往来自内部，认证和授权才是真正的核心。

**核心目标**：确保只有合法的网络流量能到达 Agent 服务。

**实现方式**：Agent 服务通过 API Gateway 对外暴露，配置 IP 白名单；强制 HTTPS通信（TLS，https://格式访问），保证传输层加密。

5. **认证（Authentication）**

认证是授权的基础，没有身份认证的授权是有漏洞的，因为攻击者可以冒充他人身份访问资源。

**核心目标**：验证“你是谁”，确认请求发起者的合法身份。

**实现方式**：用户输入用户名和密码，经过验证后登录系统，通过验证用户可以使用Agent应用。同时在RuntimeContext中注入身份，例如：

```Plain Text
# 认证通过后，用户信息会被注入到后续所有节点的上下文中，供工具和中间件使用：@dataclassclass AgentContext:"""由服务端认证后生成的可信身份上下文"""
    tenant_id: str #租户ID
    user_id: str #用户ID
    username: str #用户姓名
    roles: list[str] #用户角色
    scopes: list[str] #用户权限，记录用户可以访问内容
    request_id: str #本次请求ID... ....

def chat(token_claims: dict, thread_id: str, message: str, request_id: str):# 1. 从认证结果中提取身份，来自 JWT，非客户端传参
    tenant_id = token_claims["tenant_id"] 
    user_id = token_claims["user_id"]   
    user_name = token_claims["user_name"]   
    roles = token_claims.get("roles", [])
    scopes = token_claims.get("scopes", [])

    # 2. 会话级授权if not check_thread_permission(tenant_id, user_id, thread_id):
        raise PermissionError("当前用户无权访问该会话")

    # 3. 构造可信 Runtime Context
    context = AgentContext(
        tenant_id=tenant_id,
        user_id=user_id,
        user_name=user_name,
        roles=roles,
        scopes=scopes,
        request_id=request_id,
    )

    # 4. 执行 Agentreturn agent.invoke(
        {"messages": [{"role": "user", "content": message}]},
        config={"configurable": {"thread_id": thread_id}},
        context=context,
    )
```

以上同时进行用户是否对当前thread\_id有权访问，这在同一个thread\_id 恢复中很重要：

```Plain Text
#先校验权限，再使用 thread_iddef check_thread_permission(tenant_id: str, user_id: str, thread_id: str) -> bool:
    result = db.query(
        "SELECT 1 FROM conversations ""WHERE thread_id = :thread_id ""AND tenant_id = :tenant_id ""AND user_id = :user_id",
        {"thread_id": thread_id, "tenant_id": tenant_id, "user_id": user_id}
    )
    return result is not None
```

6. **授权\(Authorization\)**

传统系统的行为是确定的（用户点击“查看订单”→ 系统校验权限 → 返回数据），但 Agent 的行为是非确定性的——它会自主决定调用哪些工具、以什么参数调用。这意味着授权必须嵌入到 Agent 的执行路径中，而不是只在入口处检查一次。

**核心目标**：验证“你能做什么”，根据用户身份决定 Agent 可以调用哪些工具、访问哪些数据。

**具体实现**可以采用三层授权架构：

**第一层：入口工具过滤**

在 Agent 执行前，根据用户角色动态裁剪工具列表，让模型只看到用户有权调用的工具。

```Plain Text
@wrap_model_calldef role_based_tool_filter(request: ModelRequest, handler):
    user_role = request.runtime.context.get("roles")
  
    if user_role == "employee":
        # 普通员工：只有只读工具
        allowed_tools = ["search_documents", "read_document"]
        filtered = [t for t in request.tools if t.name in allowed_tools]
        request = request.override(tools=filtered)
  
    return handler(request)
```

这种设置方式，模型根本不知道无权限工具的存在，不会尝试调用；减少上下文Token消耗；比工具内部抛异常更优雅。

**第二层：工具级\+数据级过滤**

工具执行时，从 runtime\.context 读取可信身份，进行细粒度权限校验。用户身份必须来自认证层注入的上下文，绝对不能从模型输出或客户端参数中读取。

```Plain Text
@tooldef query_order(order_id: str, runtime: ToolRuntime) -> str:# 从可信上下文读取用户身份
    user_id = runtime.context.user_id
    tenant_id = runtime.context.tenant_id
  
    # 工具级授权：检查用户是否有“查询订单”权限if "order:read" not in runtime.context.scopes:
        raise PermissionError("无订单查询权限")
  
    # 数据级授权：查询时自动追加租户和用户过滤
    order = db.query(
        "SELECT * FROM orders ""WHERE order_id = :order_id ""AND tenant_id = :tenant_id ""AND user_id = :user_id",
        {"order_id": order_id, "tenant_id": tenant_id, "user_id": user_id}
    )
    return order
```

**第三层：HITL人工审批**

对于高风险操作（删除数据、退款、发送通知），引入人工审批作为最后一道防线：

```Plain Text
agent = create_agent(
    model=llm,
    tools=[...],
    middleware=[
        HumanInTheLoopMiddleware(
            interrupt_on={
                "delete_document": True,
                "process_refund": True,
                "send_broadcast": True,
            }
        ),
    ],
)
```

对于 MCP Server，需要在适配器层和 Server 层分别做授权：

- MCP 工具拦截器：在 LangChain Client 端注入用户身份到参数

- MCP Server 鉴权：HTTP Server 模式支持 OAuth 2\.1，独立校验 Token

7. **审计\(Audit\)**

**核心目标**：记录“你做了什么”，所有 Agent 操作都可追溯。

**实现方式**：Agent 的审计比传统应用更复杂：一次用户提问可能触发多次工具调用、多次数据访问。审计日志需要记录完整的调用链。

```Plain Text
async def audit_log_interceptor(request: MCPToolCallRequest, handler):
    user_id = request.runtime.context.user_id
    log_entry = {
        "user_id": user_id,
        "tool": request.name,
        "args": request.args,
        "timestamp": datetime.now().isoformat(),
        "request_id": request.runtime.context.request_id,
    }
    await audit_service.log({"action": "tool_call_start", **log_entry})
  
    try:
        result = await handler(request)
        await audit_service.log({"action": "tool_call_success", **log_entry})
        return result
    except Exception as e:
        await audit_service.log({"action": "tool_call_failed", "error": str(e), **log_entry})
        raise
```

注意：MCP 中可以设置拦截器完成日志审计；普通工具中在中间件（@wrap\_tool\_call等）中完成日志审计。

8. **加密\(Encrypt\)**

**核心目标**：防止数据在传输或存储过程中被窃取/破解。

**实现方式**：传输加密\-所有对外暴露的端点强制 HTTPS，如MCP中使用MCP HTTP 传输加密；数据脱敏\-PII（个人身份信息）在输出前自动脱敏。

总体流程如下：

![JxEcSpHj\.jpg](图片和附件/JxEcSpHj.jpg)

## 1\.52\. **LangGraph中工具调用陷入死循环处理**

业务场景： Agent 在生产环境中突然出现循环调用工具的异常:LLM 反复调用同一个工具，每次都传入相同参数，既不给出最终答案也不停止。

recursion\_limit 是 LangGraph 中的一个安全控制参数，用于限制图（Graph）在单次执行过程中允许执行的最大超级步（Super\-step） 数量\.LangGraph 的核心执行模型可能是循环的：节点执行 → 状态更新 → 路由到下一个节点 → 继续执行。如果没有限制，一个设计不当的图可能永远执行下去（例如：节点 A → 节点 B → 节点 A → 节点 B……）。

recursion\_limit 充当断路器：当图执行的超级步数达到该限制时，LangGraph 会立即抛出 GraphRecursionError 异常，终止执行

LangGraph 的 recursion\_limit 默认值为10007。这意味着，如果一个图在执行了 10007 个超级步后仍未到达 END 节点，就会触发错误。

```Plain Text
result = graph.invoke(
        initial_state,
        config={
            # 这是图的 super-step 限制，不等于工具调用次数
            "recursion_limit": 100
        },
    )
```

注意：一些基于 LangGraph 构建的高级框架中recursion\_limit默认值不同。例如，LangChain中create\_agent中的Agent该参数默认值为9999，create\_deep\_agent中的Agent该参数默认值为9999。

此外，在langgraph中recursion\_limit不等同于调用工具次数，所以如果要精准控制某个工具调用次数还可以维护状态，调用一次工具后状态值累加，然后在条件边中判断如果达到一定次数后路由到END节点，recursion\_limit只作为兜底。

```Plain Text
class State(TypedDict):
    messages: list
search_count: int... ...
def route_after_search(state: State):# 搜索次数达到上限，直接结束if state["search_count"] >= 5:
        return END
    return "agent"
```

2\.设置工具超时





