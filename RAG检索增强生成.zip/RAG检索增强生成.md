# RAG检索增强生成

# RAG介绍与三种架构

## 1\.1\. RAG介绍

RAG 全称 Retrieval\-Augmented Generation，中文叫检索增强生成。它的核心是：在模型生成回答时，把运行时从外部知识源取得的相关证据提供给模型。最简单的实现是固定的“检索 → 生成”流程。

大模型的训练数据不会自动包含企业内部文档，也不能实时知道最新的产品规则、订单状态和业务数据。把这些信息直接写进模型参数，更新成本高；把所有资料一次性塞进 Prompt，上下文又会过长。**RAG 的作用就是在每次提问时，只找出当前问题真正需要的资料**。

RAG 没有让模型“记住”知识库，而是在模型回答前临时提供参考资料。知识更新时只需要更新知识库和索引，不需要重新训练模型。**RAG 不能保证模型一定回答正确，它只负责把更相关的证据交给模型，最终质量仍然受原始资料、文本切分、Embedding、检索策略、Prompt 和模型能力影响。**

## 1\.2\. RAG工作原理

RAG的工作原理如下：

![24kfLgUY\.jpg](图片和附件/24kfLgUY.jpg)

我们有自己的文档（url、pdf、txt、数据库等），这些文档就是用户本地的知识，经过解析处理为chunks（小块）文档，然后这些文档通过嵌入模型（Embedding Model）将这些文本信息转换成向量（Vector）,即转换成数学表示，这就是嵌入的含义，这些向量保存在向量数据库中，这个过程我们称为indexing\(索引\)。

当用户提出问题时，这些问题也会通过Embedding Model转换成向量，然后去向量数据库中去检索（Retrieve），检索到与问题相关的文档，然后把这些内容打包，结合提示词（Prompt）一起传递给大模型，这样大模型就有了如何回答该问题的上下文概念，结合大模型的推理能力，形成连贯答案返回给用户，这就是RAG工作流程。

### 1\.2\.1\. 余弦相似度

余弦相似度是一种衡量两个向量方向相似程度的度量方法，通过计算它们夹角的余弦值来评估相似性，广泛应用于文本分析、数据挖掘等领域。

余弦相似度的数学本质是向量空间模型中夹角的余弦值，计算公式为两个向量的点积除以它们的模长乘积。对于n维向量A和B，公式可表示为：

![4Zxu0Y8x\.jpg](图片和附件/4Zxu0Y8x.jpg)

其值范围在\-1到1之间，1表示完全相同，\-1表示完全相反，0表示无关。

余弦相似度典型应用场景如下：

- 文本相似度计算：将文档转化为词频向量后，通过余弦相似度比较内容相似性。

- 聚类分析：衡量数据点在高维空间中的分布方向是否相近，常用于推荐系统或异常检测。

在RAG中，我们可以将知识库内容切分后，通过Embedding Model（嵌入模型）转换成向量，然后存储在向量数据库中，当用户进行查询时，将用户的输入也转换成向量，然后使用余弦相似度找出与用户输入最相似的内容。

### 1\.2\.2\. 知识库构建流程（离线）

RAG 的第一部分是知识库构建，也叫 Indexing。这个过程通常离线执行，不会在每次提问时重新处理全部文档。知识库构建步骤如下：

1. 使用 Document Loader 读取 PDF、Word、Markdown、网页或数据库内容。

2. 将原始内容转换成 LangChain 的 Document对象。

3. 使用 Text Splitter 把长文档切成多个 chunk。

4. 使用 Embedding Model 把每个 chunk 转换成向量。

5. 将向量、原文和 metadata 保存到 Vector Store。

其中metadata用来保存来源、页码、产品、版本和租户等信息。它可以参与检索过滤和辅助权限判断，但 metadata filter 本身不是完整的权限边界；租户和权限条件必须由可信服务端根据认证上下文生成，并在文档进入模型上下文之前强制执行。

### 1\.2\.3\. 用户问答流程（在线）

构建的RAG用户提问后的在线流程如下：

1. 使用与文档向量处于兼容空间的 Embedding Model 将问题转换成向量。

2. Retriever 从 Vector Store 中召回相关文档。

3. 将文档内容整理成模型上下文。

4. Prompt 要求模型优先依据上下文回答，并在资料不足时拒答。

5. 模型生成答案，程序附加来源信息。

## 1\.3\. RAG与长上下文、微调的区别

三种方式解决的问题不同，不能互相简单替代。

如果问题是“模型不知道今天更新的退款规则”，优先使用 RAG；如果问题是“模型必须始终输出固定 JSON 格式”，优先考虑结构化输出或微调。**RAG 更适合补知识，微调更适合改行为**。

## 1\.4\. 三种RAG架构

LangChain 中将常见 RAG 架构归纳为 2\-Step RAG、Agentic RAG 和 Hybrid RAG三类，

### 1\.4\.1\. 构建RAG相关名词

后面的三种架构案例会使用 RAG 的六个基础组件和名词，这里先做简单了解，后续章节会逐个深入讲解。

该课程中我们使用千问“text\-embedding\-v1”作为Embedding Model，使用deepseek\-flash作为ChatModel，完成回答、决策、文档评估和问题改写。

### 1\.4\.2\. 2\-Step RAG

#### 1\.4\.2\.1\. 2\-Step RAG介绍

Step RAG 是最直接的 RAG 结构：流程固定先完成检索，再根据检索结果生成回答。这里的“2\-Step”强调两个阶段的固定顺序，不等于任何实现都只能调用一次 Retriever 或一次模型。

执行流程如下：

```Plain Text
用户问题 → Retriever → 相关文档 → Prompt → Model → 最终回答
```

2\-Step RAG 的优点是流程清楚、延迟稳定、容易测试。FAQ、内部制度查询、产品手册问答等场景，如果一次检索就能得到足够资料，优先使用这种方式。

它的限制也很明显：

- 用户问题表达不准确时，系统不会主动改写；

- 第一次召回的资料不相关时，系统仍可能继续生成。

#### 1\.4\.2\.2\. 2\-Step RAG使用案例

使用 LangChain 构建 2\-Step RAG 的步骤如下：

1. 创建或加载 Document。

2. 使用 Text Splitter 切分文档。

3. 创建 Embedding 和 Vector Store。

4. 通过 as\_retriever\(\) 得到 Retriever。

5. 调用 retriever\.invoke\(question\) 获取文档。

6. 将问题和文档交给 Prompt 与 Model。

下面构建一个退款到账查询案例。文档和问题使用千问 text\-embedding\-v1 生成语义向量，Retriever 固定检索一次，再把上下文交给LLM生成回答。

```Plain Text
# two_step_rag：固定执行一次Retriever，再把真实检索上下文交给 LLM 回答from langchain_core.messages import SystemMessage, HumanMessage

from env_utils import DASHSCOPE_API_KEY
from langchain_community.embeddings import DashScopeEmbeddings
from langchain_core.documents import Document
from langchain_core.vectorstores import InMemoryVectorStore
from langchain_text_splitters import RecursiveCharacterTextSplitter
from init_llm import deepseek_llm_flash


# ============================================================# 第一步：初始化千问Embedding模型# ============================================================
embedding_model = DashScopeEmbeddings(
    model="text-embedding-v1",
    dashscope_api_key=DASHSCOPE_API_KEY,
)


# ========================================================# 第二步：准备并切分知识库文档# ========================================================
documents = [
    Document(
        page_content="退货规则：收货后七日内可以申请无理由退货，商品、包装和配件需要保持完整。",
        metadata={"source": "售后规则.md"},
    ),
    Document(
        page_content="退款规则：仓库验收通过后发起原路退款，通常三个工作日内到账。",
        metadata={"source": "退款规则.md"},
    ),
    Document(
        page_content="物流规则：订单发货后可以在订单详情查看物流轨迹。",
        metadata={"source": "物流规则.md"},
    ),
]

splitter = RecursiveCharacterTextSplitter(
    chunk_size=80,
    chunk_overlap=12,
    separators=["\n\n", "\n", "。", "；", "，", ""],
)

chunks = splitter.split_documents(documents)
print("chunks:", chunks)

# ========================================================# 第三步：使用Embedding创建Retriever# ========================================================
vector_store = InMemoryVectorStore(embedding_model)
vector_store.add_documents(chunks)

retriever = vector_store.as_retriever(search_kwargs={"k": 1})

# ========================================================# 第四步：固定执行一次检索# ========================================================
question = "退款通常什么时候到账？"

retrieved_documents = retriever.invoke(question)
print("retrieved_documents:", retrieved_documents)

context = "\n\n".join(
    f"来源：{document.metadata['source']}\n{document.page_content}"for document in retrieved_documents
)

# ========================================================# 第五步：LLM 根据上下文生成回答# ========================================================
messages = [
    SystemMessage(content="你是售后助手。只能根据参考资料回答，资料不足时明确说明。"),
    HumanMessage(content=f"参考资料：\n{context}\n\n用户问题：{question}")
]

response = deepseek_llm_flash.invoke(messages)
answer = response.content


print("用户问题：", question)
print("检索片段数：", len(retrieved_documents))
print("\n\n检索上下文：")
print(context)
print("\n\n LLM 回答：")
print(answer)
```

以上代码运行结果如下：

![gRYADvTI\.jpg](图片和附件/gRYADvTI.jpg)

RecursiveCharacterTextSplitter的三个参数解释如下：

- chunk\_size=80：每个 Chunk 最多 80 个字符（注意是字符数，不是 token 数）。

- chunk\_overlap=12：相邻 Chunk 之间重叠 12 个字符，避免语义断裂。

- separators：按优先级顺序尝试分割的字符列表，优先用双换行、单换行、句号、分号、逗号，最后按字符切分。这样可以尽量保持语义完整性。

以上代码进一步解释如下：

1. 在 LangChain 的 Document 类设计中，只有 page\_content（文本内容）是固定必须存在的字段，而 metadata 是一个自由灵活的字典（Dict\[str, Any\]），可以往里面放任意键值对（key\-value）。

2. “chunks = splitter\.split\_documents\(documents\)”对 documents 列表中的每个文档进行切分，返回一个 Chunk 列表（每个 Chunk 也是 Document 对象，保留原元数据）。该示例文档很短（每条约 20\~30 字），且 chunk\_size=80，所以每个文档可能只生成一个 Chunk，但实际大文档会被切分成多个。

3. InMemoryVectorStore\(embedding\_model\)：初始化内存向量库，传入嵌入模型，它会在添加文档时自动调用嵌入模型生成向量。

4. add\_documents\(chunks\)：将所有 Chunk 的文本内容向量化并存入库中。

5. as\_retriever\(search\_kwargs=\{"k": 1\}\)：将向量库包装成检索器，并指定检索时返回 相似度最高的前 1 个 文档（k=1），检索默认使用余弦相似度。

6. 调用 retriever\.invoke\(question\)，内部会将问题文本用同样的嵌入模型向量化 → 在向量库中计算相似度 → 返回得分最高的 1 个 Document（因为 k=1）。

### 1\.4\.3\. Agentic RAG

#### 1\.4\.3\.1\. Agentic RAG 介绍

Agentic RAG 将 Retriever 包装成 Agent 可以调用的 Tool，模型不是先收到程序写死的检索结果，而是先阅读用户问题，由Agent自主决定是否调用检索工具\(不是每次必检），然后根据工具返回的结果生成最终答案，整个过程由Agent的决策驱动，更加灵活。

典型流程如下：

![jxhuRQL4\.jpg](图片和附件/jxhuRQL4.jpg)

LangChain 的 create\_agent\(\) 是构建标准 Agentic RAG 的高层入口。它接收模型和工具，并在内部组织“模型 → 工具 → 模型”的循环。create\_agent\(\) 本身构建在 LangGraph 之上，使用者不需要手工编写每个节点和边。

#### 1\.4\.3\.2\. Agent RAG使用案例

Agentic RAG使用步骤如下：

1. 使用Embedding 创建 Vector Store 和 Retriever。

2. 使用 create\_retriever\_tool\(\) 将 Retriever 包装成 Tool。

3. 将 Chat Model 和 Retriever Tool 传给create\_agent\(\)。

4. 调用 Agent，模型根据问题决定是否生成 tool\_calls。

5. ToolMessage 返回后，Agent 再次调用模型；模型可能继续产生新的 tool\_calls，直到返回不包含工具调用的最终消息，或达到运行限制。

6. 需要自定义文档评估、改写、人工审核和恢复流程时，再使用原生 LangGraph。

下面使用 create\_agent\(\) 构建最小 Agentic RAG。该案例中DeepSeek 遇到退款问题后生成了一次工具调用，Retriever 使用 text\-embedding\-v1 检索退款规则，Agent 再根据 ToolMessage 生成答案；工具调用次数是本次输入和模型决策的观察结果，不是固定协议。

```Plain Text
from env_utils import DASHSCOPE_API_KEYfrom langchain.agents import create_agentfrom langchain_community.embeddings import DashScopeEmbeddingsfrom langchain_core.documents import Documentfrom langchain_core.prompts import PromptTemplatefrom langchain_core.tools import create_retriever_toolfrom langchain_core.vectorstores import InMemoryVectorStorefrom init_llm import deepseek_llm_flash

# ============================================================
# 第一步：使用真实Embedding建立知识库
# ============================================================embedding_model = DashScopeEmbeddings(
    model="text-embedding-v1",
    dashscope_api_key=DASHSCOPE_API_KEY,
)

vector_store = InMemoryVectorStore(embedding_model)
vector_store.add_documents(
    [
        Document("退款通常三个工作日内到账。", metadata={"source": "退款规则.md"}),
        Document("订单发货后可以查看物流轨迹。", metadata={"source": "物流规则.md"}),
    ]
)


# ============================================================
# 第二步：把Retriever包装成Agent工具
# ============================================================retriever_tool = create_retriever_tool(
    vector_store.as_retriever(search_kwargs={"k": 1}),
    name="retrieve_after_sale_rules",
    description="检索退款到账和物流规则。涉及退款、到账或物流问题时必须调用。",
    document_prompt=PromptTemplate.from_template("{page_content}\n来源：{source}"),
)


if __name__ == "__main__":
    # ========================================================
    # 第三步：使用create_agent创建RAG Agent
    # ========================================================agent = create_agent(
        model=deepseek_llm_flash,
        tools=[retriever_tool],
        system_prompt=(
            "你是售后Agent。涉及退款、到账或物流问题时必须先调用检索工具。""只能根据工具结果回答，回答末尾列出来源。"
        ),
    )

    # ========================================================
    # 第四步：调用Agent，模型自主生成tool_calls
    # ========================================================result = agent.invoke(
        {"messages": [{"role": "user", "content": "退款多久到账？"}]}
    )

    print("最终回答：",result["messages"][-1].content)
```

以上代码运行结果如下：

![rqKhZyAr\.jpg](图片和附件/rqKhZyAr.jpg)

以上代码中注意create\_retriever\_tool是将检索器包装成 LangChain 标准工具对象。Agent 可以像调用函数一样调用这个工具。

- name：工具的唯一标识，LLM 在决定调用哪个工具时会引用这个名字。

- description：LLM 根据此描述判断何时该调用该工具。这里明确说明涉及“退款、到账或物流”时必须调用。

- document\_prompt： 把结果拼成一段纯文本，作为工具的输出（Tool Result）返回给 Agent。page\_content 和 source 名称对应到Document中的 page\_content和metadata中source字段。

### 1\.4\.4\. Hybrid RAG

#### 1\.4\.4\.1\. Hybrid RAG介绍

Hybrid RAG 是把确定性流程与受控的 Agentic 能力组合起来。常见实现会加入查询处理、文档验证、答案验证或有限自纠错，但并不要求所有 Hybrid RAG 都固定从 Retriever 开始。它的核心是：模型可以参与判断，但判断范围仍由工作流约束。

典型流程如下：

![sbCKLDNm\.jpg](图片和附件/sbCKLDNm.jpg)

Hybrid RAG 与 Hybrid Search 不是同一个概念：

- Hybrid RAG：描述整条 RAG 工作流，重点是确定性节点与受控模型决策的组合。

- Hybrid Search：描述 Retriever 内部的检索方式，重点是组合向量检索与关键词检索。

Hybrid RAG 适合制度问答、客服和知识助手等既需要资料验证或查询改写，又不希望 Agent 完全自由规划流程的场景。

#### 1\.4\.4\.2\. Hybrid RAG使用案例

下面案例演示一种常见的 Hybrid RAG 实现：固定检索后增加验证与一次自纠错。该案例并不是 Hybrid RAG 的唯一结构。

1. 按固定流程执行 Retriever。

2. 对召回文档进行相关性验证。

3. 验证通过时进入生成节点。

4. 验证失败时改写查询并重新检索。

5. 设置最大改写次数，超过次数后拒答或转人工。

6. 可继续增加答案忠实性验证，但要控制调用成本。

该案例使用LangGraph构建固定检索流程：

```Plain Text
import osfrom typing import TypedDictfrom langchain_community.embeddings import DashScopeEmbeddingsfrom langchain_core.documents import Documentfrom langchain_core.vectorstores import InMemoryVectorStorefrom langgraph.graph import END, START, StateGraphfrom init_llm import deepseek_llm_flashembedding_model = DashScopeEmbeddings(
    model="text-embedding-v1",
    dashscope_api_key=os.environ["DASHSCOPE_API_KEY"],
)


# ============================================================
# 第一步：创建语义知识库
# ============================================================vector_store = InMemoryVectorStore(embedding_model)
vector_store.add_documents(
    [
        Document("退款通常三个工作日内到账。", metadata={"source": "退款规则.md"}),
        Document("收货后七日内可以申请退货。", metadata={"source": "退货规则.md"}),
    ]
)


class HybridState(TypedDict, total=False):
    original_question: str # 用户原始问题
    retrieval_query: str # 检索查询
    documents: list[Document] # 检索到的知识库文档
    relevant: bool # 是否相关
    answer: str # 回答
    attempts: int # 尝试次数
    grade_result: str # 验证结果
    trace: list[str] # 执行轨迹


# ============================================================
# 第二步：检索节点
# ============================================================def retrieve(state: HybridState) -> dict:
    documents = vector_store.similarity_search(state["retrieval_query"], k=2)
    return {"documents": documents, "trace": [*state.get("trace", []), "retrieve"]}


# ============================================================
# 第三步：LLM验证文档
# ============================================================def validate_documents(state: HybridState) -> dict:
    context = "\n".join(document.page_content for document in state["documents"])
    response = deepseek_llm_flash.invoke(
        "判断资料是否能回答用户问题。只输出YES或NO。\n"f"用户问题：{state['original_question']}\n检索资料：{context}"
    )
    grade_result = response.content.strip().upper()
    relevant = grade_result.startswith("YES")
    return {
        "relevant": relevant,
        "grade_result": grade_result,
        "trace": [*state["trace"], f"validate_documents({grade_result})"],
    }


def route_after_validation(state: HybridState) -> str:
    if state["relevant"]:
        return "generate"
    # 如果尝试次数小于1次，改写问题并重试
    if state.get("attempts", 0) < 1:
        return "rewrite_question"return "fallback"


# ============================================================
# 第四步：LLM改写检索问题
# ============================================================def rewrite_question(state: HybridState) -> dict:
    response = deepseek_llm_flash.invoke(
        "把下面问题改写成适合检索退款知识库的短查询。只输出查询，不要解释。\n"f"原始问题：{state['original_question']}"
    )
    rewritten = response.content.strip().replace("\n", " ")
    return {
        "retrieval_query": rewritten,
        "attempts": state.get("attempts", 0) + 1,
        "trace": [*state["trace"], f"rewrite_question({rewritten})"],
    }


# ============================================================
# 第五步：LLM生成回答
# ============================================================def generate(state: HybridState) -> dict:
    context = "\n".join(document.page_content for document in state["documents"])
    response = deepseek_llm_flash.invoke(
        "只能根据资料回答问题，保留时间和条件。\n"f"资料：{context}\n问题：{state['original_question']}"
    )
    return {"answer": response.content, "trace": [*state["trace"], "generate"]}


def fallback(state: HybridState) -> dict:
    return {
        "answer": "检索和问题改写后仍没有可靠资料，请转人工客服。",
        "trace": [*state["trace"], "fallback"],
    }


if __name__ == "__main__":
    # ========================================================
    # 第六步：组装并调用Hybrid RAG图
    # ========================================================builder = StateGraph(HybridState)
    builder.add_node("retrieve", retrieve)
    builder.add_node("validate_documents", validate_documents)
    builder.add_node("rewrite_question", rewrite_question)
    builder.add_node("generate", generate)
    builder.add_node("fallback", fallback)

    builder.add_edge(START, "retrieve")
    builder.add_edge("retrieve", "validate_documents")
    builder.add_conditional_edges(
        "validate_documents",
        route_after_validation,
        {"generate": "generate", "rewrite_question": "rewrite_question", "fallback": "fallback"},
    )
    builder.add_edge("rewrite_question", "retrieve")
    builder.add_edge("generate", END)
    builder.add_edge("fallback", END)
    graph = builder.compile()

    question = "款项什么时候回银行卡？"
    # question = "你们产品质量怎么样？"result = graph.invoke(
        {
            "original_question": question,
            "retrieval_query": question,
            "attempts": 0,
            "trace": [],
        }
    )

    print("用户原始问题：", result["original_question"])
    print("执行轨迹：", " -> ".join(result["trace"]))
    print("最终检索问题：", result["retrieval_query"])
    print("最终回答：", result["answer"])
```

以上代码，选择question为“款项什么时候回银行卡？” 时候，输出结果如下：

![tga6DnDT\.jpg](图片和附件/tga6DnDT.jpg)

选择question为“你们产品质量怎么样？”时候，输出结果如下：

![0oLI3w9x\.jpg](图片和附件/0oLI3w9x.jpg)

可以看到检索重试后，达到一定次数就通过“fallback”节点直接输出固定结果。

### 1\.4\.5\. 三种RAG架构总结

三种架构解决的问题不同，主要区别如下：

选择顺序如下：

1. 普通知识问答先建立 2\-Step RAG 基线。

2. 需要 Agent 判断是否检索或选择不同工具时，使用 Agentic RAG。

3. 需要把确定性流程与受控模型判断、验证或有限自纠错组合时，使用 Hybrid RAG。

4. 需要组合向量与关键词检索时，在任一架构的 Retriever 内部增加 Hybrid Search。

# LangChain RAG构建流程

## 2\.1\. Document

LangChain 使用 Document 统一表示一段文本，一个 Document 主要包含如下内容：

- page\_content：真正参与检索的文本。

- metadata：文本的来源、页码、产品、版本、租户等附加信息。

RAG 中不能只保存正文，回答需要引用来源时，要从 metadata 中读取文件名；检索需要限制产品时，要从 metadata 中读取产品字段；资料存在新旧版本时，也要通过 metadata 区分。

```Plain Text
documents = [
    Document(
        page_content="退货规则：收货后七日内可以申请无理由退货，商品、包装和配件需要保持完整。",
        metadata={"source": "售后规则.md"},
    ),
    Document(
        page_content="退款规则：仓库验收通过后发起原路退款，通常三个工作日内到账。",
        metadata={"source": "退款规则.md"},
    ),
    Document(
        page_content="物流规则：订单发货后可以在订单详情查看物流轨迹。",
        metadata={"source": "物流规则.md"},
    ),
]
```

metadata中的k:v可以自定义，常见的metadata字段如下：

metadata 应保存程序需要过滤和展示的结构化信息，不要把所有内容都拼接成一段字符串。尤其是 tenant\_id、权限和有效期，这些字段应由服务端根据认证上下文生成，不能直接相信用户输入，也不能把 Retriever 当作唯一的安全边界。

## 2\.2\. Document Loader

外部知识进入 LangChain 后，需要先转换为统一的 Document 对象。Document Loader 负责读取文件、网页、数据库或云存储中的原始数据，并把它们转换成后续可以切分、向量化和检索的 Document。

整体数据流如下：

![662OV7Uo\.jpg](图片和附件/662OV7Uo.jpg)

Document Loader 只负责读取和转换文档，不负责 Embedding、向量存储和语义检索。LangChain 为不同数据源提供了统一 Loader 接口：load\(\) 一次返回全部文档，lazy\_load\(\) 按迭代方式逐个产生文档。可以参考：[https://docs\.langchain\.com/oss/python/integrations/document\_loaders](https://docs.langchain.com/oss/python/integrations/document_loaders)

常用的Loader选项如下：

Loader 产生多少个 Document，不能只根据文件数量判断。TXT 文件通常是一个文件对应一个 Document；PDF 在分页模式下通常是一页对应一个 Document；JSON、CSV 等结构化文件则可能一条记录对应一个 Document。

### 2\.2\.1\. Text转换为Document

TextLoader 用于读取纯文本文件，例如：“\.txt”、“\.md”、“\.log”、“\.py”、“\.csv”，不过，如果文件本身具有明确结构，例如 CSV 或 JSON，通常应该优先使用专门的 CSVLoader 或 JSONLoader，而不是全部当成普通文本读取。

TextLoader常见初始化方式如下：

```Plain Text
TextLoader(
    file_path="售后规则.txt",
    encoding="utf-8",
)
```

以上参数解释如下：

- file\_path：文件路径；

- encoding：文件编码，建议明确指定编码。

TextLoader将一个文件加载为一个Document对象并返回，该Document中除了有page\_content存储文件内容外，metadata字段中还默认自带source，指定读取文件的相对路径。Document结构如下：

```Plain Text
Document(
        page_content="读取文件的整个内容",
        metadata={"source": "文件相对路径"},
    )
```

案例：使用TextLoader读取文本内容转换成Document。

```Plain Text
from pathlib import Path

from langchain_community.document_loaders import TextLoader


loader = TextLoader(
    "D:\\PyCharmSpace\\RAGProject\\02_LangChain RAG相关名词\\data\\售后规则.txt",
    encoding="utf-8",
)

documents = loader.load()

print("Document数量：", len(documents))

for index, document in enumerate(
    documents,
    start=1,
):
    print(f"\n第{index}个Document")
    print(
        "来源：",
        Path(document.metadata["source"]).name,
    )
    print("正文：")
    print(document.page_content.strip())
```

以上代码运行后结果如下：

![uSoSYBPM\.jpg](图片和附件/uSoSYBPM.jpg)

以上代码中使用“langchain\-community”包中的“TextLoader”，运行代码时会有警告，原因是langchain 仓库已经停止主动维护并进入归档状态。官方当前发布的 langchain\-community 会在导入时主动产生 DeprecationWarning。官方目前没有提供一个明确的、独立维护的 TextLoader 替代包。对于这种没有替代包情况，我们也可以通过自定义Loader来实现。

### 2\.2\.2\. 自定义Loader案例

LangChain允许通过继承BaseLoader实现自定义Loader，只要实现lazy\_load\(\) 并产生Document，就能继续接入Text Splitter、Embedding、Vector Store和Retriever。

将上一个案例通过自定义Loader来实现，代码如下：

```Plain Text
from collections.abc import Iteratorfrom pathlib import Pathfrom langchain_core.document_loaders import BaseLoaderfrom langchain_core.documents import Document


# ============================================================
# 第一步：定义TXT Loader
# ============================================================class TextFileLoader(BaseLoader):
    """使用Python标准库读取本地TXT文件。"""def __init__(
        self,
        file_path: str | Path,
        encoding: str = "utf-8",
    ) -> None:
        self.file_path = Path(file_path)
        self.encoding = encoding

    # 在 lazy_load 中实现文件读取并生成Documentdef lazy_load(self) -> Iterator[Document]:
        """读取TXT并产生一个Document。"""if not self.file_path.exists():
            raise FileNotFoundError(
                f"没有找到TXT文件："f"{self.file_path}"
            )

        content = self.file_path.read_text(encoding=self.encoding)

        yield Document(
            page_content=content,
            metadata={
                "source": str(
                    self.file_path
                ),
                "file_name": self.file_path.name,
                "file_type": self.file_path.suffix,
                "encoding": self.encoding,
            },
        )


# ============================================================
# 第二步：指定文件
# ============================================================FILE_PATH = Path(r"D:\PyCharmSpace\RAGProject\02_LangChain RAG相关名词\data\售后规则.txt")

# ========================================================
# 第三步：创建Loader
# ========================================================loader = TextFileLoader(
    file_path=FILE_PATH,
    encoding="utf-8",
)

# ========================================================
# 第四步：加载并查看Document
# ========================================================documents = loader.load()

print("Document数量：",len(documents),)

for index, document in enumerate(documents,start=1,):
    print(f"\n第{index}个Document")
    print("来源：",document.metadata["source"])
    print("内容：",document.page_content.strip())
```

以上代码运行结果如下：

![Q66uRiUf\.jpg](图片和附件/Q66uRiUf.jpg)

以上代码解释如下：

1. 该案例继承 BaseLoader 实现自定义 TXT Loader，这种方式只依赖 langchain\-core，可以在不引入 langchain\-community 的情况下实现文档加载。

2. BaseLoader 是 LangChain 文档加载器的抽象基类。子类只需实现 lazy\_load\(\) 方法，load\(\) 方法由基类自动提供，内部调用 lazy\_load\(\) 并收集所有文档。因此案例中只实现了 lazy\_load\(\)，loader\.load\(\) 仍然可以正常使用。

3. lazy\_load\(\) 使用 yield 逐个返回 Document，而非一次性返回列表。这种生成器模式适合大文件场景，文件内容不会全部驻留内存，而是在迭代过程中按需读取。

4. 自定义 Loader 的 metadata 应至少包含 source，便于后续检索时追溯来源。该案例还补充了 file\_name、file\_type 和 encoding，这些字段可以在调试、过滤和来源引用时提供额外信息。

6. 如果需要支持多种文件格式（如 PDF、Word、Markdown），可按同样方式为每种格式实现独立的 Loader，或在同一个 Loader 中根据文件后缀选择解析策略。

### 2\.2\.3\. PDF文档转换为Document

PyPDFLoader 使用 pypdf 读取 PDF 中的文本层。PyPDFLoader常见初始化方式如下：

```Plain Text
PyPDFLoader(
    file_path,
    password=None,
    extract_images=False,
    mode="page",
    extraction_mode="plain",
)
```

以上参数解释如下：

需要注意，普通 PyPDFLoader 主要提取 PDF 的文本层。如果 PDF 是扫描图片，没有可复制的文字，可能提取不到有效正文，这时需要使用 OCR 或文档解析类 Loader。

PyPDFLoader 能完成基础文本提取，真实业务场景中，一个PDF文件中可能不仅仅包含文本、图片，还有可能包含表格，这种复杂的富文本格式，使用PyPDFLoader可能并不能很好地进行处理，所以这里使用自定义Loader方式来处理富文本格式的PDF（包含文本、图片、表格）。

以下选择自定义BaseLoader来处理包含文本、图片、表格的PDF文档的思路如下：

1. 按照顺序识别PDF文档中的文本、图片、表格。

2. 文本内容直接原样放入到Document的page\_content中。

3. 图片内容转换成MD的图片提示内容，然后图片单独保存到一个目录中，在Document的metadata中保存存储图片的目录地址。

4. 表格内容可以直接根据表格头和每行表格的内容，转换成文本形式内容，放入到Document的page\_content中，例如表头 \["商品", "单价"\]，数据 \["耳机", 299\] 最终转换成 "商品为耳机，单价为299。"

特别注意：图片的二进制像素不会自动进入 page\_content，普通文本 Embedding 也不会理解图片像素。要让图片内容参与语义检索，还需要先使用 OCR 或多模态模型生成图片描述，再把描述文本写入 page\_content。

```Plain Text
from collections.abc import Iterator
from pathlib import Path
import re
from dataclasses import dataclass
from typing import Anyimport pymupdf
from langchain_core.document_loaders import BaseLoader
from langchain_core.documents import Document


# ============================================================# 配置路径# ============================================================
FILE_PATH = Path(r"D:\PyCharmSpace\RAGProject\02_LangChain RAG相关名词\data\售后手册.pdf")
IMAGE_OUTPUT_DIR = Path(r"D:\PyCharmSpace\RAGProject\02_LangChain RAG相关名词\data\extracted_pdf_images")


# ============================================================# 辅助函数：清理单元格文本# ============================================================def normalize_cell(cell: str | None) -> str:"""清理单元格中的换行和多余空白，将连续空白替换为单个空格。"""# 如果 cell 是 None，转为空字符串；否则转为字符串# re.sub(r"\s+", " ", ...) 将所有连续空白（空格、换行、制表符）替换为单个空格# .strip() 去除首尾空白return re.sub(r"\s+", " ", str(cell or "")).strip()


# ============================================================# 辅助函数：将表格行转换为自然语言陈述句# ============================================================def table_rows_to_text(rows: list[list[str | None]]) -> list[str]:"""
    使用首行作为表头，将每条数据行转换成"字段为值"的完整陈述句。
    例如：表头 ["商品", "单价"]，数据 ["耳机", 299] → "商品为耳机，单价为299。"
    """# 如果少于2行（无表头或无数据），返回空列表if len(rows) < 2:
        return []

    # 第一行作为表头，清理每个单元格的空白字符
    headers = [normalize_cell(cell) for cell in rows[0]]

    # 初始化空列表，用于存储每个数据行的陈述句
    sentences: list[str] = []

    # 从第二行开始遍历数据行for row in rows[1:]:
        # 清理当前行每个单元格的内容
        values = [normalize_cell(cell) for cell in row]

        fields: list[str] = []

        # 逐列处理，将每列拼接成 "表头为值"for col_idx, header in enumerate(headers):
            # 如果表头为空，跳过该列（无法形成有意义的短语）if not header:
                continue# 如果当前行有该列的值，则取用；否则置为空字符串
            value = values[col_idx] if col_idx < len(values) else ""# 拼接 "表头为值"，如果值为空则显示"未填写"
            fields.append(f"{header}为{value or '未填写'}")

        # 如果当前行有有效字段，用中文逗号连接，末尾加句号if fields:
            sentences.append("，".join(fields) + "。")

    return sentences


# ============================================================# 定义页面元素的数据结构，用于按Y坐标排序# ============================================================@dataclassclass PageElement:"""页面元素：文本块、表格或图片，统一记录其Y坐标和内容。"""
    y: float                    # 元素在页面上的Y坐标（越小越靠上）
    element_type: str           # "text", "table", "image"
    content: str                # 元素的文本内容或描述
    extra: dict[str, Any] | None = None  # 附加信息（如图片路径）# ============================================================# 核心加载器类# ============================================================class RichPDFLoader(BaseLoader):"""
    将PDF正文、表格行文本和图片引用按视觉顺序（从上到下）组装成Document。
    每个页面生成一个Document，保持页面内元素的原始布局顺序。
    """def __init__(self, file_path: Path, image_output_dir: Path) -> None:"""初始化加载器：保存PDF路径和图片输出目录。"""
        self.file_path = file_path
        self.image_output_dir = image_output_dir

    def lazy_load(self) -> Iterator[Document]:"""
        生成器：逐页处理PDF，每页生成一个Document。
        使用yield逐个返回，适合大文件流式处理。
        """# 创建图片输出目录（如果不存在则递归创建）# parents: 是否递归创建父目录# exist_ok: 是否忽略已存在目录（True是不抛出异常）
        self.image_output_dir.mkdir(parents=True, exist_ok=True)

        # 使用PyMuPDF打开PDF文件
        pdf = pymupdf.open(self.file_path)

        try:
            # 逐页遍历for page_index, page in enumerate(pdf):
                # 存储当前页的所有元素（文本块、表格、图片）
                elements: list[PageElement] = []

                # ============================================================# 第一步：识别表格，记录表格内容和表格区域# ============================================================# PyMuPDF 提供的表格检测方法，会分析页面上的线条、网格和文本布局，自动识别出页面中哪些区域属于“表格”，返回值是一个 TableFinder 对象
                table_result = page.find_tables()

                # TableFinder 对象的一个属性，返回一个列表（或元组），包含该页面上所有检测到的 Table 对象（即每一个独立的表格）# Table 对象的 bbox 属性，边界框（Bounding Box）。它是一个元组 (x0, y0, x1, y1)：# - x0：矩形左边缘的 X 坐标# - y0：矩形上边缘的 Y 坐标# - x1：矩形右边缘的 X 坐标# - y1：矩形下边缘的 Y 坐标# 坐标系原点在页面左上角，Y 轴向下为正。## PyMuPDF 的 Rect 类构造函数，接收 (x0, y0, x1, y1) 元组，生成一个 Rect 对象。# Rect 对象提供了丰富的几何方法，如 .intersects()（检测两个矩形是否相交）、.contains()（检测是否包含某个点）等。# 最终得到的table_rects列表，包含该页面上所有表格的 Rect 对象。# 这里得到 table_rects 是方便后续判断文本是否存在于表格中，后续用到该 table_rects 列表
                table_rects = [pymupdf.Rect(table.bbox) for table in table_result.tables]

                # 遍历找到的每个表格，提取内容并转换为陈述句，有几个表格就循环几次for table_index, table in enumerate(table_result.tables, start=1):
                    rows = table.extract()                      # 提取原始二维列表
                    row_texts = table_rows_to_text(rows)       # 转换为自然语言句子if row_texts:
                        # 构造表格的文本描述，加入标题
                        content = f"## 表格{table_index}\n" + "\n".join(row_texts)
                        # 获取表格的Y坐标（取上边框的Y值，越小越靠上）
                        table_y = table.bbox[1]
                        elements.append(
                            PageElement(
                                y=table_y, # 表格Y坐标（越小越靠上）
                                element_type="table", # 表格元素类型
                                content=content, # 表格内容
                            )
                        )

                # ============================================================# 第二步：提取图片，保存为独立文件，并记录位置# ============================================================
                image_paths: list[str] = [] # 存储所有图片的绝对路径
                seen_xrefs: set[int] = set() # 存储已处理的图片交叉引用编号，避免重复处理# page.get_images(full=True):遍历当前页面内容流中引用的所有图片，返回一个列表。# full=True: 控制返回信息的详细程度，设置为True时，get_images() 返回完整的图片元数据# image_info 每条信息包含 (xref, ...)等信息，xref是图片在 PDF 文件中的交叉引用编号（Cross-Reference ID），这是提取图片实际数据时所需的唯一标识符。for image_info in page.get_images(full=True):
                    # 图片的交叉引用编号
                    xref = image_info[0]

                    # 去重：同一张图片可能被多次引用if xref in seen_xrefs:
                        continue

                    seen_xrefs.add(xref)

                    # extract_image(xref)：从 PDF 文件中提取指定图片的原始二进制数据及其元信息。返回 {"image": bytes, "ext": "png"}
                    image_data = pdf.extract_image(xref)

                    # 生成图片文件名：原文件名_page_页码_image_序号.扩展名
                    image_number = len(image_paths) + 1
                    image_name = (
                        f"{self.file_path.stem}_"f"page_{page_index + 1}_"f"image_{image_number}."f"{image_data['ext']}"
                    )

                    # 等价于：Path(os.path.join(self.image_output_dir, image_name))# 拼接图片路径，“/”表示Path中路径拼接符
                    image_path = self.image_output_dir / image_name

                    # 将图片二进制数据写入文件
                    image_path.write_bytes(image_data["image"])
                    image_paths.append(str(image_path.resolve()))

                    # page.get_image_rects(xref) ：精确定位一张图片在页面上的所有显示位置。# 这个方法返回一个列表[x0，y0，x1，y1]，包含图片在页面上的所有出现位置# - x0：矩形左边缘的 X 坐标# - y0：矩形上边缘的 Y 坐标# - x1：矩形右边缘的 X 坐标# - y1：矩形下边缘的 Y 坐标
                    image_rects = page.get_image_rects(xref)
                    if image_rects:
                        # 取第一个矩形的位置（通常一张图片只出现一次）
                        img_rect = image_rects[0]
                        img_y = img_rect.y0  # 图片上边框的Y坐标else:
                        # 如果无法获取坐标，使用一个默认值（放在页面底部）# page.rect：返回一个 Rect（矩形）对象，表示整个页面的边界框# page.rect.height：返回矩形的高度（即 y1 - y0），由于页面矩形的 y0 通常为 0，所以 page.rect.height 直接等于页面底部的 Y 坐标值。
                        img_y = page.rect.height

                    # 构造图片的文本描述（Markdown格式引用）
                    image_content = f"![页面图片{image_number}]({Path(image_path).name})"
                    elements.append(
                        PageElement(
                            y=img_y, # 图片Y坐标（越小越靠上）
                            element_type="image", # 图片元素类型
                            content=image_content, # 图片内容（Markdown格式引用）
                            extra={"path": str(image_path.resolve())}, # 图片绝对路径
                        )
                    )

                # ============================================================# 第三步：提取普通文本块（非表格、非图片区域）# ============================================================# page.get_text("blocks") 返回页面上的所有文本块# 每个块是一个元组: (x0, y0, x1, y1, text, block_no, block_type)# -x0: 文本块左边缘的 X 坐标# -y0：文本块上边缘的 Y 坐标# -x1：文本块右边缘的 X 坐标# -y1：文本块下边缘的 Y 坐标# -text：文本块的文本内容# -block_no：文本块的唯一标识符，块在页面上的编号（内部序号）# block_type：块类型标志：0 表示文本块（Text Block），1 表示图片块（Image Block）for block in page.get_text("blocks"):
                    block_type = block[6]
                    if block_type != 0:
                        continue  # 跳过非文本块（如图片块）# PyMuPDF 的 Rect 类构造函数，接收 (x0, y0, x1, y1) 元组，生成一个 Rect 对象。# Rect 对象提供了丰富的几何方法，如 .intersects()（检测两个矩形是否相交）、.contains()（检测是否包含某个点）等。
                    block_rect = pymupdf.Rect(block[:4])  # 文本块的矩形区域# 如果文本块位于表格区域内，跳过（表格内容已单独提取）# 这里使用 any() 函数，表示只要当前文本块与任意一个表格矩形相交，就认为文本块位于表格区域内。# 这样可以确保我们只提取非表格区域的文本块。if any(block_rect.intersects(table_rect) for table_rect in table_rects):
                        continue

                    block_text = str(block[4]).strip()
                    if not block_text:
                        continue# 获取文本块的Y坐标（上边框的Y值，越小越靠上）
                    block_y = block_rect.y0

                    # 将文本块作为文本元素加入列表
                    elements.append(
                        PageElement(
                            y=block_y, # 文本块Y坐标（越小越靠上）
                            element_type="text", # 文本块元素类型
                            content=block_text, # 文本块内容
                        )
                    )

                # ============================================================# 第四步：按Y坐标排序，保持视觉顺序（从上到下）# ============================================================
                elements.sort(key=lambda e: e.y)

                # ============================================================# 第五步：组装页面内容，添加段落标题# ============================================================
                content_parts: list[str] = []
                # 当前页中按照y坐标排序好的结果，拼接页面内容for elem in elements:
                    content_parts.append(elem.content)

                # ============================================================# 第六步：创建Document，包含正文和元数据# ============================================================# 收集所有图片路径（用于元数据）
                all_image_paths = [
                    elem.extra["path"] for elem in elements
                    if elem.element_type == "image" and elem.extra
                ]

                yield Document(
                    page_content="\n\n".join(content_parts),
                    metadata={
                        "source": str(self.file_path.resolve()), # 源文件绝对路径"page": page_index, # 页码索引（从0开始）"table_count": len(table_result.tables), # 识别到的表格数量"image_count": len(all_image_paths), # 识别到的图片数量"images": all_image_paths, # 所有图片路径（用于元数据）
                    },
                )

        finally:
            # 确保PDF文件被正确关闭，释放资源
            pdf.close()


# ============================================================# 主流程：执行加载并打印结果# ============================================================"""创建加载器，加载PDF，打印每页的元数据和正文内容。"""
loader = RichPDFLoader(
    file_path=FILE_PATH,
    image_output_dir=IMAGE_OUTPUT_DIR,
)

# load() 内部调用 lazy_load() 并收集所有Document
documents = loader.load()

print("Document数量：", len(documents))

for document in documents:
    print("页码索引：", document.metadata["page"])
    print("识别表格数：", document.metadata["table_count"])
    print("识别图片数：", document.metadata["image_count"])
    print("图片文件：", [Path(path).name for path in document.metadata["images"]])

    print("\nDocument正文：")
    print(document.page_content)
```

以上代码运行结果如下：

![VTwwJy2j\.jpg](图片和附件/VTwwJy2j.jpg)

以上代码中自定义PDF处理Loader使用的是PyMuPDF，需要提前安装依赖：

```Plain Text
pip install PyMuPDF python-docx Pillow reportlab
```

此外，实际知识库中，建议将正文、表格和图片拆成不同 Document，而不是全部塞进一个大对象。例如:

普通正文处理为如下Document:

```Plain Text
Document(
    page_content="退款申请需要先完成仓库验收。",
    metadata={
        "source": "售后制度.docx",
        "element_type": "text",
        "section": "退款规则",
    },
)
```

表格行处理为如下Document：

```Plain Text
Document(
    page_content=(
        "业务类型：退款；""处理条件：仓库验收通过；""处理时效：通常三个工作日到账。"
    ),
    metadata={
        "source": "售后制度.docx",
        "element_type": "table_row",
        "table_index": 1,
        "row_index": 2,
    },
)
```

图片描述处理为如下Document:

```Plain Text
Document(
    page_content=(
        "售后退款处理流程：""提交申请后进入仓库验收，""验收通过后发起原路退款。"
    ),
    metadata={
        "source": "售后制度.docx",
        "element_type": "image",
        "image_path": "售后制度_image_1.png",
        "image_index": 1,
    },
)
```

这样做的好处如下：

- 每种元素可以独立检索；

- 图片可以使用 OCR 或多模态模型单独处理；

- 最终答案可以追溯到具体段落、表格行或图片；

- metadata 过滤更加清晰。

### 2\.2\.4\. Docx转换为Document

Docx2txtLoader用于读取\.docx文件，并把其中的正文转换为普通文本，适合Word文档一普通文本为主，没有复杂格式场景。

```Plain Text
Docx2txtLoader("售后制度.docx")
```

UnstructuredWordDocumentLoader 可以处理复杂word，例如word中包含表格、图片、页眉页脚等内容，可以通过该对象解析：

```Plain Text
loader = UnstructuredWordDocumentLoader(
    "售后制度.docx",
    mode="elements",
)
```

model有两种模式：single 表示将整个 Word 文档合并为一个 Document；elements 会尽量按照标题、正文、表格等文档元素拆分。

在一些特殊场景下，比如需要精准对表格、图片进行处理，UnstructuredWordDocumentLoader方式使用起来不灵活，这种情况可以自定义BaseLoader来处理docx文档。

自定义BaseLoader处理包含文本、图片、表格的docx文档的思路如下：

1. 按照顺序识别DOCX文档中的文本、图片、表格。

2. 文本内容直接原样放入到Document的page\_content中。

3. 图片内容转换成MD的图片提示内容，然后图片单独保存到一个目录中，在Document的metadata中保存存储图片的目录地址。

4. 表格内容可以直接根据表格头和每行表格的内容，转换成文本形式内容，放入到Document的page\_content中，例如表头 \["商品", "单价"\]，数据 \["耳机", 299\] 最终转换成 "商品为耳机，单价为299。"

特别注意：图片的二进制像素不会自动进入 page\_content，普通文本 Embedding 也不会理解图片像素。要让图片内容参与语义检索，还需要先使用 OCR 或多模态模型生成图片描述，再把描述文本写入 page\_content。

```Plain Text
from collections.abc import Iterator
from pathlib import Path
import re

from docx import Document as WordDocument
from docx.document import Document as WordDocumentType
from docx.oxml.ns import qn
from docx.oxml.table import CT_Tbl
from docx.oxml.text.paragraph import CT_P
from docx.table import Table
from docx.text.paragraph import Paragraph

from langchain_core.document_loaders import BaseLoader
from langchain_core.documents import Document


# ============================================================# 配置路径# ============================================================
FILE_PATH = Path(r"D:\PyCharmSpace\RAGProject\02_LangChain RAG相关名词\data\售后制度.docx")
IMAGE_OUTPUT_DIR = Path(r"D:\PyCharmSpace\RAGProject\02_LangChain RAG相关名词\data\extracted_docx_images")


# ============================================================# 第一步：清理表格单元格文本# ============================================================def normalize_cell(cell: str | None) -> str:"""清理表格单元格中的换行和多余空白，将连续空白替换为单个空格。"""# 如果 cell 是 None，转为空字符串；# re.sub 将连续空白替换为单个空格；# .strip() 去除首尾空白return re.sub(r"\s+", " ", str(cell or "")).strip()


# ============================================================# 第二步：将表格行转换为自然语言陈述句# ============================================================def table_rows_to_text(rows: list[list[str | None]]) -> list[str]:"""
    使用首行作为表头，将每条数据行转换成"字段为值"的完整陈述句。
    例如：表头 ["商品", "单价"]，数据 ["耳机", 299] → "商品为耳机，单价为299。"
    """# 如果少于2行（无表头或无数据），返回空列表if len(rows) < 2:
        return []

    # 第一行作为表头，清理每个单元格的空白字符
    headers = [normalize_cell(cell) for cell in rows[0]]

    # 初始化空列表，用于存储每个数据行的陈述句
    sentences: list[str] = []

    # 从第二行开始遍历数据行for row in rows[1:]:
        # 清理当前行每个单元格的内容
        values = [normalize_cell(cell) for cell in row]

        fields: list[str] = []

        # 逐列处理，将每列拼接成 "表头为值"for col_idx, header in enumerate(headers):
            # 如果表头为空，跳过该列（无法形成有意义的短语）if not header:
                continue# 如果当前行有该列的值，则取用；否则置为空字符串
            value = values[col_idx] if col_idx < len(values) else ""# 拼接 "表头为值"，如果值为空则显示"未填写"
            fields.append(f"{header}为{value or '未填写'}")

        # 如果当前行有有效字段，用中文逗号连接，末尾加句号if fields:
            sentences.append("，".join(fields) + "。")

    return sentences


# ============================================================# 第三步：按照DOCX内部顺序遍历段落和表格# ============================================================def iter_document_blocks(document: WordDocumentType):"""
    按照DOCX内部XML顺序逐个产生段落和表格对象。
    document.paragraphs 和 document.tables 各自独立，无法保留交叉顺序。
    直接遍历 body 的 XML 子节点，顺序即文档的真实视觉顺序。
    """# document.element.body 是文档主体的 XML 根节点 <w:body># .iterchildren() 遍历 body 的所有直接子节点for child in document.element.body.iterchildren():
        # CT_P 是 <w:p> 节点，表示一个段落if isinstance(child, CT_P):
            yield Paragraph(child, document)
        # CT_Tbl 是 <w:tbl> 节点，表示一个表格elif isinstance(child, CT_Tbl):
            yield Table(child, document)


# ============================================================# 第四步：提取Word表格的二维数据# ============================================================def extract_table_rows(table: Table) -> list[list[str]]:"""提取Word表格中的二维行列数据，每个单元格的文本内容经过清理。"""return [[normalize_cell(cell.text) for cell in row.cells] for row in table.rows]


# ============================================================# 第五步：提取段落中的嵌入图片# ============================================================def extract_paragraph_images(
    paragraph: Paragraph,
    document: WordDocumentType,
    image_output_dir: Path,
    file_stem: str,
    image_counter: int,
) -> tuple[list[str], int]:"""
    提取段落中嵌入的图片。

    Word 中图片通过 <w:drawing> → <a:blip> 节点引用，
    <a:blip> 的 r:embed 属性保存关系 ID，
    通过关系 ID 可在 document.part.related_parts 中找到对应的图片部件。

    返回值：(当前段落提取出的图片路径列表, 更新后的图片计数器)
    """
    image_paths: list[str] = []

    # paragraph._p 是段落底层的 XML 节点 <w:p># .xpath(".//a:blip") 查找所有 <a:blip> 元素，这是 Word 中图片引用的关键节点# qn("r:embed") 构造带有命名空间的标签名，用于读取 r:embed 属性for blip in paragraph._p.xpath(".//a:blip"):
        # 读取 r:embed 属性，这是图片的关系 ID
        relation_id = blip.get(qn("r:embed"))
        # 没有关系 ID 时跳过if not relation_id:
            continue# 通过关系 ID 找到对应的图片部件
        image_part = document.part.related_parts[relation_id]

        # 从 MIME 类型中提取图片扩展名，如 "image/jpeg" → "jpeg"
        extension = image_part.content_type.split("/")[-1]
        # Word 中的 JPEG 扩展名统一为 "jpg"if extension == "jpeg":
            extension = "jpg"# 全局图片计数器加一
        image_counter += 1# 生成图片文件名：原文件名_image_序号.扩展名
        image_name = f"{file_stem}_image_{image_counter}.{extension}"# 拼接完整输出路径
        image_path = image_output_dir / image_name

        # 将图片二进制数据写入文件
        image_path.write_bytes(image_part.blob)

        # 保存图片绝对路径
        image_paths.append(str(image_path.resolve()))

    return image_paths, image_counter


# ============================================================# 第六步：定义自定义DOCX Loader# ============================================================class RichDocxLoader(BaseLoader):"""
    将DOCX正文、表格行文本和图片引用按原始顺序组装成Document。
    每个DOCX文件产生一个Document。
    """def __init__(self, file_path: Path, image_output_dir: Path) -> None:"""初始化加载器：保存DOCX路径和图片输出目录。"""
        self.file_path = file_path
        self.image_output_dir = image_output_dir

    def lazy_load(self) -> Iterator[Document]:"""
        生成器：按DOCX原始块顺序读取文档，每个DOCX文件产生一个Document。
        使用yield逐个返回，符合BaseLoader接口。
        """# 创建图片输出目录（不存在则递归创建，已存在则忽略）
        self.image_output_dir.mkdir(parents=True, exist_ok=True)

        # 使用python-docx打开Word文档
        word_document = WordDocument(str(self.file_path))

        # 保存最终Document正文的各个部分（段落文本、表格描述、图片Markdown引用）
        content_parts: list[str] = []

        # 保存所有提取后的图片路径
        image_paths: list[str] = []

        # 识别到的表格数量
        table_count = 0# 图片计数器，用于生成唯一文件名
        image_counter = 0# 按照DOCX内部XML顺序遍历段落和表格（段落1 → 表格1 → 段落2 → 表格2...）for block in iter_document_blocks(word_document):
            # ========================================================# 处理段落# ========================================================if isinstance(block, Paragraph):
                # 读取当前段落的普通文字
                paragraph_text = block.text.strip()
                # 有文字时，按当前位置加入正文if paragraph_text:
                    # 有文字时，按当前位置加入正文
                    content_parts.append(paragraph_text)

                # 即使段落没有普通文字，也要检查其中是否包含图片# Word中图片可能单独占据一个段落，也可能和文字混排
                paragraph_images, image_counter = extract_paragraph_images(
                    paragraph=block, # 当前段落
                    document=word_document, # 当前文档
                    image_output_dir=self.image_output_dir, # 图片输出目录
                    file_stem=self.file_path.stem, # 原文件名（不扩展名）
                    image_counter=image_counter,  # 图片计数器
                )

                # 将当前段落中的图片按原位置加入正文for image_path in paragraph_images:
                    # 保存图片绝对路径
                    image_paths.append(image_path)
                    # 这样可以确保图片在Markdown中显示时，路径是相对的，而不是绝对的# 例如：![嵌入图片1](image_1.jpg)# 而不是：![嵌入图片1](/path/to/image_1.jpg)
                    image_number = len(image_paths)

                    # 生成Markdown格式的图片引用
                    content_parts.append(f"![嵌入图片{image_number}]({Path(image_path).name})")

            # ========================================================# 处理表格# ========================================================elif isinstance(block, Table):
                table_count += 1# 提取表格二维数据并转换为自然语言陈述句
                rows = extract_table_rows(block)
                row_texts = table_rows_to_text(rows)

                if row_texts:
                    # 识别到表格时，按当前位置加入表格转换后的自然语言陈述句
                    content_parts.append(f"识别表格{table_count}：\n" + "\n".join(row_texts))

        # 生成一个Documentyield Document(
            page_content="\n\n".join(content_parts),
            metadata={
                "source": str(self.file_path.resolve()), # 文档路径"table_count": table_count, # 识别到的表格数量"image_count": len(image_paths), # 识别到的图片数量"images": image_paths, # 图片绝对路径列表
            },
        )


# ============================================================# 第七步：运行Loader并查看Document# ============================================================"""创建Loader，加载DOCX并打印Document结果。"""
loader = RichDocxLoader(
    file_path=FILE_PATH,
    image_output_dir=IMAGE_OUTPUT_DIR
)

# BaseLoader.load() 内部调用 lazy_load() 并收集所有Document
documents = loader.load()

print("Document数量：", len(documents))

for document in documents:
    print("识别表格数：", document.metadata["table_count"])
    print("识别图片数：", document.metadata["image_count"])
    print("图片文件：", [Path(path).name for path in document.metadata["images"]])
    print("\nDocument正文：")
    print(document.page_content)
```

以上代码运行后，结果如下:

![orNqdOAb\.jpg](图片和附件/orNqdOAb.jpg)

## 2\.3\. Text Splitter

向量库通常不会把整本手册保存成一个向量。文档过大时，一个向量会混入多个主题，例如：用户查询退款规则时可能同时召回物流、发票和会员内容；文档过小时，完整条件又会被拆散。这是如何切分文档成为关键。

可以使用Text Splitter对Document进行切分，Text Splitter 的目标不是机械地按字符切开，而是尽量让一个 chunk 表达一个相对完整的知识点。

关于LangChain提供的素有Splitter的API地址如下：https://reference\.langchain\.com/python/langchain\-text\-splitters/langchain\_text\_splitters

### 2\.3\.1\. RecursiveCharacterTextSplitter

RecursiveCharacterTextSplitter 是 LangChain 官方推荐的通用文本分割器。它的核心设计目标是在将长文档切分为适合向量检索和模型上下文窗口的小块时，最大限度地保持语义的完整性

RecursiveCharacterTextSplitter 使用形式如下：

```Plain Text
from langchain_text_splitters import RecursiveCharacterTextSplitterdocuments = [
    Document(
        page_content="退货规则：收货后七日内可以申请无理由退货，商品、包装和配件需要保持完整。",
        metadata={"source": "售后规则.md"},
    ),
    Document(
        page_content="退款规则：仓库验收通过后发起原路退款，通常三个工作日内到账。",
        metadata={"source": "退款规则.md"},
    ),
    Document(
        page_content="物流规则：订单发货后可以在订单详情查看物流轨迹。",
        metadata={"source": "物流规则.md"},
    ),
]

splitter = RecursiveCharacterTextSplitter(
    chunk_size=80,
    chunk_overlap=12,
    separators=["\n\n", "\n", "。", "；", "，", ""],
)

chunks = splitter.split_documents(documents)
```

RecursiveCharacterTextSplitter 默认按字符长度计算，chunk\_size 控制单个片段大小，chunk\_overlap 控制相邻片段的重叠。

中文制度或产品规则可以优先使用如下分隔顺序：

```Plain Text
separators=["\n\n", "\n", "。", "；", "，", ""]
```

这表示先按段落和换行切分，再按句号、分号和逗号切分，最后才按字符切分。

### 2\.3\.2\. CharacterTextSplitter

CharacterTextSplitter 按指定分隔符切分文本，默认分隔符通常是：“\\n\\n”,它的特点是规则简单、行为直接：按照指定分隔符切分文本。使用方式如下：

```Plain Text
from langchain_text_splitters import CharacterTextSplittersplitter = CharacterTextSplitter(
    separator="\n\n",
    chunk_size=500,
    chunk_overlap=50,
)

chunks = splitter.split_documents(documents)
```

CharacterTextSplitter适用场景：文本格式非常规整；文档结构明确以某个分隔符进行分割；简单的段落切分。

绝大多数场景，推荐优先使用 RecursiveCharacterTextSplitter 。

### 2\.3\.3\. TokenTextSplitter

TokenTextSplitter 按 Token 数量切分，而不是按 Python 字符数量切分。使用方式如下：

```Plain Text
from langchain_text_splitters import TokenTextSplittersplitter = TokenTextSplitter(
    chunk_size=500,
    chunk_overlap=50,
)

chunks = splitter.split_documents(documents)
```

适合场景：大模型批处理中，精确控制单纯模型输入Token长度场景。

特别需要注意：中文、日文等语言中的一个字符可能对应多个 Token。直接使用 TokenTextSplitter 时，极端情况下可能把字符的 Token 拆到不同 chunk，造成 Unicode 字符异常。因此中文场景中，通常更建议使用RecursiveCharacterTextSplitter。

### 2\.3\.4\. MarkdownHeaderTextSplitter

MarkdownHeaderTextSplitter 按 Markdown 标题层级切分文档，例如：

```Plain Text
# 第1章：RAG介绍
## 1.1 RAG是什么

正文……

## 1.2 RAG工作原理

正文……
```

可以按照如下这种形式切分：

```Plain Text
headers_to_split_on = [
    ("#", "Header 1"),
    ("##", "Header 2"),
    ("###", "Header 3"),
]
```

它不仅将正文拆开，还会把标题信息保存到每个 Document\.metadata 中。例如：

```Plain Text
Document(
    page_content="RAG是检索增强生成……",
    metadata={
        "Header 1": "第1章：RAG介绍",
        "Header 2": "1.1 RAG是什么",
    },
)
```

使用方式如下：

```Plain Text
from langchain_text_splitters import MarkdownHeaderTextSplitterheaders_to_split_on = [
    ("#", "Header 1"),
    ("##", "Header 2"),
    ("###", "Header 3"),
]

splitter = MarkdownHeaderTextSplitter(
    headers_to_split_on=headers_to_split_on,
    strip_headers=False, #是否移除标题行，True表示移除，False表示不移除
)

documents = splitter.split_text(
    markdown_text
)
```

适合场景：Markdown格式相关文档。

### 2\.3\.5\. HTMLHeaderTextSplitter

HTMLHeaderTextSplitter 按 HTML 标题标签切分，例如：

```Plain Text
<h1>售后服务</h1><h2>退款规则</h2><p>仓库验收通过后发起退款。</p>
```

它可以根据\<h1\>、\<h2\>、\<h3\>等标题标签来此份，并将标题信息写入metadata,如下：

```Plain Text
Document(
    page_content="仓库验收通过后发起退款。",
    metadata={
        "Header 1": "售后服务",
        "Header 2": "退款规则",
    },
)
```

适用场景：带有明确 \<h1\>、\<h2\> 层级的网页内容。

### 2\.3\.6\. HTMLSectionSplitter

该Splitter不是只按标题切分，而是更倾向于按 HTML 区块切分，例如按照\<section\>、\<div\>、\<h1\>、\<h2\>切分。适用于想保留较大的html页面段落，不希望每个标题都立即生成一个 chunk。

### 2\.3\.7\. HTMLSemanticPreservingSplitter

HTMLSemanticPreservingSplitter是 HTML 场景中更关注语义完整性的 Splitter。它可以尽量保持以下结构不被拆散：

- 表格

- 列表

- 其他 HTML 元素

- 图片、视频等媒体元素

例如一个 HTML 页面中有：

```Plain Text
<table><tr><td>退款时效</td><td>三个工作日</td></tr></table>
```

如果普通字符切分把表头和数据拆开，检索效果会下降。此时更适合使用HTMLSemanticPreservingSplitter 对 HTML 表格和列表进行结构保护。

### 2\.3\.8\. RecursiveJsonSplitter

RecursiveJsonSplitter 专门处理 JSON结构内容，不是简单地把 JSON 字符串按字符截断，而是尽量保留 JSON 的层级结构：

```Plain Text
{
  "user": {
    "name": "张三",
    "orders": [
      {
        "id": "A001",
        "status": "已退款"
      }
    ]
  }
}
```

它会尽量按嵌套对象、数组元素等结构拆分，同时保持父子层级关系。

使用方式如下：

```Plain Text
from langchain_text_splitters import RecursiveJsonSplitter,

splitter = RecursiveJsonSplitter(
    max_chunk_size=500
)

chunks = splitter.split_json(json_data)

# 可以得到 JSON 字符串
json_chunks = splitter.split_text(json_data)
```

## 2\.4\. 基于Embedding的语义Splitter

以上各个Text Splitter 都不是根据语义进行切分Document，LangChain之前支持SemanticChunker，可以根据句子语义来切分Document，但目前由于架构调整目前已经过时。

如果我们应用场景对分块的语义连贯性有极致要求，且可以接受额外的计算成本和开发工作量，可以自行实现一个轻量级的语义分块器，从而获得更强、更个性化的控制力。

基于Embedding语义Splitter实现核心思路如下：

1. 将原始文档按照中文句末标点切成句子（如。！？；）

2. 使用Embedding模型为每个句子生成向量

3. 计算相邻句子的余弦距离，距离明显变大的位置作为语义断点

4. 最终生成多个按照语义分割的Document

特别提示：语义切分比固定字符切分更灵活，但不代表它一定能准确识别所有主题边界。Embedding 模型、阈值、句子长度和文档内容都会影响结果，所以必须结合真实输出评估。

完整基于Embedding语义Splitter实现代码如下：

```Plain Text
from __future__ import annotations

import re
from dataclasses import dataclass

import numpy as np
from langchain_community.embeddings import DashScopeEmbeddings
from langchain_core.documents import Document
from env_utils import DASHSCOPE_API_KEY

# ============================================================# 第一步：定义语义分析结果# ============================================================@dataclassclass SemanticSplitAnalysis:"""保存语义切分过程中的中间结果。"""
    sentences: list[str] # 原始句子列表
    distances: list[float] # 相邻句子Embedding距离列表
    threshold: float # 语义断点阈值
    break_after: list[int] # 语义断点索引列表# ============================================================# 第二步：定义自定义语义Splitter# ============================================================class EmbeddingSemanticTextSplitter:"""根据相邻句子Embedding距离自动寻找语义断点。"""def __init__(
        self,
        embeddings,
        breakpoint_percentile: float = 75.0,
        min_sentences: int = 3,
        max_chunk_chars: int = 180,
    ) -> None:
        self.embeddings = embeddings # 用于计算Embedding距离的模型
        self.breakpoint_percentile = breakpoint_percentile # 用于计算语义断点的距离分位数
        self.min_sentences = min_sentences # 限制每个chunk至少包含多少个句子，避免因为局部距离过大而产生过短chunk。
        self.max_chunk_chars = max_chunk_chars # chunk的最大字符数def split_sentences(self,text: str,) -> list[str]:"""按照中文句末标点切分文本，并保留完整句子。"""# 去除换行、空格和制表符，避免它们影响句子匹配
        text = re.sub(r"\s+","",text,)

        # 按中文句号、问号、感叹号和分号切分# 查找字符串中所有符合括号内模式的内容，返回一个字符串列表, ".+?" 是非贪婪匹配任意字符（至少一个）# 这里从当前位置开始，一个一个字符地读，遇到 。！？； 或读到字符串末尾就停下，# 把读到的内容作为一个结果返回。然后再从停下的地方继续往后找，直到整个文本处理完。
        sentences = re.findall(r".+?(?:[。！？；]|$)",text,)

        # 过滤空字符串return [sentence for sentence in sentences if sentence]

    def cosine_distance(self,vector_a: np.ndarray,vector_b: np.ndarray,) -> float:"""
        计算两个向量的余弦距离。
        距离越小：两个句子的语义越接近。
        距离越大：两个句子的语义变化越明显。
        """# 计算两个向量长度的乘积# np.linalg.norm(v)：计算向量的 L2 范数（欧几里得长度），公式为 sqrt(sum(v_i²))
        denominator = (np.linalg.norm(vector_a) * np.linalg.norm(vector_b))

        # 如果向量为空，直接认为差异最大if denominator == 0:
            return 1.0# 计算余弦相似度# np.dot(vector_a, vector_b)：两个向量的点积，公式为 Σ a_i · b_i
        similarity = float(np.dot(vector_a, vector_b) / denominator )

        # 避免浮点误差导致数值略微超过[-1, 1]
        similarity = max(-1.0,min(1.0, similarity),)

        # 余弦距离 = 1 - 余弦相似度return 1.0 - similarity

    def analyze(self,sentences: list[str],) -> SemanticSplitAnalysis:"""
        计算相邻句子的语义距离，并选择候选断点。
        """# 少于两个句子时，无法计算相邻句子距离if len(sentences) < 2:
            return SemanticSplitAnalysis(
                sentences=sentences, # 原始句子列表
                distances=[], # 相邻句子Embedding距离列表
                threshold=float("inf"), # 语义断点阈值
                break_after=[], # 语义断点索引列表
            )

        # 调用真实Embedding模型，为所有句子生成向量
        vectors = self.embeddings.embed_documents(sentences)

        # 将Python列表转换为NumPy数组，方便计算向量距离# np.asarray(vector,dtype=np.float32) : 将vector转换为NumPy数组，每个元素数据类型为float32
        arrays = [np.asarray(vector,dtype=np.float32,) for vector in vectors]

        # 计算相邻句子之间的余弦距离
        distances = [
            self.cosine_distance(arrays[index],arrays[index + 1],)
            for index in range(len(arrays) - 1)
        ]

        # 根据距离分布计算断点阈值# np.percentile(x,y) : 计算x中y百分位数的值。首先会根据 x 由小到大排序，然后找到第y百分位数的值。# x 假设为 [0.10, 0.12, 0.80, 0.85, 0.90] ，y 假设为75，那么第75%分位数为0.85。# 这里就是根据各个句子之间的距离，根据用户指定的分位数，动态计算阈值作为语义断点阈值。# breakpoint_percentile 取值越高，表示只有距离极大的相邻句子（这些句子语义无关）才会被断点切分，chunk 更长，切分更保守；# breakpoint_percentile 取值越低，表示距离较小的相邻句子（这些句子语义更相关）也会被断点切分，chunk 更短，切分更激进。
        threshold = float(np.percentile(np.asarray(distances),self.breakpoint_percentile,))

        # 距离大于等于阈值的位置，作为候选语义断点# candidates 的值例如：[2, 4, 10, 20]
        candidates = [index for index, distance in enumerate(distances) if distance >= threshold]

        # 控制相邻断点之间至少保留一定数量的句子
        break_after: list[int] = []

        # 第一个候选点从索引-1开始（表示第一个句子之前）
        previous_break = -1for index in candidates:
            # 如果距离上一个断点太近，则跳过当前断点if (index - previous_break) >= self.min_sentences:
                break_after.append(index)
                # 更新上一个断点位置
                previous_break = index

        return SemanticSplitAnalysis(
            sentences=sentences, # 原始句子列表
            distances=distances, # 相邻句子Embedding距离列表
            threshold=threshold, # 语义断点阈值
            break_after=break_after, # 语义断点索引列表
        )

    def split_document(self,document: Document,) -> tuple[list[Document],SemanticSplitAnalysis,]:"""
        对一个Document执行语义切分。

        返回：
        1. 切分后的Document列表；
        2. 语义距离和断点分析结果。
        """# 第一步：把正文切分成句子
        sentences = self.split_sentences(document.page_content)

        # 第二步：计算句子之间的语义距离
        analysis = self.analyze(sentences)

        # 保存最终的句子分组
        groups: list[list[str]] = []

        # 保存当前chunk中的句子
        current: list[str] = []

        # 统计当前chunk字符数
        current_length = 0# 逐句构造chunkfor index, sentence in enumerate(analysis.sentences):
            # 将当前句子加入正在构建的chunk
            current.append(sentence)

            # 累加当前chunk长度
            current_length += len(sentence)

            # 判断当前是否为最后一个句子
            is_last = ( index == len(analysis.sentences) - 1 )

            # 计算下一个句子的长度
            next_length = (len(analysis.sentences[index + 1]) if not is_last else 0)

            # 判断继续加入下一个句子后是否超过长度上限
            exceeds_limit = (not is_last and current_length + next_length > self.max_chunk_chars)

            # 判断当前位置是否是语义断点
            semantic_break = (index in analysis.break_after and len(current) >= self.min_sentences)

            # 满足以下任意条件，就结束当前chunk：# 1. 已经处理到最后一个句子；# 2. 当前句子后出现语义断点；# 3. 继续加入下一个句子会超出长度限制。if is_last or semantic_break or exceeds_limit:
                groups.append(current)
                current = []
                current_length = 0# 将句子分组转换成Document
        chunks: list[Document] = []

        # 记录当前chunk对应的起始句子索引
        sentence_cursor = 0for chunk_index, group in enumerate(groups):
            # 当前chunk的起始句子索引
            start = sentence_cursor

            # 移动句子游标
            sentence_cursor += len(group)

            # 当前chunk的结束句子索引
            end = sentence_cursor - 1# 创建新的Document
            chunks.append(
                Document(
                    # 将同一个chunk中的句子拼接起来
                    page_content="".join(group),

                    # 保留原Document的metadata，# 同时追加语义切分信息
                    metadata={
                        **document.metadata,
                        "splitter": "embedding_semantic_splitter",
                        "chunk_index": chunk_index,
                        "sentence_start": start,
                        "sentence_end": end,
                        "breakpoint_percentile": self.breakpoint_percentile,
                        "breakpoint_threshold": round(analysis.threshold,6,),
                        "max_chunk_chars": self.max_chunk_chars,
                    },
                )
            )

        return chunks, analysis

    def split_documents(self,documents: list[Document],) -> list[Document]:"""
        按照LangChain常见Splitter接口，
        批量切分多个Document。
        """
        chunks: list[Document] = []

        for document in documents:
            document_chunks, _ = self.split_document(document)
            chunks.extend(document_chunks)

        return chunks


# ============================================================# 第四步：运行语义Splitter# ============================================================def main() -> None:# ========================================================# 第一步：初始化真实Embedding模型# ========================================================
    embedding_model = DashScopeEmbeddings(
        model="text-embedding-v1",
        dashscope_api_key=DASHSCOPE_API_KEY,
    )

    # ========================================================# 第二步：准备多个业务主题的售后文档# ========================================================
    source_document = Document(
        page_content=(
            "退货规则：收货后七日内可以申请无理由退货，""商品、包装和配件需要保持完整。""退货申请提交后，客服会在一个工作日内完成审核。""审核通过后，用户需要将商品寄回指定仓库。""退款规则：仓库验收通过后发起原路退款，""通常三个工作日内到账。""如果商品存在质量问题，""退款申请需要附上相关照片。""退款会按照原支付渠道原路退回。""物流规则：订单发货后可以在订单详情查看物流轨迹。""物流信息通常会在包裹揽收后更新。""如果物流超过三天没有更新，""需要联系人工客服查询。""保修规则：耳机主机提供一年有限保修服务。""人为损坏和进水造成的故障不属于免费保修范围。""申请保修时需要提供订单号和故障说明。"
        ),
        metadata={"source": "售后规则.md"},
    )

    # ========================================================# 第三步：创建自定义语义Splitter# ========================================================
    splitter = EmbeddingSemanticTextSplitter(
                embeddings=embedding_model, # 语义模型
                breakpoint_percentile=75.0, # 断点百分比
                min_sentences=3, # 最小句子数量
                max_chunk_chars=180, # 最大chunk字符数
               )

    # 对整个Document执行一次切分,这里同时拿到切分结果和语义分析结果，# 方便打印距离和断点。
    chunks, analysis = splitter.split_document(source_document)

    print("句子数量：",len(analysis.sentences),)

    print("相邻句子语义距离：")
    for index, distance in enumerate(analysis.distances):
        print(f"句子{index} -> 句子{index + 1}:{distance:.6f}")

    print("断点阈值：",f"{analysis.threshold:.6f}",)
    print("语义断点索引列表：",analysis.break_after,)
    print("Document数量：",len(chunks),)

    for index, chunk in enumerate(chunks):
        print(f"Document{index}：{chunk.page_content}")
        print("metadata：",chunk.metadata,)


if __name__ == "__main__":
    main()
```

该代码中自定义根据语义切分的splitter为EmbeddingSemanticTextSplitter，后续完全可以复复用。用户可以传入embedding、breakpoint\_percentile、min\_sentences、max\_chunk\_chars参数，这几个参数解释如下：

1. embedding:用于计算Embedding距离的模型

2. breakpoint\_percentile:用于计算语义断点的距离分位数,取值1\-100之间，取值越高，表示只有距离极大的相邻句子（这些句子语义无关）才会被断点切分，chunk 更长，切分更保守；取值越低，表示距离较小的相邻句子（这些句子语义更相关）也会被断点切分，chunk 更短，切分更激进。

3. min\_sentences：限制每个chunk至少包含多少个句子，避免因为局部距离过大而产生过短chunk。

4. max\_chunk\_chars：切分每个chunk的字符数。

用法形式如下：

```Plain Text
splitter = EmbeddingSemanticTextSplitter(
            embeddings=embedding_model, # 语义模型
            breakpoint_percentile=75.0, # 断点百分比
            min_sentences=3, # 最小句子数量
            max_chunk_chars=180, # 最大chunk字符数
           )

# 对整个Document执行一次切分,这里同时拿到切分结果和语义分析结果
chunks, analysis = splitter.split_document(source_document)
```

返回的chunks是按照语义切分后的Document列表；analysis是语义距离和断点分析结果。

以上代码运行后，可以看到输出结果如下：

![xKRFud1T\.jpg](图片和附件/xKRFud1T.jpg)

## 2\.5\. Embedding嵌入

### 2\.5\.1\. Embedding介绍

Embedding Model（本章通过 DashScope/阿里云模型服务调用 text\-embedding\-v1）将文本转换成数值向量。语义相近的文本通常在向量空间中更接近，Vector Store 就是根据这种距离寻找相关文档。

文档入库和用户查询必须处于同一兼容的向量空间，并遵循模型规定的 query/document 编码方式。最简单的做法是二者使用同一个 Embedding Model；如果模型、向量维度或预处理方式发生不兼容变化，原有文档通常需要重新生成向量。更换 Embedding 后，原有索引也要重新构建或迁移。

Embedding 与 Chat Model 的职责不同：Embedding 输出向量，用于检索；Chat Model 输出文字，用于生成回答。二者可以来自同一个模型供应商，也可以来自不同供应商。

### 2\.5\.2\. 常见Embedding Model与选型

选择 Embedding Model 时，主要4个维度：

1. 部署方式：云 API 上手快、免运维；开源模型可私有化，但需要 GPU 和向量化流水线。

2. 向量维度：维度越高信息容量越大，存储和检索成本也越高。

3. 最大输入长度：长文档适合 8192 Token 以上的模型。

4. 语言支持：中文业务优先中文/多语模型，纯英文场景可选英文专用模型。

下面是当前市面上常见 Embedding Model 的选型对比，参数以官方文档为准：

以上模型对应的官网链接如下：

- 阿里云百炼：https://help\.aliyun\.com/zh/model\-studio/embedding\-rerank\-model

- OpenAI:https://developers\.openai\.com/api/docs/models

- 智普：https://docs\.bigmodel\.cn/cn/guide/models/embedding/embedding\-3

- Qwen3\-Embedding\-8B：https://huggingface\.co/Qwen/Qwen3\-Embedding\-8B

- BGE\-M3：https://huggingface\.co/BAAI/bge\-m3

选型结论：

- 纯文本中文 RAG，且希望减少运维：优先阿里云 text\-embedding\-v4 或智谱 embedding\-3。

- 需要私有化部署：优先 BGE\-M3 或 Qwen3\-Embedding 系列，按可用 GPU 选择 0\.6B/4B/8B。

- 文档特别长：优先 qwen3\.7\-text\-embedding\-flash（131K）。

- 更换 Embedding Model 意味着向量空间变化，必须重新生成文档向量并重建索引，不能只改一个模型名。

### 2\.5\.3\. Embedding接口

Embedding 接口主要包含如下两个方法：

```Plain Text
embed_documents(texts: list[str]) -> list[list[float]]
embed_query(text: str) -> list[float]
```

embed\_documents\(\) 批量处理文档，embed\_query\(\) 处理用户问题。生产环境应优先批量生成文档向量，避免逐条请求造成额外延迟。

## 2\.6\. Vector Store向量存储

### 2\.6\.1\. Vector Store介绍

Vector Store 通常通过统一接口管理文档向量及其关联的文本和 metadata，并提供新增、查询、删除等操作。具体存储布局由后端决定；生产系统也可以把向量和 metadata 放在向量库，把完整原文放在对象存储或文档库。LangChain 使用统一的 Vector Store 接口连接不同后端，例如 InMemoryVectorStore、FAISS、Chroma、Qdrant、Milvus 和 PGVector。

### 2\.6\.2\. InMemoryVectorStore案例

本小节用 InMemoryVectorStore 演示完整流程，InMemoryVectorStore 的数据只保存在当前 Python 进程中，程序退出后不会持久化，因此不适合生产知识库。

下面使用千问 text\-embedding\-v1 将退款和物流资料写入 InMemoryVectorStore，再通过 similarity\_search\_with\_score\(\) 查看真实语义检索分数。

```Plain Text
from env_utils import DASHSCOPE_API_KEYfrom langchain_community.embeddings import DashScopeEmbeddingsfrom langchain_core.documents import Documentfrom langchain_core.vectorstores import InMemoryVectorStore


# ============================================================
# 第一步：初始化千问Embedding模型
# ============================================================embedding_model = DashScopeEmbeddings(
    model="text-embedding-v1",
    dashscope_api_key=DASHSCOPE_API_KEY,
)


# ============================================================
# 第二步：准备需要写入向量库的业务文档
# ============================================================documents = [
    Document(
        page_content="退款规则：仓库验收通过后发起原路退款，通常三个工作日内到账。",
        metadata={"source": "退款规则.md"},
    ),
    Document(
        page_content="物流规则：订单发货后可以在订单详情查看物流轨迹。",
        metadata={"source": "物流规则.md"},
    ),
]


# ============================================================
# 第三步：创建内存向量库并写入文档
# ============================================================vector_store = InMemoryVectorStore(embedding_model)
# 写入文档到向量库
document_ids = vector_store.add_documents(documents)
print("写入文档数量：", len(document_ids))

if __name__ == "__main__":
    # 第四步：确认千问Embedding返回的向量维度
    question = "退款什么时候到账？"query_vector = embedding_model.embed_query(question)
    print("Embedding模型：text-embedding-v1")
    print("查询向量维度：", len(query_vector))


    # 第五步：使用千问语义向量查询文档
    results = vector_store.similarity_search_with_score(question, k=2)
    print("检索结果：")
    for document, score in results:
        print(f"- score={float(score):.4f} | {document.metadata['source']} | {document.page_content}")
```

以上代码运行输出结果如下：

![P9qGrCXE\.jpg](图片和附件/P9qGrCXE.jpg)

以上代码注意如下几点：

1. InMemoryVectorStore\(embedding\_model\)：创建一个内存向量库实例，传入 Embedding 模型。当调用add\_documents时，向量库会自动调用 embedding\_model\.embed\_documents\(\) 将每个 Document\.page\_content 转换成向量，并与原文、metadata 一起保存。

2. add\_documents 返回每个文档在向量库中的内部 ID（字符串列表），用于后续追踪或删除。

3. embed\_query\(\) 将用户问题转换成向量，与文档向量处于同一语义空间。这里打印维度的主要目的是验证模型配置是否正确

4. similarity\_search\_with\_score\(\) 是向量库的检索方法（vector\_store\.similarity\_search底层调用就是该方法），参数 k 控制返回的文档数量。它会计算查询向量与库中所有文档向量的余弦相似度，按得分从高到低排序，返回 \(Document, score\) 元组列表。

### 2\.6\.3\. 向量数据库Milvus

Milvus 是一个开源的高性能向量数据库（Vector Database），专为存储、索引和检索高维向量数据而设计，它能够处理图像、音频、视频、自然语言等嵌入表示（embeddings），支持海量向量（万亿级）毫秒级相似搜索。

Milvus 是 RAG 系统中的核心基础设施之一，Milvus 在RAG过程中可以担当“VectorStore”的角色，能够精准语义检索，查询到相关文档。Milvus文档地址：[https://milvus\.io/docs/zh](https://milvus.io/docs/zh,Milvus)

#### 2\.6\.3\.1\. Milvus Standalone搭建

Milvus支持三种方式搭建：

- Milvus Lite:作为 Python 库本地嵌入（类似“向量版 SQLite”）,支持百万级别向量存储，适合快速学习。

- Milvus Standalone（单机版）:Docker 中运行，所有组件（Milvus \+ etcd）打包在一台主机内，支持10亿向量存储，适合中小型生产环境。

- Milvus Distributed（分布式集群）:部署在 Kubernetes 环境，通过 Proxy、Query、Index 等节点分离，实现高可用与弹性伸缩，支持百亿向量存储，适合大规模、高可用或K8s部署。

这里我们搭建Milvus Standalone 版本，所以需要预先准备一台Linux节点（默认已准备好），按照如下步骤在Linux节点中安装Docker并部署Milvus。

1\) **在Linux中安装docker**

这里在node2安装docker。获取docker repo文件，如下源只选一个即可。

```Plain Text
#从阿里源获取docker repo文件
wget -O /etc/yum.repos.d/docker-ce.repo https://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo

#从清华源获取docker repo文件
wget -O /etc/yum.repos.d/docker-ce.repo  https://mirrors.tuna.tsinghua.edu.cn/docker-ce/linux/centos/docker-ce.repo

#从docker官方源获取docker repo文件
wget -O /etc/yum.repos.d/docker-ce.repo  https://download.docker.com/linux/centos/docker-ce.repo
```

查看docker可以安装的版本：

```Plain Text
yum list docker-ce.x86_64 --showduplicates | sort -r
```

安装docker:这里指定docker版本为26\.1\.4版本:

```Plain Text
yum -y install docker-ce-26.1.4-1.el7
```

设置docker 开机启动，并启动docker：

```Plain Text
systemctl enable docker
systemctl start docker
```

查看docker版本

```Plain Text
docker version
```

修改cgroup方式，并重启docker。

```Plain Text
vim /etc/docker/daemon.json
{
        "exec-opts": ["native.cgroupdriver=systemd"],
        "registry-mirrors":[
          "https://docker.m.daocloud.io",
          "https://docker.rainbond.cc",
          "https://docker.lmirror.top",
          "https://docker.xuanyuan.me",
          "https://docker.1ms.run",
          "https://registry.docker-cn.com"
       ]
}

#重启docker
systemctl restart docker
```

2\) **使用docker compose 安装Milvus**

```Plain Text
#创建目录并进入mkdir -p /software/milvus && cd /software/milvus

#下载compose 配置,或者直接将资料中 docker-compose.yml上传至目录下wget https://github.com/milvus-io/milvus/releases/download/v2.5.14/milvus-standalone-docker-compose.yml -O docker-compose.yml


# 由于minio镜像迁移其他地址，所以这里修改 docker-compose.yml文件中minio的镜像地址，将minio的镜像地址改为：milvusdb/minio:RELEASE.2024-05-28T17-19-04Z#启动 Milvusdocker compose up -d

#停止Milvusdocker compose down
```

3\) **访问Milvus WebUI**

浏览器输入 [http://node2:9091/webui/](http://node2:9091/webui/) 查看Milvus WebUI。

![4WGJHkfd\.jpg](图片和附件/4WGJHkfd.jpg)

4\) **安装 attu可视化操作Milvus**

Attu是一款专为Milvus向量数据库打造的开源数据库管理工具，提供了便捷的图形化界面，极大地简化了对Milvus数据库的操作与管理流程。

双击资料中“attu\-Setup\-2\.5\.12\.exe”进行Attu安装，安装完成后进入Attu并连接Milvus：

![cLkTNHfK\.jpg](图片和附件/cLkTNHfK.jpg)

![n3KWhUQg\.jpg](图片和附件/n3KWhUQg.jpg)

#### 2\.6\.3\.2\. Milvus 核心概念

Milvus核心概念有数据库、Collections、Schema、Field、Entity、索引，下面分别介绍。

1. **数据库**

在 Milvus 中，数据库是组织和管理数据的逻辑单元。为了提高数据安全性并实现多租户，你可以创建多个数据库，为不同的应用程序或租户从逻辑上隔离数据。例如，创建一个数据库用于存储用户 A 的数据，另一个数据库用于存储用户 B 的数据。与关系型数据库中所说的数据库一个概念。

2. **Collections**

在 Milvus 中，Collection 可以比作关系存储系统中的表。Collections 是 Milvus 中最大的数据单元，在 Milvus 中，所有数据都是按 Collections（集合）、shard（分片）、partition（分区）、segment（数据片段） 和 entity （数据实体，一行数据就是一个实体）组织的。

![SiKY8WKC\.jpg](图片和附件/SiKY8WKC.jpg)

为了在写入数据时充分利用集群的并行计算能力，Milvus 中的 Collection 必须将数据写入操作分散到不同的节点上，默认情况下，一个 Collections 包含两个分片，根据你的数据集容量，你可以在一个 Collection 中拥有更多的分片。Milvus 使用主密钥散列方法进行分片。关于Milvus数据模型参考：https://milvus\.io/zh/blog/deep\-dive\-1\-milvus\-architecture\-overview\.md\#Shard

Collection 是一个二维表，具有固定的列和变化的行。每列代表一个字段，每行代表一个实体。下图显示了一个有 8 列和 6 个实体的 Collection。

![JHGd2zFh\.jpg](图片和附件/JHGd2zFh.jpg)

3. **Schema**

Schema 定义了 Collections 的数据结构。在创建一个 Collection 之前，你需要设计出它的 Schema，定义如何组织 Collection 中的数据。一个 Collection Schema 有一个主键、最多四个向量字段和几个标量字段。下图说明了如何将文章映射到模式字段列表。

![gOoYEiLo\.jpg](图片和附件/gOoYEiLo.jpg)

Milvus支持的更多类型参考：https://milvus\.io/docs/zh/schema\.md

4. **Field**

一列，例如 id、text、vector。

5. **Entity**

一行数据，一个实体就是一条记录。

6. **索引**

向量字段必须配置索引才能高效检索，例如 AUTOINDEX

7. **数据一致性**

Milvus 提供了四种一致性级别，允许用户在数据一致性和查询延迟之间做出平衡选择：

- Strong：最强一致性，保证读取到最新数据，但查询延迟较高。

- Bounded：有界一致性，默认级别，允许轻微延迟，满足大多数场景使用。

- Session:会话一致性，保证在同一客户端会话中读取到自己写入的数据，跨会话数据可能不一致。

- Eventually：最终一致性，相应查询最快，数据一致性最弱，适用于实时监控、日志展示等。

关于以上一致性的原理参考：[https://milvus\.io/docs/zh/tune\_consistency\.md\#Set\-Consistency\-Level\-upon\-Creating\-Collection。](https://milvus.io/docs/zh/tune_consistency.md#Set-Consistency-Level-upon-Creating-Collection%E3%80%82)

### 2\.6\.4\. Milvus VectorStore案例

本案例用Milvus进行数据存储，演示Milvus中增删改查数据，并进行向量化后数据查询。

```Plain Text
# Milvus原生建表与增删改查# 使用 pymilvus.MilvusClient 原生API，在默认数据库完成CRUD全流程。from env_utils import DASHSCOPE_API_KEY
from langchain_community.embeddings import DashScopeEmbeddings
from pymilvus import DataType, MilvusClient


# ============================================================# 第一步：连接 Milvus# ============================================================

MILVUS_URI = "http://192.168.179.5:19530"
MILVUS_DB = "default"
COLLECTION_NAME = "rag_milvus_crud"

embedding_model = DashScopeEmbeddings(
    model="text-embedding-v1",
    dashscope_api_key=DASHSCOPE_API_KEY,
)

client = MilvusClient(
    uri=MILVUS_URI,
    db_name=MILVUS_DB
)


def main() -> None:print("Milvus服务版本：", client.get_server_version())
    print("连接数据库：", MILVUS_DB)
    print("连接前集合：", client.list_collections())

    # 如果集合已存在，先删除if client.has_collection(COLLECTION_NAME):
        client.drop_collection(COLLECTION_NAME)

    try:
        # ====================================================# 第二步：建表# ====================================================# 确认向量维度
        dimension = len(embedding_model.embed_query("测试文本"))

        schema = client.create_schema(
            auto_id=False,
            enable_dynamic_field=False
        )

        schema.add_field(
            "id",
            DataType.INT64,
            is_primary=True
        )

        schema.add_field(
            "text",
            DataType.VARCHAR,
            max_length=1000
        )

        schema.add_field(
            "source",
            DataType.VARCHAR,
            max_length=200
        )

        schema.add_field(
            "vector",
            DataType.FLOAT_VECTOR,
            dim=dimension
        )

        # 构建索引
        index_params = client.prepare_index_params()
        # 给 vector 字段添加索引
        index_params.add_index(
            field_name="vector",
            index_type="AUTOINDEX",
            metric_type="COSINE",
        )

        # 创建集合
        client.create_collection(
            collection_name=COLLECTION_NAME,
            schema=schema,
            index_params=index_params,
        )

        print("建表完成：", COLLECTION_NAME, "| 向量维度：", dimension)

        # ====================================================# 第三步：插入数据# ====================================================
        rows = [
            {
                "id": 1,
                "text": "退款规则：仓库验收通过后发起原路退款，通常三个工作日内到账。",
                "source": "退款规则.md",
            },
            {
                "id": 2,
                "text": "物流规则：订单发货后可以在订单详情查看物流轨迹。",
                "source": "物流规则.md",
            },
            {
                "id": 3,
                "text": "退货规则：收货后七日内可以申请无理由退货。",
                "source": "退货规则.md",
            },
        ]

        # 得到文档的向量表示
        vectors = embedding_model.embed_documents([row["text"] for row in rows])

        # 原始数据合并向量，并插入集合
        data = [{**row, "vector": vector} for row, vector in zip(rows, vectors)]
        client.insert(
            collection_name=COLLECTION_NAME,
            data=data
        )

        # 确保插入的数据已经写入Milvus
        client.flush(COLLECTION_NAME)
        # 将Collection加载到内存以供搜索
        client.load_collection(COLLECTION_NAME)
        print("插入实体数：", client.get_collection_stats(COLLECTION_NAME).get("row_count"))

        # ====================================================# 第四步：向量检索# ====================================================
        query_vector = embedding_model.embed_query("退款多久到账？")

        hits = client.search(
            collection_name=COLLECTION_NAME,
            data=[query_vector],
            limit=3,
            output_fields=["id", "text", "source"],
        )
        print("向量检索结果：")
        for hit in hits[0]:
            print("hit:",hit)
            entity = hit["entity"]
            print("- id=", entity["id"], "score=", round(hit["distance"], 4), "|", entity["text"])

        # ====================================================# 第五步：标量过滤# ====================================================
        resp = client.query(
            collection_name=COLLECTION_NAME,
            filter='source == "退款规则.md"',
            output_fields=["id", "text", "source"],
        )
        print("标量过滤结果：")
        for item in resp:
            print("- id=", item["id"], "source=", item["source"], "|", item["text"])

        # ====================================================# 第六步：更新# ====================================================
        client.upsert(
            collection_name=COLLECTION_NAME,
            data=[
                {
                    "id": 2,
                    "text": "物流规则：订单发货后可以在订单详情查看物流轨迹，签收后自动完成。",
                    "source": "物流规则.md",
                    "vector": embedding_model.embed_query(
                        "物流规则：订单发货后可以在订单详情查看物流轨迹，签收后自动完成。"
                    ),
                }
            ],
        )
        # 确保更新的数据已经写入Milvus
        client.flush(COLLECTION_NAME)
        resp2 = client.get(
            collection_name=COLLECTION_NAME,
            ids=[2], # 查询id=2的实体
            output_fields=["id", "text", "source"],
        )
        print("更新结果（id=2）：")
        for item in resp2:
            print("- id=", item["id"], "source=", item["source"], "|", item["text"])

        # ====================================================# 第七步：删除# ====================================================# 删除id=2的实体
        client.delete(
            collection_name=COLLECTION_NAME,
            ids=[2]
        )
        # 确保删除的数据已经写入Milvus
        client.flush(COLLECTION_NAME)
        resp3 = client.query(
            collection_name=COLLECTION_NAME,
            filter="id > 0",
            output_fields=["id", "source"],
        )
        print("删除后剩余：")
        for item in resp3:
            print("- id=", item["id"], "source=", item["source"])

    finally:
        if client.has_collection(COLLECTION_NAME):
            client.drop_collection(COLLECTION_NAME)
        print("测试集合已清理，剩余集合：", client.list_collections())


if __name__ == "__main__":
    main()
```

以上代码运行结果如下：

![sC0W0TWT\.jpg](图片和附件/sC0W0TWT.jpg)

以上使用Milvus代码注意如下几点：

1. MilvusClient\(uri=\.\.\., db\_name=\.\.\.\) 是 Milvus 2\.4\+ 推荐的轻量客户端入口，uri 使用 http:// 形式连接远程服务，测试环境也可以直接使用你的 192\.168\.179\.5:19530/default。

2. 建表必须明确 Schema：主键 id、原文 text、来源 source、向量 vector；vector 的 dim 必须与 Embedding 模型输出维度一致。

3. 有向量字段就必须创建索引，否则无法检索。

4. 插入后调用 flush\(\) 将数据落盘，检索前调用 load\_collection\(\) 加载到内存（即查询节点）。

5. search\(\) 的 data 必须传 list\[list\[float\]\]，例如 \[query\_vector\]；output\_fields 决定返回哪些标量字段。

6. upsert\(\) 需要提供主键和完整字段，向量也必须重新生成并一起提交，否则旧向量会保留。

## 2\.7\. Retriever检索

Retriever 是 RAG 的统一检索接口，输入自然语言问题，输出 list\[Document\]。Vector Store 负责存储和相似度计算，Retriever 负责把具体查询方式封装成后续 Chain 或 Agent 可以调用的组件。

### 2\.7\.1\. 检索类型

通过 vector\_store\.as\_retriever\(\) 可以把 Vector Store 转换成 Retriever。VectorStoreRetriever 的抽象支持 similarity、similarity\_score\_threshold 和 mmr 等 search\_type。

#### 2\.7\.1\.1\. similarity检索

similarity 是 VectorStoreRetriever 的默认检索方式，它的工作方式非常直接：将用户问题转换成向量后，与向量库中所有文档的向量进行相似度计算（通常是余弦相似度），然后按相似度从高到低排序，返回前 k 个文档。

```Plain Text
retriever = vector_store.as_retriever(search_kwargs={"k": 3})
documents = retriever.invoke("退款多久到账？")
```

similarity无论用户检索内容与向量库中的内容相似度多低，永远返回前K个文档。

#### 2\.7\.1\.2\. similarity\_score\_threshold检索

similarity\_score\_threshold在前 k 个结果的基础上，增加了一个相似度分数阈值作为过滤条件，只返回相似度分数不低于指定阈值的文档。使用方式如下：

```Plain Text
retriever = vector_store.as_retriever(
    search_type="similarity_score_threshold",
    search_kwargs={
        "k": 5,
        "score_threshold": 0.7,
    }
)
documents = retriever.invoke("退款多久到账？")
```

以上search\_kwargs参数注意点：

- score\_threshold 的取值通常在 0 到 1 之间，0\.7 是一个常见的实践阈值。分数越高，返回的文档与查询的语义相关性要求越严格。

- search\_kewrgs还支持其他参数：k表示最多返回的文档数量（默认4）；filter可以按文档metadata进行过滤。

- **similarity\_score\_threshold 依赖向量库的 similarity\_search\_with\_relevance\_scores\(\) 方法**。并非所有向量库都完整实现了该方法。在InMemoryVectorStore中，直接使用该检索类型会抛出 NotImplementedError。生产环境建议使用 Chroma、FAISS、PGVector 等成熟向量库。

与similarity检索不同，similarity\_score\_threshold检索方式在返回前k个文档的基础上，进一步过滤掉分数低于阈值的文档，如果符合条件的结果不足 k 个，则只返回实际满足阈值的结果。

#### 2\.7\.1\.3\. mmr检索

MMR全称Maximum Marginal Relevance（最大边际相关性）。它在 similarity 的基础上增加了一个目标：在保证相关性的同时，尽量让返回的文档之间彼此不同，避免结果冗余。

MMR 不是一个全新的检索算法，而是一个重排序（reranking）算法。它的工作流程分为两步：

7. 先多召回：先从向量库中召回fetch\_k个与问题最相似的文档（fetch\_k \> k）。

8. 再选多样：在这 fetch\_k个候选中，用 MMR 算法迭代挑选出最终的k个文档。每一步都选择“与问题既相关、又与已选文档差异最大”的那个。

用法如下：

```Plain Text
retriever = vector_store.as_retriever(
    search_type="mmr",
    search_kwargs={
        "k": 2,              # 最终返回 2 个文档"fetch_k": 5,        # 先召回 5 个候选
    }
)
documents = retriever.invoke("退款多久到账？")
```

以上参数解释如下：

mmr检索适用于知识库中大量文档内容高度相似或重复（如多个 chunk 都在解释同一条规则）场景，需要 LLM 从多个角度获取信息，而不是反复看到同一段话的不同版本，让有限的上下文窗口容纳更多不同类型的信息。

### 2\.7\.2\. metadata filter

metadata filter 用于在向量检索前，根据文档的 metadata 属性进行条件过滤，只让符合条件的文档参与相似度计算。

向量相似度解决的是“语义像不像”的问题，但无法区分文档的业务属性。例如：用户查询耳机退款规则，向量检索可能同时召回耳机和手表规则。metadata filter 的作用就是在检索前先划定范围——只允许“产品=耳机”的文档参与检索。

在 LangChain 中，metadata filter 主要通过 search\_kwargs 中的 filter 参数传递：

```Plain Text
retriever = vector_store.as_retriever(
    search_kwargs={
        "k": 3,
        "filter": lambda document:document.metadata.get("product") == "耳机",
    }
)
documents = retriever.invoke("退款多久到账？")
```

### 2\.7\.3\. InMemoryVectoreStore Retriever 检索与过滤案例

下面基于InMemoryVectoreStore分别执行similarity、MMR 和 metadata filter，观察返回来源。

```Plain Text
from env_utils import DASHSCOPE_API_KEYfrom langchain_community.embeddings import DashScopeEmbeddingsfrom langchain_core.documents import Documentfrom langchain_core.vectorstores import InMemoryVectorStoreembedding_model = DashScopeEmbeddings(
    model="text-embedding-v1",
    dashscope_api_key=DASHSCOPE_API_KEY,
)


if __name__ == "__main__":
    # ========================================================
    # 第一步：创建千问语义向量库
    # ========================================================documents = [
        Document("耳机退货需要保持包装完整。", metadata={"source": "耳机退货.md", "product": "耳机"}),
        Document("耳机退款通常三个工作日内到账。", metadata={"source": "耳机退款.md", "product": "耳机"}),
        Document("手表激活后不支持无理由退货。", metadata={"source": "手表退货.md", "product": "手表"}),
    ]

    vector_store = InMemoryVectorStore(embedding_model)
    # 写入文档到向量库
    vector_store.add_documents(documents)


    # ========================================================
    # 第二步：similarity只返回最相似的一条
    # ========================================================similarity_retriever = vector_store.as_retriever(search_kwargs={"k": 1})

    similarity_results = similarity_retriever.invoke("耳机退款多久到账？")

    # ========================================================
    # 第三步：MMR在耳机资料内返回两个互补结果
    # ========================================================mmr_retriever = vector_store.as_retriever(
        search_type="mmr",
        search_kwargs={
            "k": 2,
            "fetch_k": 3,
            "filter": lambda document: document.metadata.get("product") == "耳机",
        },
    )
    mmr_results = mmr_retriever.invoke("耳机退货和退款规则")

    # ========================================================
    # 第四步：metadata filter限制产品范围
    # ========================================================filtered_retriever = vector_store.as_retriever(
        search_kwargs={
            "k": 2,
            "filter": lambda document: document.metadata.get("product") == "耳机",
        }
    )

    filtered_results = filtered_retriever.invoke("退货规则")

    print("Embedding模型：text-embedding-v1")
    print("similarity：", [f"{document.metadata['source']} | {document.page_content}" for document in similarity_results])
    print("MMR：", [f"{document.metadata['source']} | {document.page_content}" for document in mmr_results])
    print("metadata filter：", [f"{document.metadata['source']} | {document.page_content}" for document in filtered_results])
```

以上代码运行结果如下：

![fvpMqmrr\.jpg](图片和附件/fvpMqmrr.jpg)

### 2\.7\.4\. MilvusVectoreStore Retriever 检索与过滤案例

下面基于Milvus分别执行similarity、similarity\_score\_threshold、MMR 和 metadata filter，观察返回来源。

```Plain Text
from langchain_core.documents import Documentfrom langchain_milvus import Milvusfrom pymilvus import MilvusClient, DataTypefrom env_utils import DASHSCOPE_API_KEYfrom langchain_community.embeddings import DashScopeEmbeddingsMILVUS_URI = "http://192.168.179.5:19530"MILVUS_DB = "default"COLLECTION_NAME = "rag_milvus_crud2"embedding_model = DashScopeEmbeddings(
    model="text-embedding-v1",
    dashscope_api_key=DASHSCOPE_API_KEY,
)

client = MilvusClient(
    uri=MILVUS_URI,
    db_name=MILVUS_DB
)

# ====================================================
# 第一步：清理旧集合
# ====================================================
# 如果集合已存在，先删除，保证每次运行环境干净、结果可复现
if client.has_collection(COLLECTION_NAME):
    client.drop_collection(COLLECTION_NAME)

# ====================================================
# 第二步：建表
# ====================================================
# 确认向量维度：不能写死，必须与当前嵌入模型的实际输出保持一致
dimension = len(embedding_model.embed_query("测试文本"))

schema = client.create_schema(
    auto_id=True,                # 主键由 Milvus 自动生成
    enable_dynamic_field=False   # 关闭动态字段，所有字段必须显式声明
)

schema.add_field(
    "id",
    DataType.INT64,
    is_primary=True,
)

schema.add_field(
    "page_content",
    DataType.VARCHAR,
    max_length=1000
)

schema.add_field(
    "source",
    DataType.VARCHAR,
    max_length=200
)

schema.add_field(
    "product",
    DataType.VARCHAR,
    max_length=200
)

schema.add_field(
    "vector",
    DataType.FLOAT_VECTOR,
    dim=dimension
)

# 构建索引
index_params = client.prepare_index_params()
# 给 vector 字段添加索引
# AUTOINDEX 由 Milvus 根据数据规模自动选择底层索引类型，无需手工调参
index_params.add_index(
    field_name="vector",
    index_type="AUTOINDEX",
    metric_type="COSINE",
)

# 创建集合
client.create_collection(
    collection_name=COLLECTION_NAME,
    schema=schema,
    index_params=index_params,
)

print("建表完成：", COLLECTION_NAME, "| 向量维度：", dimension)


# ====================================================
# 第三步：插入数据
# ====================================================documents = [
        Document("耳机退货需要保持包装完整。", metadata={"source": "耳机退货.md", "product": "耳机"}),
        Document("耳机退款通常三个工作日内到账。", metadata={"source": "耳机退款.md", "product": "耳机"}),
        Document("手表激活后不支持无理由退货。", metadata={"source": "手表退货.md", "product": "手表"}),
    ]


# 得到文档的向量表示
vectors = embedding_model.embed_documents([document.page_content for document in documents])

# 原始数据合并向量，并插入集合
data = [
    {
        "page_content":document.page_content,
        "source":document.metadata['source'],
        "product":document.metadata['product'],
        "vector": vector
    }
    for document, vector in zip(documents, vectors)
]

client.insert(
    collection_name=COLLECTION_NAME,
    data=data
)

# 确保插入的数据已经写入Milvus，否则 row_count 可能不准
client.flush(COLLECTION_NAME)
# 将Collection加载到内存以供搜索，未加载的集合无法检索
client.load_collection(COLLECTION_NAME)
print("插入实体数：", client.get_collection_stats(COLLECTION_NAME).get("row_count"))


# ====================================================
# 第四步：挂载集合，构建 LangChain 向量库对象
# ====================================================vector_store = Milvus(
    embedding_function=embedding_model, # 用于将查询文本转换为向量
    collection_name=COLLECTION_NAME, # 指定要挂载的集合名
    connection_args={"uri": MILVUS_URI, "db_name": MILVUS_DB}, # Milvus 连接信息
    auto_id=True, # 主键自动生成
    primary_field="id", # 主键字段名
    text_field="page_content", # 文本字段名
    vector_field="vector", # 向量字段名
    enable_dynamic_field=False, # 关闭动态字段
    # index_params：告诉 LangChain 本集合用的是哪种度量，用于把原始余弦距离换算成相关性分数
    index_params={"index_type": "AUTOINDEX", "metric_type": "COSINE"},
    # search_params：发给 Milvus 服务端的检索参数，决定用哪种度量做近邻搜索
    search_params={"metric_type": "COSINE"},
)

# 1. ============= similarity 只返回最相似一条数据 =============
# 纯向量近邻搜索，按度量结果取前 k 条，不做任何过滤，返回条数恒等于 min(k, 实体数)
similarity_retriever = vector_store.as_retriever(search_kwargs={"k":1})

similarity_result = similarity_retriever.invoke("耳机退款多久到账？")

print("type(similarity_result):",type(similarity_result))
print("similarity_result:",similarity_result)


# 2. ============= similarity_score_threshold 检索 =============
# 先做相似度检索，再把原始距离换算成 [0,1] 的相关性分数，丢弃低于阈值的文档
# 因此返回条数可能少于 k，具体换算公式由上面的 index_params 决定
similarity_score_threshold = vector_store.as_retriever(
    search_type="similarity_score_threshold",
    search_kwargs={
        "k": 5,
        "score_threshold": 0.7, # 相关性分数
    }
)

similarity_score_threshold_result = similarity_score_threshold.invoke("耳机退款多久到账？")

print("type(similarity_score_threshold_result):",type(similarity_score_threshold_result))
print("similarity_score_threshold_result:",similarity_score_threshold_result)


# 3. ========== mmr检索 =============
# MMR（最大边际相关性）在"与查询相关"和"结果之间彼此不重复"之间做权衡
# expr 是 Milvus 的标量过滤表达式，在服务端先筛后搜
mmr_retriever = vector_store.as_retriever(
    search_type="mmr",
    search_kwargs={
        "k":2,          # 最终返回条数
        "fetch_k":3,    # 先取多少条候选，再从中精选
        "expr":'product == "手表"'  # 只保留手表类文档
    }
)

mmr_result = mmr_retriever.invoke("耳机退货和退款规则")
print("type(mmr_result):",type(mmr_result))
print("mmr_result:",mmr_result)
```

以上代码需要注意：

1. vector\_store = Milvus\(\.\.\.\)是创建Milvus VectoreStore

2. expr 是 Milvus 的标量过滤表达式，在服务端先筛后搜，这里不用filter

## 2\.8\. RAG知识库构建及检索案例

下面把 TextLoader、Document、Text Splitter、Embedding、Vector Store 和 Retriever 串成完整知识库构建流程。

该案例从本地售后文本读取资料，切成chunk，写入向量库后使用带产品过滤的 MMR Retriever 查询。

```Plain Text
from env_utils import DASHSCOPE_API_KEYfrom langchain_community.document_loaders import TextLoaderfrom langchain_community.embeddings import DashScopeEmbeddingsfrom langchain_core.vectorstores import InMemoryVectorStorefrom langchain_text_splitters import RecursiveCharacterTextSplitterembedding_model = DashScopeEmbeddings(
    model="text-embedding-v1",
    dashscope_api_key=DASHSCOPE_API_KEY,
)


if __name__ == "__main__":
    # ========================================================
    # 第一步：使用TextLoader读取本地售后规则
    # ========================================================data_file = "data/售后规则.txt"

    # 读取文件，获取一个Document对象
    documents = TextLoader(
        str(data_file),
        encoding="utf-8").load()

    # 给原始文档增加业务metadata，后面切分出的每个chunk都会继承这些字段。
    documents[0].metadata.update(
        {"product": "降噪耳机", "section": "退货与退款", "version": "2026-09"}
    )

    # ========================================================
    # 第二步：按中文段落和句子切分文档
    # ========================================================splitter = RecursiveCharacterTextSplitter(
        chunk_size=55,
        chunk_overlap=8,
        separators=["\n\n", "\n", "。", "；", "，", ""],
        keep_separator="end",
    )

    chunks = splitter.split_documents(documents)

    # ========================================================
    # 第三步：使用真实Embedding写入内存向量库
    # ========================================================vector_store = InMemoryVectorStore(embedding_model)
    document_ids = vector_store.add_documents(chunks)


    # ========================================================
    # 第四步：创建MMR Retriever并执行语义检索
    # ========================================================retriever = vector_store.as_retriever(
        search_type="mmr",
        search_kwargs={
            "k": 2,
            "fetch_k": 4,
            "filter": lambda document: document.metadata.get("product") == "降噪耳机",
        },
    )
    results = retriever.invoke("退货后退款多久到账？")

    # ========================================================
    # 第五步：输出真实检索结果
    # ========================================================print("Embedding模型：text-embedding-v1")
    print("切分片段数：", len(chunks))
    print("写入向量库数量：", len(document_ids))
    print("Retriever返回：")
    for document in results:
        print(f"- {document.page_content}")
        print(
            f"  product={document.metadata['product']} | "f"version={document.metadata['version']}"
        )
```

以上代码运行结果如下：

![N8a713jj\.jpg](图片和附件/N8a713jj.jpg)

以上代码中注意如下几点：

1. Text Splitter将Document切分成多个Chunk，然后存入内存的Vector Store，Retriever 使用 MMR 返回与用户检索最相近的两份互补资料。

2. TextLoader 在加载文件时会自动将文件路径写入 metadata，而 RecursiveCharacterTextSplitter 在切分时会自动继承原始 Document 的所有 metadata。

# LangChain RAG应用

## 3\.1\. 查询改写

查询改写（Query Rewriting）是指在检索发生之前，将用户的原始问题转换为更适合向量检索的查询语句的过程\.

用户提出的问题往往是口语化、不完整或带有模糊指代的。例如，用户可能问“那个耳机退款要多久”，而知识库中的文档写的是“降噪耳机退货后，退款通常在三个工作日内到账”。两者的用词和表达方式差异很大，直接使用原始问题去检索，很可能无法命中正确的文档。

查询改写的核心作用，就是消除用户表达与文档写法之间的“词汇鸿沟”（Vocabulary Mismatch），将口语化的、有歧义的原始问题，转化为简洁、精确、包含关键业务术语的检索查询，这个过程通常由一个轻量级的 LLM 来完成。

注意：查询改写只服务于检索环节。程序应同时保存原始问题（用于最终回答和审计）和改写后的查询（用于 Retriever 检索），二者不能混为一谈。

### 3\.1\.1\. 查询改写实现

在 LangChain 生态中，实现查询改写主要有两种方式：确定性规则改写和基于 LLM 的动态改写。

#### 3\.1\.1\.1\. 确定性规则改写

对于同义词替换、术语标准化等确定性需求，可以使用字符串替换或正则表达式实现。这种方式速度快、成本低，且结果可控。

```Plain Text
def rewrite_query_by_rule(question: str) -> str:"""通过确定性规则改写查询。"""# 替换口语化表达为业务术语
    rewritten = question.replace("钱回银行卡", "退款到账")
    rewritten = rewritten.replace("退掉", "退货")
    rewritten = rewritten.replace("啥时候", "多久")
    # 补充核心关键词return f"{rewritten} 退货 退款 到账"# 示例
original = "钱啥时候能回到我的银行卡？"
rewritten = rewrite_query_by_rule(original)
print(rewritten)
# 输出: 钱多久能回到我的银行卡？ 退货 退款 到账
```

这种方式适合适合简单、固定的场景，处理业务中确定性高、规则明确的同义词和口语表达，能保证关键术语不被遗漏。

#### 3\.1\.1\.2\. 基于 LLM 的改写

对于更复杂的语义理解可以使用 LLM 进行改写是更灵活的选择。这种方式直接使用一个 LLM 对原始查询进行改写，然后用改写后的查询去检索即可。

```Plain Text
question = "这款耳机退掉后，钱回银行卡要多久？"
rewrite_response = deepseek_llm_flash.invoke(
    "把下面问题改写成适合检索降噪耳机售后知识库的短查询。""补充退货、退款、到账等标准词。严格只输出一条查询，必须在一行内，不超过20个中文字符，不要给多个方案。\n"
    f"原始问题：{question}"
)
rewritten_query = rewrite_response.content.strip().replace("\n", " ")
```

### 3\.1\.2\. 查询改写案例

下面的案例演示了如何在一个RAG流程中集成查询改写并配合metadata 过滤、MMR，演示一个检索链路。

```Plain Text
from env_utils import DASHSCOPE_API_KEYfrom langchain_community.embeddings import DashScopeEmbeddingsfrom langchain_core.documents import Documentfrom langchain_core.messages import HumanMessage, SystemMessagefrom langchain_core.vectorstores import InMemoryVectorStorefrom langchain_text_splitters import RecursiveCharacterTextSplitterfrom init_llm import deepseek_llm_flashembedding_model = DashScopeEmbeddings(
    model="text-embedding-v1",
    dashscope_api_key=DASHSCOPE_API_KEY,
)


if __name__ == "__main__":
    # ========================================================
    # 第一步：准备多产品知识库并切分
    # ========================================================documents = [
        Document(
            "降噪耳机退货：收货后七日内可以申请无理由退货，包装和配件需要保持完整。",
            metadata={"source": "耳机售后.md", "product": "降噪耳机"},
        ),
        Document(
            "降噪耳机退款：仓库验收后发起原路退款，通常三个工作日内到账。",
            metadata={"source": "耳机退款.md", "product": "降噪耳机"},
        ),
        Document(
            "智能手表规则：手表激活后不支持无理由退货。",
            metadata={"source": "手表售后.md", "product": "智能手表"},
        ),
    ]

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=100,
        chunk_overlap=15,
        separators=["\n\n", "\n", "。", "；", "，", ""],
    )

    chunks = splitter.split_documents(documents)

    # 存入向量库
    vector_store = InMemoryVectorStore(embedding_model)
    vector_store.add_documents(chunks)

    # ========================================================
    # 第二步：使用LLM模型完成改写查询
    # ========================================================question = "这款耳机退掉后，钱回银行卡要多久？"rewrite_response = deepseek_llm_flash.invoke(
        "把下面问题改写成适合检索降噪耳机售后知识库的短查询。""补充退货、退款、到账等标准词。严格只输出一条查询，必须在一行内，不超过20个中文字符，不要给多个方案。\n"f"原始问题：{question}"
    )
    rewritten_query = rewrite_response.content.strip().replace("\n", " ")

    # ========================================================
    # 第三步：使用千问Embedding、MMR和产品过滤检索
    # ========================================================retriever = vector_store.as_retriever(
        search_type="mmr",
        search_kwargs={
            "k": 2,
            "fetch_k": 3,
            "filter": lambda document: document.metadata.get("product") == "降噪耳机",
        },
    )

    retrieved_documents = retriever.invoke(rewritten_query)

    # 组织召回内容
    context = "\n\n".join(
        f"来源：{document.metadata['source']}\n{document.page_content}"for document in retrieved_documents
    )

    # ========================================================
    # 第四步：直接构造消息并调用LLM
    # ========================================================messages = [
        SystemMessage(content="你是售后助手，只能根据参考资料回答，并在回答末尾列出来源。"),
        HumanMessage(content=f"参考资料：\n{context}\n\n用户问题：{question}"),
    ]
    response = deepseek_llm_flash.invoke(messages)
    answer = response.contentprint("原始问题：", question)
    print("改写查询：", rewritten_query)
    print("召回来源：", [document.metadata["source"] for document in retrieved_documents])
    print("\n最终回答：", answer)
```

以上代码运行结果如下：

![PbD6DWxZ\.jpg](图片和附件/PbD6DWxZ.jpg)

注意：查询改写不是万能的。如果现有的检索系统在真实问题上已经表现良好，或者问题本身非常结构化、术语明确，那么引入查询改写可能带来的延迟和成本开销就值得权衡。

### 3\.1\.3\. 查询改写价值

在 RAG 系统中，查询改写的价值体现在以下几个方面：

1\) **弥补用户表达的“缺陷”**

- 口语化与模糊：用户问“钱啥时候回来”，文档写“原路退款到账时间”。改写能补充“退款”“到账”等标准业务术语。

- 代词与指代不清：在多轮对话中，用户可能说“那它支持退货吗？”，改写需要将“它”替换为具体的商品名称，形成独立的、可检索的查询。

- 不完整问题：用户输入“快递”，改写可以扩展为“订单物流轨迹查询”。

2. **优化向量检索的效果**

Embedding 模型擅长处理语义相似，但对关键词的精确匹配并不总是可靠。查询改写通过补充同义词和关键业务实体，为 Embedding 模型提供了更丰富的语义锚点，使其能更准确地找到相关文档。如“快递”名词根据业务改写为“订单物流轨迹查询”。

3. **提升检索的准确率和召回率**

通过将原始问题重写为更接近知识库文档风格和用词的查询，可以显著提高向量检索的命中率。一个经过优化的查询，能更好地匹配到相关的文档块，减少无关或噪声信息的干扰。

## 3\.2\. Hybrid Search混合检索

### 3\.2\.1\. Hybrid Search 介绍

混合检索（Hybrid Search）是一种将**关键词检索**与**向量检索**组合起来的检索策略。在 RAG 系统中，关键词检索负责查找用户问题和知识库文档中相同或高度相关的词语，向量检索负责判断用户问题和文档表达的含义是否相近。两种检索方式分别执行后，再通过结果融合算法生成一份统一的文档排序。

例如，用户提出“AB\-120 退货后多久到账？”，这个问题同时包含两个不同类型的检索目标：

- AB\-120 是产品型号，系统需要准确区分 AB\-120、AB\-121 和其他型号；

- “退货后多久到账”则是一个自然语言问题，知识库中可能使用“退款时效”“款项退回时间”或“原路退款到账时间”等不同表达。

如果只使用关键词检索，系统可能无法识别这些同义表达；如果只使用向量检索，系统又可能把字符相近的产品型号混淆。Hybrid Search 的作用就是让两种检索能力同时参与：

- 关键词检索：负责产品型号、错误码和专有名词

- 向量检索：负责同义表达和自然语言语义

- 结果融合：将两路结果整理成最终排序

因此，Hybrid Search 混合检索的核心是并行执行两路检索，然后融合结果，其并不是为了替代向量检索，而是用关键词检索补充向量检索在精确实体上的不足，同时从知识库中找到包含精确实体和自然语言相关更完整、更准确的候选文档”。

![wI0gIpo8\.jpg](图片和附件/wI0gIpo8.jpg)

### 3\.2\.2\. Hybrid Search 工作原理

Hybrid Search 的完整执行过程可以分成四个阶段：关键词检索、向量检索、候选结果融合和最终截取。

#### 3\.2\.2\.1\. BM25关键字检索

BM25是信息检索领域最经典的关键词匹配打分算法，核心思想是对查询进行分词，然后计算每个词与文档的相关性，最后将所有这些相关性得分加权求和。其原理如下：给定一个查询（Query）和一系列文档，BM25 会为每个文档计算一个相关性分数，分数越高，表示该文档与查询在关键词层面越匹配。

BM25 主要考虑三个因素：

1\) **词语在当前文档中是否出现以及出现了多少次**

如果查询中包含“退款”，出现“退款”的文档通常会获得分数。一个词在文档中重复出现时，分数会提高，但不会无限增长，因为 BM25 会对词频进行饱和处理。

2\) **词语在整个知识库中的区分能力**

如果“商品”出现在绝大多数文档中，它对区分文档帮助不大；如果 AB\-120 只出现在少数文档中，这个词的区分能力更强，因此会获得更高权重。

3\) **文档长度**

同一个关键词出现在一条很短的产品规则中，通常比出现在一本包含大量无关内容的长手册中更集中。BM25 会根据文档长度做归一化，避免长文档仅仅因为包含的词更多就总是获得高分。

例如用户搜索“AB\-120 退货政策”,BM25会逐个匹配文档中是否包含“AB\-120”、“退货”、“政策”这些精确的词，并给每个文档计算得分，\*\*它给分的原则是：包含这些词越多、越罕见（如“AB\-120”这种编号）的文档，得分越高。\*\*它完全不理解“AB\-120”和“型号”在语义上可能相关，它只认字面匹配。

在 Milvus 2\.5 及以上版本中，BM25已得到原生支持，Milvus 将 BM25 算法实现为一种内置的函数（Function）。当你向一个定义了 BM25 函数的字段（如 text）插入数据时，Milvus 会自动将其转换为一个稀疏向量（Sparse Vector） 并存储。这让你可以像处理稠密向量一样，用统一的向量检索范式来处理关键词匹配。

Milvus 可以在 Collection Schema 中定义 BM25 Function：

```Plain Text
# BM25的输入文本字段
schema.add_field(
    field_name="text",
    datatype=DataType.VARCHAR,
    max_length=1000,

    # 开启文本分析功能
    enable_analyzer=True,

    # 中文使用jieba分词
    analyzer_params={"tokenizer": "jieba"},
)

schema.add_field(
        field_name="sparse_vector",
        datatype=DataType.SPARSE_FLOAT_VECTOR,
    )

... ...
schema.add_function(
    Function(
        name="bm25_function", # 自定义函数名
        function_type=FunctionType.BM25, # 指定为 BM25 转换函数
        input_field_names=["text"], # 输入字段为 text
        output_field_names=["sparse_vector"], # 输出字段为 sparse_vector
    )
)
```

以上表示对于text字段的原始文本，通过Milvus中在该字段上使用指定分词器分词，进而通过BM25 Function 对text字段构建一个稀疏向量 sparse\_vector。

向Milvus中text字段中插入数据时，正常写入文本数据即可，无需手动生成sparse\_vector，即Milvus 会根据 text 字段自动生成 BM25 稀疏向量。

查询 Milvus 时，直接将原始问题作为查询文本传入，Milvus 会自动使用与 text 字段相同的分析器进行分词，然后基于 BM25 算法计算查询与每个文档的相关性分数并排序返回。

如下案例展示如何在一个 Milvus Collection 中定义 BM25 函数，插入数据，使用BM25关键词检索。

实现该案例需要提前安装Milvus\(这里more已经安装\)以及python相关依赖：

```Plain Text
pip install pymilvus
```

案例总体思路：

1\) **Miluvs中创建Collection**

- 创建Schema：Schema中定义业务字段、稀疏向量存储字段、BM25函数（转换文本到稀疏向量）。

- 创建存储稀疏向量的索引：目的是加快向量搜索，例如：没有索引时，当查询“AB\-120”时，Milvus 需要逐条读取所有文档的稀疏向量，逐一计算分数；有索引时，Milvus 只需找到“AB\-120”对应的文档 ID 列表，**仅对这些文档计算分数**，其他文档被直接跳过。对于大规模知识库，这种跳过机制能带来数量级的性能提升。

2\) **向Milvus向量库中插入数据并执行检索**

调用 client\.search\(\)，data 参数直接传入原始查询文本。Milvus 自动完成分词、向量化和 BM25 相似度计算，返回按相关性排序的结果。

```Plain Text
from pymilvus import DataType, Function, FunctionType, MilvusClient

MILVUS_URI = "http://192.168.179.5:19530"
MILVUS_DB_NAME = "default"
COLLECTION_NAME = "tmp_course_bm25"def create_collection(client: MilvusClient,) -> None:"""创建包含文本字段和BM25稀疏向量的Collection。"""# 如果Collection已存在，先删除if client.has_collection(COLLECTION_NAME):
        client.drop_collection(COLLECTION_NAME)

    # 创建自定义Schema
    schema = client.create_schema(
        # 主键（id 字段）由 Milvus 自动生成（递增整数）
        auto_id=True,
        # 不允许动态添加字段，插入数据时只能使用 schema 中定义的字段，不能额外添加未定义的字段。
        enable_dynamic_field=False,
    )

    # 主键字段由Milvus自动生成
    schema.add_field(
        field_name="id",
        datatype=DataType.INT64,
        is_primary=True,
        auto_id=True,
    )

    # BM25的输入文本字段
    schema.add_field(
        field_name="text",
        datatype=DataType.VARCHAR,
        max_length=1000,

        # 开启文本分析功能
        enable_analyzer=True,

        # 中文使用jieba分词
        analyzer_params={"tokenizer": "jieba"},
    )

    # 文档来源
    schema.add_field(
        field_name="source",
        datatype=DataType.VARCHAR,
        max_length=200,
    )

    # 保存BM25产生的稀疏向量（高维但大多数位置为零）# 该字段无需指定维度，因为稀疏向量由输入文本动态计算。
    schema.add_field(
        field_name="sparse_vector",
        datatype=DataType.SPARSE_FLOAT_VECTOR,
    )

    # 定义BM25函数：text字段自动转换成sparse_vector# 函数作用：当向集合插入数据时，只需提供 text，Milvus 会自动根据 BM25 算法（基于集合内所有文档的词频统计）# 计算稀疏向量并存入 sparse_vector 字段。查询时也可以用原始文本作为查询向量，由引擎内部转换为稀疏向量进行检索。
    schema.add_function(
        Function(
            name="bm25_function", # 自定义函数名
            function_type=FunctionType.BM25, # 指定为 BM25 转换函数
            input_field_names=["text"], # 输入字段为 text
            output_field_names=["sparse_vector"], # 输出字段为 sparse_vector
        )
    )

    # 为BM25稀疏向量创建倒排索引
    index_params = client.prepare_index_params()
    index_params.add_index(
        field_name="sparse_vector", # 索引字段为 sparse_vector
        index_type="SPARSE_INVERTED_INDEX", # 稀疏向量专用倒排索引，适合 BM25 相似度计算
        metric_type="BM25", # 指定为 BM25 相似度计算相关性分数
    )

    # 创建Collection
    client.create_collection(
        collection_name=COLLECTION_NAME, # 指定Collection名称
        schema=schema, # 指定Collection的Schema
        index_params=index_params, # 指定Collection的索引参数
    )


def main() -> None:# 连接Milvus的default数据库
    client = MilvusClient(
        uri=MILVUS_URI,
        db_name=MILVUS_DB_NAME,
    )

    try:
        # 创建Collection
        create_collection(client)

        # 只插入原始文本，不需要提供sparse_vector
        client.insert(
            collection_name=COLLECTION_NAME,
            data=[
                {"text": "AB-120 是降噪耳机型号。", "source": "产品型号.md",},
                {"text": "降噪耳机退货后，退款通常三个工作日内到账。", "source": "退款规则.md",},
                {"text": "AB-121 是运动耳机型号。", "source": "产品型号.md",},
                {"text": "订单发货后可以在订单详情查看物流轨迹。", "source": "物流规则.md",},
            ],
        )

        # 强制刷新内存中的数据到磁盘，确保数据已持久化，后续操作能立即看到最新数据
        client.flush(COLLECTION_NAME)

        # 将集合加载到内存中，只有加载后才能进行查询操作
        client.load_collection(COLLECTION_NAME)

        question = "AB-120 退货后多久到账？"# 查询BM25稀疏向量字段，查询数据可以直接传入原始文本
        results = client.search(
            collection_name=COLLECTION_NAME, # 指定Collection名称
            data=[question], # 查询数据，直接传入原始文本
            anns_field="sparse_vector", # 指定在 sparse_vector 字段上进行搜索
            search_params={ #检索参数"metric_type": "BM25", # 指定为 BM25 相似度计算相关性分数，与索引一致"params": {},
            },
            limit=3, # 返回最相似的 3 条结果
            output_fields=["text", "source",], # 返回结果中附带这些字段的值
        )

        print("查询问题：", question)
        print("BM25检索结果：")

        for rank, hit in enumerate(results[0], start=1):
            print("hit:",hit)
            print(f"{rank}. score= {hit['distance']:.6f}")
            print("   内容：", hit["entity"]["text"])
            print("   来源：", hit["entity"]["source"])

    finally:
        pass# 运行结束后删除临时Collection# if client.has_collection(COLLECTION_NAME):#     client.drop_collection(COLLECTION_NAME)if __name__ == "__main__":
    main()
```

以上代码运行后结果如下：

![kpPi4SsY\.jpg](图片和附件/kpPi4SsY.jpg)

以上代码注意点如下：

1. schema\.add\_function\(Function\(\.\.\.\)\)定义BM25函数,当向集合插入数据时，只需提供 text，Milvus 会自动根据 BM25 算法,查询时也可以用原始文本作为查询向量，由引擎内部转换为稀疏向量进行检索。其中FunctionType\.BM25 是 Milvus 内置 BM25 函数。

2. text 字段必须启用 Analyzer，否则 Milvus 无法完成文本分词。

3. sparse\_vector的字段类型必须指定为DataType\.SPARSE\_FLOAT\_VECTOR。

4. 插入数据时不需要提交 sparse\_vector，该字段由 BM25 Function 自动生成。查询 sparse\_vector 时直接传入原始问题字符串。

5. PyMilvus 返回结果中的字段名叫 distance，但在 BM25 检索中应将其理解为相关性分数，分数越大表示当前排序越靠前。

#### 3\.2\.2\.2\. 向量语义检索

向量检索使用 Embedding 模型把文本转换成稠密向量。稠密向量是一个固定长度的数字列表，其中大部分位置都有数值。

例如我们使用“text\-embedding\-v1”向量模型将Document转换成向量，实际生成的向量维度是1536，对应的向量形式如下（稠密向量）：

```Plain Text
[0.012, -0.038, 0.157, ...]
```

当用户提问“AB\-120 退货后多久到账？”时，用户问题也会转换成相同维度的向量，然后通过余弦相似度比较两者的方向是否接近。两个向量越相似，通常表示问题与文档的语义越接近。

#### 3\.2\.2\.3\. RRF倒数排名融合

关键词检索（BM25）与向量检索分别返回了分数，那么混合检索如何融合两种检索结构为一种检索结果呢？这两种返回的分数不能直接比较，例如：BM25分数是4\.18,向量COSINE分数为0\.49,不能因为4\.18 \> 0\.49就认为BM25 的结果一定更相关。这里通用一种做法是通过RRF倒数排名对两种结果进行融合。

RRF（Reciprocal Rank Fusion，倒数排名融合）不直接比较原始分数，而是只看文档在每路结果中的排名，这样可以避免不同检索系统分数尺度不一致的问题。其原理如下：

RRF 对每个排名位置计算一个倒数排名分数：

```Plain Text
1 / (k + rank)
```

同一个文档在多路结果中的分数相加：

```Plain Text
最终RRF分数 = BM25排名贡献 + 向量排名贡献
```

最终某个文档的RRF融合的分数如下，RRF分数越大表示融合后的排名越靠前。

```Plain Text
RRF分数 = Σ 1 / (k + rank)
```

其中：

- rank 表示文档在当前检索结果中的排名，从 1 开始；

- k 是平滑参数；

- 文档没有出现在某一路结果中时，那一路不给它贡献分数。

Milvus 也提供了 RRFRanker，默认使用 k=60。较大的 k 会减小不同排名位置之间的分数差距；较小的 k 会让排名靠前的文档获得更明显的优势。k=60 可以作为常见初始值，但不能认为它在所有数据集上都是最优参数。

RRFRanker计算示例：假设两路检索返回如下内容：

以上示例中，文档 C 在两路都排第 2，C的RRF分数=1/\(60\+2\) \+ 1/\(60\+2\)≈0\.032258；文档 A 只在 BM25 路出现，A的RRF分数= 1/\(60\+1\)≈ 0\.016393，因此，虽然文档 C 没有在任何一路排第一，但它同时被两路认可，最终融合分数高于只被一路检索到的文档 A。由此可得RRF的核心就是：**不追求某一路的最高原始分数，而是奖励被多路检索共同认可的文档，即：RRF 会优先将那些在多个检索系统中都表现优异的文档（排名都很靠前）排在前面**。

在Milvus中我们不需要手动计算RRF分数，而是通过“client\.hybrid\_search\(\.\.\.\)”传入多路向量即可，核心代码结构如下：

```Plain Text
# 向量语义检索：获取多个稠密向量
dense_request = AnnSearchRequest(
    data=[query_dense_vector],  #传入用户问题的稠密向量
    anns_field="dense_vector", # 搜索稠密向量字段param={
       "metric_type": "COSINE",
       "params": {},
    },  # 使用余弦相似度
    limit=3,  # 向量检索返回3个候选
)

# BM25关键字检索：获取多个稀疏向量
sparse_request = AnnSearchRequest(
    data=[question], #用户原始查询文本
    anns_field="sparse_vector", #搜索BM25稀疏向量字段param={
        "metric_type": "BM25",
        "params": {},
    },  # 使用BM25相关性评分
    limit=3,  # BM25检索最多返回3个候选
)

# RRF倒数排名融合
results = client.hybrid_search(
    #传入Dense与Sparse两路向量
    reqs=[dense_request,sparse_request,],
    ranker=RRFRanker(k=60), #使用RRF根据两路排名融合
    limit=2,
    output_fields=["text","source",],  # 返回正文和来源
)
```

如下案例中演示使用Milvus Hybrid Search 核心流程，案例总体思路如下：

1\) **Miluvs中创建Collection**

- 创建Schema：Schema中定义业务字段、稀疏向量存储字段、稠密向量存储字段、BM25函数（转换文本到稀疏向量）

- 创建存储向量的索引：创建稀疏向量和稠密向量索引，目的加快两者查询。

2\) **向Milvus向量库中插入数据**

用户准备要存入Milvus中的原始文档，通过EmbeddingModel进行向量化，然后将原始文档内容和向量化数据存入到Milvus中。

3\) **根据用户问题获取检索向量**

根据用户问题通过“AnnSearchRequest（\.\.\.）”获取BM25稀疏向量和语义Embedding稠密向量。

4\) **Hybrid Search进行融合**

调用 client\.hybrid\_search（\.\.\.）对稀疏向量和稠密向量进行融合，根据RRF分支返回最终匹配的N个排序的结果。

![fGWEsHyo\.jpg](图片和附件/fGWEsHyo.jpg)

```Plain Text
from langchain_community.embeddings import DashScopeEmbeddingsfrom pymilvus import AnnSearchRequestfrom pymilvus import DataTypefrom pymilvus import Functionfrom pymilvus import FunctionTypefrom pymilvus import MilvusClientfrom pymilvus import RRFRankerfrom env_utils import DASHSCOPE_API_KEY

# 创建千问Embedding模型
embedding_model = DashScopeEmbeddings(
    model="text-embedding-v1",  # 指定Embedding模型名称
    dashscope_api_key=DASHSCOPE_API_KEY,  # 设置DashScope API Key
)

MILVUS_URI = "http://192.168.179.5:19530"  # Milvus服务地址
MILVUS_DB_NAME = "default"  # Milvus数据库名称
COLLECTION_NAME = "tmp_simple_hybrid_search"def main() -> None:  # 定义程序入口函数
    client = MilvusClient(  # 创建Milvus客户端
        uri=MILVUS_URI,  # 指定Milvus服务地址
        db_name=MILVUS_DB_NAME,  # 指定要访问的数据库
    )

    # 使用try/finally保证测试后删除临时Collectiontry:
        # 如果同名Collection已经存在，先删除旧Collectionif client.has_collection(COLLECTION_NAME):
            client.drop_collection(COLLECTION_NAME)

        # 准备要写入Milvus的原始文档
        documents = [
            {"text": "AB-120 是降噪耳机型号。","source": "产品型号.md",},
            {"text": "降噪耳机退货后，退款通常三个工作日内到账。","source": "退款规则.md",},
            {"text": "订单发货后可以在订单详情查看物流轨迹。","source": "物流规则.md",},
        ]

        # 为全部文档生成稠密向量，只把正文交给Embedding模型
        dense_vectors = embedding_model.embed_documents([document["text"] for document in documents])

        # 读取真实向量维度
        embedding_dimension = len(dense_vectors[0])

        # ====================================================
        # 第一步：定义Collection字段
        # ====================================================
        # 创建Collection Schemaschema = client.create_schema(
            auto_id=True,  # 让Milvus自动生成主键
            enable_dynamic_field=False,  # 禁止写入Schema之外的字段
        )

        schema.add_field(  # 添加主键字段
            field_name="id",  # 主键字段名称
            datatype=DataType.INT64,  # 主键使用INT64类型
            is_primary=True,  # 声明为主键
            auto_id=True,  # 主键值由Milvus自动生成
        )

        schema.add_field(  # 添加文档正文字段
            field_name="text",  # 正文字段名称
            datatype=DataType.VARCHAR,  # 正文使用字符串类型
            max_length=1000,  # 设置最大字符长度
            enable_analyzer=True,  # 开启文本分析，BM25需要使用
            analyzer_params={"tokenizer": "jieba"},# 使用jieba切分中文词语
        )

        schema.add_field(  # 添加文档来源字段
            field_name="source",  # 来源字段名称
            datatype=DataType.VARCHAR,  # 来源使用字符串类型
            max_length=200,  # 设置最大字符长度
        )

        schema.add_field(  # 添加稠密向量字段
            field_name="dense_vector",  # 保存Embedding向量
            datatype=DataType.FLOAT_VECTOR,  # 使用稠密浮点向量类型
            dim=embedding_dimension,  # 使用真实Embedding维度
        )

        schema.add_field(  # 添加BM25稀疏向量字段
            field_name="sparse_vector",  # 保存BM25产生的稀疏向量
            datatype=DataType.SPARSE_FLOAT_VECTOR,  # 使用稀疏向量类型
        )

        # ====================================================
        # 第二步：定义Milvus原生BM25函数
        # ====================================================schema.add_function(  # 给Schema添加Milvus内置函数
            Function(  # 创建函数定义
                name="bm25_function",  # 设置函数名称
                function_type=FunctionType.BM25,  # 指定函数类型为BM25input_field_names=["text"],  # 从text字段读取原始文本
                output_field_names=["sparse_vector"],  # 自动把结果写入稀疏向量字段
            )
        )

        # ====================================================
        # 第三步：创建Dense与Sparse两种索引
        # ====================================================
        # 创建索引配置对象
        index_params = client.prepare_index_params()

        index_params.add_index(  # 为稠密向量创建索引
            field_name="dense_vector",  # 指定稠密向量字段
            index_type="AUTOINDEX",  # 由Milvus自动选择索引配置
            metric_type="COSINE",  # 使用余弦相似度比较语义
        )

        index_params.add_index(  # 为BM25稀疏向量创建索引
            field_name="sparse_vector",  # 指定稀疏向量字段
            index_type="SPARSE_INVERTED_INDEX",  # 使用稀疏倒排索引
            metric_type="BM25",  # 使用BM25相关性评分
        )

        # ====================================================
        # 第四步：创建Collection
        # ====================================================
        # 创建Milvus Collectionclient.create_collection(
            collection_name=COLLECTION_NAME,  # 设置Collection名称
            schema=schema,  # 传入字段和BM25函数定义
            index_params=index_params,  # 传入两种索引配置
        )

        # ====================================================
        # 第五步：插入正文和稠密向量
        # ====================================================insert_data = []  # 准备最终写入Milvus的数据

        # 让每篇文档与自己的向量一一对应
        for document, dense_vector in zip(documents,dense_vectors,):
            # 把当前实体加入写入列表
            insert_data.append({
                    "text": document["text"],  # 写入原始正文
                    "source": document["source"],  # 写入文档来源
                    "dense_vector": dense_vector,  # 写入真实稠密向量
                })

        # 向Collection写入全部实体
        client.insert(
            collection_name=COLLECTION_NAME,  # 指定目标Collectiondata=insert_data,  # 传入正文、来源和稠密向量
        )

        # sparse_vector不需要写入
        # Milvus会根据text字段和BM25函数自动生成sparse_vector

        # 确保插入的数据已经写入Milvusclient.flush(COLLECTION_NAME)

        # 将Collection加载到内存以供搜索
        client.load_collection(COLLECTION_NAME)

        # ====================================================
        # 第六步：准备用户问题
        # ====================================================
        # 用户问题同时包含精确型号和退款语义
        question = "AB-120 退货后多久到账？"

        # 把用户问题转换成稠密向量
        query_dense_vector = embedding_model.embed_query(question)

        # ====================================================
        # 第七步：创建向量语义检索请求
        # ====================================================
        # 创建Dense检索请求
        dense_request = AnnSearchRequest(
            data=[query_dense_vector],  # 传入用户问题的稠密向量
            anns_field="dense_vector",  # 搜索稠密向量字段
            param={
                "metric_type": "COSINE",
                "params": {},
            },  # 使用余弦相似度
            limit=3,  # 向量检索最多返回3个候选
        )

        # ====================================================
        # 第八步：创建BM25关键词检索请求
        # ====================================================
        # 创建Sparse检索请求
        sparse_request = AnnSearchRequest(
            data=[question],  # 直接传入原始查询文本
            anns_field="sparse_vector",  # 搜索BM25稀疏向量字段
            param={
                "metric_type": "BM25",
                "params": {},
            },  # 使用BM25相关性评分
            limit=3,  # BM25检索最多返回3个候选
        )

        # ====================================================
        # 第九步：执行Hybrid Search
        # ====================================================
        # 同时执行两路检索并融合结果
        results = client.hybrid_search(
            collection_name=COLLECTION_NAME,  # 指定目标Collectionreqs=[dense_request,sparse_request,],  # 传入Dense与Sparse两路请求
            # 使用RRF根据两路排名融合
            ranker=RRFRanker(
                k=60
            ),
            limit=2,  # 融合后最终返回前2个文档
            output_fields=["text","source",],  # 返回正文和来源
        )

        # ====================================================
        # 第十步：输出融合结果
        # ====================================================print("Embedding模型：text-embedding-v1")
        print("Embedding维度：",embedding_dimension,)

        print("查询问题：",question,)

        print("Hybrid Search结果：")

        for rank, hit in enumerate(results[0],start=1,):  # 遍历融合后的检索结果
            print("hit:",hit)
            print(f"{rank}. RRF分数：{hit['distance']:.6f}")  # 输出RRF融合分数
            print("   内容：",hit["entity"]["text"])  # 输出文档正文
            print("   来源：",hit["entity"]["source"])  # 输出文档来源

    finally:
        pass
        # 无论运行成功还是失败都会进入finally
        # if client.has_collection(COLLECTION_NAME):  # 判断临时Collection是否存在
        #     client.drop_collection(COLLECTION_NAME)  # 删除测试使用的Collectionif __name__ == "__main__":
    main()
```

以上代码运行结果如下：

![cI8V47v5\.jpg](图片和附件/cI8V47v5.jpg)

以上代码注意如下几点：

1. sparse\_vector 无需手动写入：插入数据时只提供 text 字段即可，BM25 函数会自动生成稀疏向量。

2. dense\_vector 需要手动提供：与 sparse\_vector 不同，稠密向量必须由外部 Embedding 模型生成并显式写入。

3. RRF 分数返回的是 RRF 融合分数（通常很小，0\.01\~0\.03 量级），只用于最终排序，数值本身没有绝对含义。

4. 最后的results 是一个 SearchResult 对象，它内部封装了一个二维列表 data。通过 results\[0\] 可以访问第一个查询的命中列表。

#### 3\.2\.2\.4\. Weighted Ranker加权融合（了解）

除了 RRF，Milvus 还提供 WeightedRanker，这种方式可以给每一路检索指定一个权重值，权重值范围是\[0\-1\]，权重越高，表示该路检索结果越重要。

WeightedRanker分值计算大概过程：首先获取稀疏和稠密向量选出的文档对应的分值，对这些分值进行归一化（将数值转换到\[0\-1\]范围），然后根据设置的不同权重，将归一化后的分值与对应的权重相乘，得到最终每个文档的分数，然后按照这个分数从高到低排序。

```Plain Text
# 如下示例中，表示在融合结果中更重视向量检索。权重值与传入到hybrid_search中reqs列表的顺序一致。
WeightedRanker(
    0.4,  # BM25检索0.6,  # 向量检索
)
```

Weighted Ranker 适合已经通过评估确定某一路更可靠的场景。例如企业知识库中的产品编号查询很多，可以提高 BM25 权重；自然语言问答占主导时，可以提高向量检索权重。

RRF 和 Weighted Ranker 的对比：

在没有离线评估数据时，可以先用 RRF 建立基线；有评估数据以后，再比较不同权重下的 Hit@K、MRR 或 NDCG。

### 3\.2\.3\. Hybrid Search与Hybrid RAG的区别

Hybrid Search 和 Hybrid RAG 不是同一个概念。

两者可以结合使用：使用Hybrid RAG 构建工作流，工作流RAG部分使用Hybrid Search进行混合检索。

### 3\.2\.4\. HyBrid Search混合检索RAG案例

下面模拟一个电商售后 Hybrid Search RAG。查询中同时包含产品型号 AB\-120 和退款时效问题，BM25 负责补充精确词项匹配，向量检索负责召回退款语义，RRF 负责融合两路排序，最终结果交给LLM进行回复。

案例还包含产品和租户过滤。AB\-121 属于其他产品，内部批发价格属于其他租户，两份文档都不能进入最终候选。整体流程如下：

![RwovCZ0Y\.jpg](图片和附件/RwovCZ0Y.jpg)

```Plain Text
from langchain_community.embeddings import DashScopeEmbeddingsfrom langchain_core.messages import HumanMessage,SystemMessagefrom pymilvus import AnnSearchRequest,DataType,Function,FunctionType,MilvusClient,RRFRankerfrom env_utils import DASHSCOPE_API_KEYfrom init_llm import deepseek_llm_flash


# ============================================================
# 第一步：配置Milvus
# ============================================================MILVUS_URI = "http://192.168.179.5:19530"MILVUS_DB_NAME = "default"COLLECTION_NAME = (
    "tmp_course_hybrid_search_20260909"
)


# ============================================================
# 第二步：创建Collection
# ============================================================def create_collection(client: MilvusClient, embedding_dimension: int) -> None:
    """创建同时支持向量检索和BM25检索的Collection。"""if client.has_collection(COLLECTION_NAME):
        client.drop_collection(COLLECTION_NAME)

    schema = client.create_schema(
        auto_id=True,
        enable_dynamic_field=False,
    )

    # Milvus自动生成主键
    schema.add_field(
        field_name="id",
        datatype=DataType.INT64,
        is_primary=True,
        auto_id=True,
    )

    # 业务文档唯一标识
    schema.add_field(
        field_name="doc_id",
        datatype=DataType.VARCHAR,
        max_length=100,
    )

    # 文档正文，同时作为BM25输入
    schema.add_field(
        field_name="text",
        datatype=DataType.VARCHAR,
        max_length=1000,
        enable_analyzer=True,
        analyzer_params={"tokenizer": "jieba"},
    )

    # 文档来源
    schema.add_field(
        field_name="source",
        datatype=DataType.VARCHAR,
        max_length=200,
    )

    # 产品类型，用于过滤
    schema.add_field(
        field_name="product",
        datatype=DataType.VARCHAR,
        max_length=100,
    )

    # 租户标识，用于权限隔离
    schema.add_field(
        field_name="tenant_id",
        datatype=DataType.VARCHAR,
        max_length=100,
    )

    # 保存Embedding产生的稠密向量
    schema.add_field(
        field_name="dense_vector",
        datatype=DataType.FLOAT_VECTOR,
        dim=embedding_dimension,
    )

    # 保存Milvus生成的BM25稀疏向量
    schema.add_field(
        field_name="sparse_vector",
        datatype=DataType.SPARSE_FLOAT_VECTOR
    )

    # text字段自动转换成sparse_vectorschema.add_function(
        Function(
            name="bm25_function",
            function_type=FunctionType.BM25,
            input_field_names=["text"],
            output_field_names=["sparse_vector"],
        )
    )

    index_params = client.prepare_index_params()

    # 为语义向量创建COSINE索引
    index_params.add_index(
        field_name="dense_vector",
        index_type="AUTOINDEX",
        metric_type="COSINE",
    )

    # 为BM25稀疏向量创建倒排索引
    index_params.add_index(
        field_name="sparse_vector",
        index_type="SPARSE_INVERTED_INDEX",
        metric_type="BM25",
    )

    # 创建Collectionclient.create_collection(
        collection_name=COLLECTION_NAME,
        schema=schema,
        index_params=index_params,
    )


# ============================================================
# 第三步：将检索结果转换成模型上下文
# ============================================================def format_context(results: list[dict]) -> str:
    """将Milvus检索结果转换成带来源的上下文。"""return "\n\n".join(
        (
            f"[{rank}] 来源：{hit['entity']['source']}\n"f"{hit['entity']['text']}"
        )
        for rank, hit in enumerate(results,start=1)
    )


# ============================================================
# 第四步：执行Hybrid Search RAG
# ============================================================def main() -> None:
    # 初始化Milvus客户端
    client = MilvusClient(
        uri=MILVUS_URI,
        db_name=MILVUS_DB_NAME,
    )

    try:
        # 初始化真实Embedding模型
        embedding_model = DashScopeEmbeddings(
                                model="text-embedding-v1",
                                dashscope_api_key=DASHSCOPE_API_KEY
                            )

        # 准备跨产品、跨租户的售后文档
        documents = [
            {
                "doc_id": "model-ab120",
                "text": "AB-120 是降噪耳机型号。",
                "source": "产品型号.md",
                "product": "降噪耳机",
                "tenant_id": "tenant_a",
            },
            {
                "doc_id": "refund-noise",
                "text": "降噪耳机退货后，退款通常三个工作日内到账。",
                "source": "退款规则.md",
                "product": "降噪耳机",
                "tenant_id": "tenant_a",
            },
            {
                "doc_id": "model-ab121",
                "text": "AB-121 是运动耳机型号。",
                "source": "产品型号.md",
                "product": "运动耳机",
                "tenant_id": "tenant_a",
            },
            {
                "doc_id": "price-tenant-b",
                "text": "AB-120 的内部批发价格是保密信息。",
                "source": "内部价格.md",
                "product": "降噪耳机",
                "tenant_id": "tenant_b",
            },
        ]

        # 使用真实Embedding生成稠密向量
        dense_vectors = embedding_model.embed_documents([document["text"] for document in documents])

        # 根据实际向量维度创建Collectioncreate_collection(
            client=client,
            embedding_dimension=len(dense_vectors[0]),
        )

        # 组装写入数据
        # sparse_vector由Milvus自动生成
        insert_data = []

        for document, dense_vector in zip(documents,dense_vectors):
            insert_data.append({
                    **document, # 包含所有文档字段
                    "dense_vector": dense_vector,
                })

        # 写入数据
        client.insert(
            collection_name=COLLECTION_NAME,
            data=insert_data,
        )

        # 确保插入的数据已经写入Milvusclient.flush(COLLECTION_NAME)
        # 将Collection加载到内存以供搜索
        client.load_collection(COLLECTION_NAME)

        # 用户问题同时包含型号和退款语义
        question = "AB-120 退货后多久到账？"

        # 两路检索必须使用同一过滤条件
        filter_expression = 'product == "降噪耳机" and tenant_id == "tenant_a"'

        # 将用户问题转换成稠密向量
        query_dense_vector = embedding_model.embed_query(question)

        # 向量语义检索请求
        dense_request = AnnSearchRequest(
            data=[query_dense_vector],
            anns_field="dense_vector",
            param={
                "metric_type": "COSINE",
                "params": {},
            },
            limit=3,
            expr=filter_expression, # 过滤条件
        )

        # BM25关键词检索请求
        sparse_request = AnnSearchRequest(
            data=[question],
            anns_field="sparse_vector",
            param={
                "metric_type": "BM25",
                "params": {},
            },
            limit=3,
            expr=filter_expression, # 过滤条件
        )

        # 同时执行两路检索并使用RRF融合
        hybrid_results = client.hybrid_search(
            collection_name= COLLECTION_NAME,
            reqs=[dense_request,sparse_request,], # 传入Dense与Sparse两路请求
            ranker=RRFRanker(k=60),  # 使用RRF根据两路排名融合
            limit=2,
            output_fields=[
                "doc_id", # 文档ID"text", # 文档内容
                "source", # 文档来源
                "product", # 产品类型
                "tenant_id", # 租户ID
            ],
        )[0]

        # 将融合结果转换成模型上下文
        context = format_context(hybrid_results)

        # 调用真实DeepSeek生成回答
        response = deepseek_llm_flash.invoke([
            SystemMessage(content=("你是售后助手。只能根据参考资料回答，必须保留时间和条件，最后列出来源。")),
            HumanMessage(content=(f"参考资料：\n{context}\n\n用户问题：{question}"))
        ])

        print("查询问题：",question)
        print("过滤条件：",filter_expression)

        print("RRF融合结果：",hybrid_results)

        for rank, hit in enumerate(hybrid_results,start=1,):
            print(f"{rank}. rrf_score= {hit['distance']:.6f} doc_id= {hit['entity']['doc_id']}")
            print("   内容：", hit["entity"]["text"],)
            print("   来源：", hit["entity"]["source"],)

        print("最终回答：",response.content)

    finally:
        pass
        # 测试结束后删除临时Collection
        # if client.has_collection(COLLECTION_NAME):
        #     client.drop_collection(COLLECTION_NAME)


if __name__ == "__main__":
    main()
```

运行结果如下：

![rY7KUc8P\.jpg](图片和附件/rY7KUc8P.jpg)

## 3\.3\. Rerank精排

Hybrid Search 解决的是“候选文档召回”的问题。它通过 BM25 和向量检索，把可能相关的文档尽量找出来，再用 RRF 或 Weighted Ranker 生成一份融合排序。经过这一步，正确文档通常已经进入候选集，但候选集内部的先后顺序不一定足够准确。

原因是 Hybrid Search 的排序依据仍然比较粗。BM25 根据词项是否出现、出现次数和文档长度计算分数，它关注的是字面匹配；向量检索根据查询向量和文档向量的相似度计算分数，它关注的是整体语义方向；RRF 只读取两路检索中的排名，它不重新阅读文档内容，也不判断某段文字是否真正回答了用户的问题。

例如用户问：“钱什么时候退回银行卡?”，候选文档中有两条内容：

```Plain Text
文档A：退款将按照原支付渠道原路退回。
文档B：仓库验收通过后，款项通常三个工作日退回原支付渠道。
```

两条文档都包含退款、原路退回等关键词，向量检索也可能给它们较高的相似度。但用户真正问的是“什么时候”，文档B明确给出了“三个工作日”这一关键信息，文档A只说明了退款渠道，没有回答时间问题。Hybrid Search 的粗排可能把两者排得很接近，甚至把文档A排在前面。

Reranker精排的任务就是重新阅读用户问题和每一篇候选文档，判断它们之间的真实相关性，再生成一份更准确的排序。它不负责从整个知识库中召回文档，只对已经召回的少量候选进行二次排序。

因此，完整检索流程通常是两阶段：

1. 第一阶段：召回。从海量知识库中快速找出Top N篇可能相关的文档

2. 第二阶段：精排。使用Reranker对Top N篇文档重新评分，保留Top K篇

召回阶段优先考虑速度和覆盖范围，精排阶段优先考虑准确度。经过召回后，需要精排的文档数量通常只有几十篇，因此可以使用计算成本更高、效果更好的模型。

### 3\.3\.1\. Ranker精排使用方式

Reranking 放在检索后处理阶段。Hybrid Search 负责把多路检索结果融合成一份排序，Reranking 则负责对这份排序中的候选文档重新判断相关性。

Hybrid Search 的候选文档可能已经包含正确答案，但排序不够准确。Reranking 先接收 Hybrid Search 返回的 Top N 候选，再对每篇文档重新评分，最后保留 Top K。

完整流程如下：

![J3o6UUuH\.jpg](图片和附件/J3o6UUuH.jpg)

Reranker 通常使用 Cross\-Encoder （交叉编码器）结构。Cross\-Encoder 把查询和文档拼接在一起，同时送入模型，让模型在内部完成查询和文档的交互，这样得到的相关性判断更精细，但计算成本更高，所以只对少量候选使用。

常见实现方式有如下两种。

1\) **第一种是 LLM 列表重排。把候选文档和查询交给大模型，让模型按相关性输出排序后的来源列表。**

LLM 列表重排实现简单，适合候选数量不多的场景，但它本质上仍然依赖大模型阅读列表，可能出现遗漏、顺序不稳定或没有严格遵守输出格式的问题。

使用形式如下：

```Plain Text
class RankResult(BaseModel):
    sources: list[str] = Field(description="按相关性从高到低排列的来源名称")


rank_model = deepseek_llm_flash.with_structured_output(RankResult)
rank_result = rank_model.invoke(
    "用户问题：耳机退款多久到账？\n""请按相关性从高到低排列下面来源，只返回来源名称。\n"
    f"候选资料：\n{candidate_text}"
)
```

2\) **第二种是专用 Reranker 模型。也就是使用专门Reranker 模型进行评分**

LangChain 提供 DashScope Reranker 集成，可以调用 gte\-rerank\-v2 对查询和候选文档重新评分。LangChain更多Reranker方式支持参考：https://reference\.langchain\.com/python/langchain\-community/document\_compressors

使用形式如下：

```Plain Text
import dashscopefrom langchain_community.document_compressors import DashScopeRerankreranker = DashScopeRerank(
    client=dashscope.TextReRank,  # 显式传入 DashScope 客户端，避免错误
    model="gte-rerank-v2",
    top_n=3,
    api_key=DASHSCOPE_API_KEY,
)

reranked_documents = reranker.compress_documents(
    candidates,
    question,
)
```

目前使用LangChain中，直接只传 api\_key 会触发 Pydantic 参数校验错误，因此需要显式传入 client=dashscope\.TextReRank。

Reranking 使用注意事项：

1. Reranker 只调整已有候选的顺序，不能找回召回阶段漏掉的文档。

2. 召回阶段保留 20 到 100 篇候选，精排阶段保留 3 到 10 篇，是比较常见的范围。

3. 专用 Reranker 比 LLM 列表重排更稳定，但会增加一次模型调用。

### 3\.3\.2\. Ranker精排案例

#### 3\.3\.2\.1\. Reranker单独案例

如下案例演示Reranker 如何改变候选顺序，不涉及 Milvus 检索。

```Plain Text
import dashscopefrom langchain_community.document_compressors import DashScopeRerankfrom langchain_core.documents import Documentfrom env_utils import DASHSCOPE_API_KEYdef main() -> None:
    # ========================================================
    # 第一步：准备候选文档
    # ========================================================documents = [
        Document(
            page_content="仓库验收通过后，款项通常三个工作日退回原支付渠道。",
            metadata={"doc_id": "refund-semantic"},
        ),
        Document(
            page_content="收货后七日内可以申请无理由退货，需要保证商品和包装完整。",
            metadata={"doc_id": "return-rule"},
        ),
        Document(
            page_content="AB-120 是降噪耳机型号，适用于蓝牙连接。",
            metadata={"doc_id": "model-ab120"},
        ),
        Document(
            page_content="订单发货后可以查看物流轨迹，超过48小时未更新联系客服。",
            metadata={"doc_id": "logistics"},
        ),
        Document(
            page_content="退款将按照原支付渠道原路退回。",
            metadata={"doc_id": "refund-channel"},
        ),
    ]

    question = "钱什么时候能退回银行卡？"print("Reranker输入顺序：")
    for rank, document in enumerate(documents, start=1):
        print(f"{rank}. {document.metadata['doc_id']}，{document.page_content}")

    # ========================================================
    # 第二步：创建DashScope Reranker
    # ========================================================reranker = DashScopeRerank(
        client=dashscope.TextReRank, # 显式传入 DashScope 客户端，避免错误
        model="gte-rerank-v2",
        top_n=3,
        api_key=DASHSCOPE_API_KEY,
    )

    # ========================================================
    # 第三步：对候选文档重新评分和排序
    # ========================================================reranked_documents = reranker.compress_documents(
        documents,
        question,
    )

    # ========================================================
    # 第四步：输出精排结果
    # ========================================================print("\nReranker精排结果：")
    for rank, document in enumerate(reranked_documents, start=1):
        print(
            f"{rank}. {document.metadata['doc_id']} "f"relevance={document.metadata['relevance_score']:.6f}"
        )
        print("   内容：", document.page_content)


if __name__ == "__main__":
    main()
```

以上代码运行结果如下：

![ANykMGqc\.jpg](图片和附件/ANykMGqc.jpg)

#### 3\.3\.2\.2\. Hybrid Search \+ Reranker综合案例

实际 RAG 中，Reranker 使用的候选文档通常来自 Hybrid Search。下面案例先使用 Milvus 的 BM25 和向量检索召回 Top 5 文档，再使用 DashScope Reranker 精排 Top 3。

```Plain Text
import dashscopefrom langchain_community.document_compressors import DashScopeRerankfrom langchain_community.embeddings import DashScopeEmbeddingsfrom langchain_core.documents import Documentfrom pymilvus import AnnSearchRequest, DataType, Function, FunctionType, MilvusClient, RRFRankerfrom env_utils import DASHSCOPE_API_KEYMILVUS_URI = "http://192.168.179.5:19530"MILVUS_DB_NAME = "default"COLLECTION_NAME = "tmp_course_hybrid_rerank"def create_collection(client: MilvusClient, dimension: int) -> None:
    """创建同时包含稠密向量和BM25稀疏向量的Collection。"""if client.has_collection(COLLECTION_NAME):
        client.drop_collection(COLLECTION_NAME)

    schema = client.create_schema(auto_id=True, enable_dynamic_field=False)
    schema.add_field("id", DataType.INT64, is_primary=True, auto_id=True)
    schema.add_field("doc_id", DataType.VARCHAR, max_length=100)
    schema.add_field(
        "text",
        DataType.VARCHAR,
        max_length=1000,
        enable_analyzer=True,
        analyzer_params={"tokenizer": "jieba"},
        enable_match=True,
    )
    schema.add_field("dense_vector", DataType.FLOAT_VECTOR, dim=dimension)
    schema.add_field("sparse_vector", DataType.SPARSE_FLOAT_VECTOR)
    schema.add_function(
        Function(
            name="bm25_function",
            function_type=FunctionType.BM25,
            input_field_names=["text"],
            output_field_names=["sparse_vector"],
        )
    )

    index_params = client.prepare_index_params()
    index_params.add_index(
        field_name="dense_vector",
        index_type="AUTOINDEX",
        metric_type="COSINE",
    )
    index_params.add_index(
        field_name="sparse_vector",
        index_type="SPARSE_INVERTED_INDEX",
        metric_type="BM25",
    )
    client.create_collection(
        collection_name=COLLECTION_NAME,
        schema=schema,
        index_params=index_params,
    )


def main() -> None:
    client = MilvusClient(
        uri=MILVUS_URI,
        db_name=MILVUS_DB_NAME
    )

    try:
        # ====================================================
        # 第一步：初始化Embedding模型
        # ====================================================embedding_model = DashScopeEmbeddings(
            model="text-embedding-v1",
            dashscope_api_key=DASHSCOPE_API_KEY,
        )

        # ====================================================
        # 第二步：准备候选知识库文档
        # ====================================================documents = [
            {"doc_id": "refund-semantic", "text": "仓库验收通过后，款项通常三个工作日退回原支付渠道。"},
            {"doc_id": "refund-channel", "text": "退款将按照原支付渠道原路退回。"},
            {"doc_id": "return-rule", "text": "收货后七日内可以申请无理由退货，需要保证商品和包装完整。"},
            {"doc_id": "model-ab120", "text": "AB-120 是降噪耳机型号，适用于蓝牙连接。"},
            {"doc_id": "logistics", "text": "订单发货后可以查看物流轨迹，超过48小时未更新联系客服。"},
        ]

        # 生成稠密向量
        dense_vectors = embedding_model.embed_documents(
            [item["text"] for item in documents]
        )

        # 创建Collectioncreate_collection(client, len(dense_vectors[0]))

        # 插入数据
        client.insert(
            collection_name=COLLECTION_NAME,
            data=[
                {**item, "dense_vector": vector}
                for item, vector in zip(documents, dense_vectors)
            ],
        )
        # 确保插入的数据已经写入Milvusclient.flush(COLLECTION_NAME)
        # 将Collection加载到内存以供搜索
        client.load_collection(COLLECTION_NAME)

        # ====================================================
        # 第三步：执行Hybrid Search召回Top 5
        # ====================================================question = "钱什么时候能退回银行卡？"query_vector = embedding_model.embed_query(question)

        dense_request = AnnSearchRequest(
            data=[query_vector],
            anns_field="dense_vector",
            param={"metric_type": "COSINE", "params": {}},
            limit=5,
        )
        sparse_request = AnnSearchRequest(
            data=[question],
            anns_field="sparse_vector",
            param={"metric_type": "BM25", "params": {}},
            limit=5,
        )

        # 混合检索：同时执行两路检索并使用RRF融合
        hybrid_results = client.hybrid_search(
            collection_name=COLLECTION_NAME,
            reqs=[dense_request, sparse_request],
            ranker=RRFRanker(k=60),
            limit=5,
            output_fields=["doc_id", "text"],
        )[0]

        candidates = [
            Document(
                page_content=hit["entity"]["text"],
                metadata={
                    "doc_id": hit["entity"]["doc_id"],
                    "rrf_score": hit["distance"],
                },
            )
            for hit in hybrid_results
        ]

        print("Hybrid Search候选：")
        for rank, document in enumerate(candidates, start=1):
            print(
                f"{rank}. {document.metadata['doc_id']} "f"rrf={document.metadata['rrf_score']:.6f} | "f"{document.page_content}"
            )

        # ====================================================
        # 第四步：使用Reranker精排Top 3
        # ====================================================reranker = DashScopeRerank(
            client=dashscope.TextReRank, # 显式传入 DashScope 客户端，避免错误
            model="gte-rerank-v2",
            top_n=3,
            api_key=DASHSCOPE_API_KEY,
        )

        # 精排Top 3
        reranked = reranker.compress_documents(candidates, question)

        print("\nReranker精排结果：")
        for rank, document in enumerate(reranked, start=1):
            print(
                f"{rank}. {document.metadata['doc_id']} "f"relevance={document.metadata['relevance_score']:.6f} | "f"{document.page_content}"
            )

    finally:
        pass
        # 删除Collection
        # if client.has_collection(COLLECTION_NAME):
        #     client.drop_collection(COLLECTION_NAME)


if __name__ == "__main__":
    main()
```

以上代码运行结果如下：

![WpKThWet\.jpg](图片和附件/WpKThWet.jpg)

## 3\.4\. 检索前查询转换与检索后处理技术

一个 RAG 系统即使已经完成文档切分、Embedding 和向量库构建，检索结果仍然可能不理想。常见问题可以分成两类。

第一类问题发生在检索之前。用户问题通常很短，表达也可能很口语化，例如“耳机怎么退”。知识库文档往往使用更完整的书面表达，例如“耳机退货需要保持包装和配件完整”。查询和文档使用的词语不一致，Embedding 相似度就会下降，正确文档可能无法进入候选集。

第二类问题发生在检索之后。检索器可能返回很多候选文档，其中有些只和问题部分相关，有些和问题使用的是同一个主题但方向不同，还有些文档很长，真正有用的内容只有一两句话。把这些文档原样交给大模型，会浪费上下文，也容易让模型把注意力放在无关内容上。

本节讲的技术分别处理这两个阶段：检索前（让查询更容易找到正确的文档）和检索后（让候选文档更相关、更精炼）。基于前面已经讲过的查询改写、Rerank精排，继续介绍 Multi\-Query、查询分解、HyDE、Routing、Reranking 和 Contextual Compression。

### 3\.4\.1\. Multi\-Query\-多查询

Multi\-Query是让模型针对同一个用户问题生成多个不同表达的检索查询，然后分别执行检索，最后把多路结果合并去重。

例如用户提问“耳机怎么退？”，模型可以生成如下不同表达：

```Plain Text
耳机退货条件
耳机无理由退货期限
耳机退款申请要求
```

这三个查询表达的是同一个意图，但用词不同。每个查询都会在向量库中执行一次相似度检索，最终把命中的文档合并成候选集。

Multi\-Query 解决的问题是“单次查询表达可能不够全面”。用户只输入一种说法时，某些正确文档可能使用另一种说法，单路检索会漏掉，多生成几个查询，可以扩大召回范围。

执行流程如下：“用户问题\-\>LLM生成多个查询变体\-\>分别执行向量检索\-\>合并结果\-\>按文档ID或来源去重\-\>得到候选文档”。查询变体通常使用结构化输出生成，这样可以保证结果是一组字符串列表，而不是一段无法解析的自然语言。例如：

```Plain Text
class QueryList(BaseModel):
    queries: list[str] = Field(description="用于检索的查询列表")


multi_query_model = deepseek_llm_flash.with_structured_output(QueryList)
multi_query_result = multi_query_model.invoke(
    "针对问题‘耳机怎么退’，生成3个不同表达的中文检索查询。"
)
```

拿到查询列表后，逐个执行检索：

```Plain Text
multi_query_documents = []
seen_sources = set()

for query in multi_query_result.queries[:3]:
    for document in vector_store.similarity_search(query, k=1):
        source = document.metadata["source"]

        if source not in seen_sources:
            multi_query_documents.append(document)
            seen_sources.add(source)
```

Multi\-Query与之前的查询改写类似，但解决的问题不同：

- 查询改写：把一个查询改成另一个更适合检索的查询。查询改写的重点是词汇对齐和补充业务词，它的输出通常是一条查询，检索次数还是和原来一样。

- Multi\-Query：把一个查询扩展成多个查询，并分别检索后合并结果。Multi\-Query 的重点不是“改成更好的一条查询”，而是“生成多条不同表达的查询，然后全部执行检索”。

实际项目中，查询改写通常是基础能力，Multi\-Query 和查询分解是在召回不足时按需增加的策略，它们可以组合使用，但不是必须全部启用。

使用 Multi\-Query 时要注意：

1. 查询数量不能无限增加，一般控制在 2 到 5 个。

2. 不同查询可能命中同一篇文档，必须去重。

3. 合并顺序不等于最终相关性排序，后续仍然可以接 Reranking。

4. 产品型号、订单号、错误码等精确内容不要随意改写，否则可能破坏检索条件。

### 3\.4\.2\. 查询分解

查询分解面对的是一个复杂问题中包含多个意图或条件，将这些意图或条件拆成单独的子问题，方便更精准的检索。

例如用户提问“耳机能不能退，退款多久到账？”，这个问题实际上包含两个子问题：

- 耳机是否支持退货？

- 退款多久到账？

如果把整句话直接转成一个向量，向量会混合“退货”和“退款”两个意图。相似度检索可能只召回其中一个主题的文档，或者把两个主题的文档都排在中间。拆成子问题后，每个子问题单独检索，可以分别找到对应证据。

查询分解执行流程：“复杂问题\-\>LLM拆分成子问题\-\>每个子问题分别检索\-\>合并子问题证据\-\>使用原始问题组织最终回答”，代码使用示例如下：

```Plain Text
decomposition_result = multi_query_model.invoke(
    "把问题‘耳机能否退货，退款多久到账’拆成2个独立中文子问题。"
)

decomposition_documents = []
seen_sources = set()

for question in decomposition_result.queries[:2]:
    for document in vector_store.similarity_search(question, k=1):
        source = document.metadata["source"]

        if source not in seen_sources:
            decomposition_documents.append(document)
            seen_sources.add(source)
```

使用查询分解时要注意：

1. 子问题之间可能存在依赖关系，例如“退货之后什么时候退款”，拆开后要保留“退货”这个前置条件。

2. 拆分后的子问题不能改变用户原意。

3. 多个子问题的检索结果需要重新整合，不能把互不相关的证据拼在一起。

4. 子问题数量过多会增加检索次数和上下文长度。

### 3\.4\.3\. HyDE\-假设文档嵌入

HyDE 的全称是 Hypothetical Document Embeddings，中文可以理解为“假设文档嵌入”,它的做法不是直接使用用户问题去检索，而是先让模型根据问题生成一段假设性答案，再使用这段假设答案的向量去检索真实文档。

用户问题通常很短，如“耳机怎么退？”，知识库文档通常更长，而且使用书面表达：

```Plain Text
耳机退货需要满足七日无理由退货条件，商品、包装和配件需要保持完整。
```

这两个文本在长度、词汇和表达方式上差异很大，向量相似度可能不够高。HyDE 让模型先生成一段类似知识库文档的假设答案，例如：

```Plain Text
耳机退货需要在签收后七天内申请，保持商品和包装完好，联系客服获取退货地址，寄回后等待退款。
```

这段假设答案不是最终回答，它的作用只是生成一个更接近知识库文档风格的检索向量，然后用这个向量去搜索真实文档。

HyDE执行流程如下：“用户问题\-\>LLM生成假设性答案\-\>对假设答案生成Embedding\-\>使用该向量检索真实文档\-\>返回真实文档”。代码使用示例如下：

```Plain Text
hypothetical_document = deepseek_llm_flash.invoke(
    "针对问题‘耳机怎么退’，生成一段不超过50字的假设性售后答案，用于向量检索。"
).content

hyde_documents = vector_store.similarity_search(
    hypothetical_document,
    k=2,
)
```

HyDE 的风险是假设答案可能偏离事实。模型生成的假设答案不是知识库原文，如果它编造了错误条件，检索就可能被带到错误方向。因此：

1. HyDE 适合查询和文档表达差异大的场景。

2. 产品编号、错误码等精确内容不适合只依赖 HyDE。

3. 可以同时保留原始查询检索和 HyDE 检索，再融合两路结果，降低单一假设答案带来的风险。

4. 假设答案只用于检索，不能直接作为最终答案。

### 3\.4\.4\. Routing\-路由

Routing 是根据问题类型选择不同知识库、Retriever 或工具。它的核心不是改写查询，而是决定“这次应该去哪个数据源查”。

例如系统同时包含如下知识库：

```Plain Text
产品知识库
售后知识库
物流系统知识库
```

用户提问“AB\-120是什么型号？”，正确路由是产品知识库；用户提问“我的订单物流到哪里了？”正确路由是物流系统。

Routing 和 metadata filter 不同。metadata filter 是在同一个检索器内部根据字段过滤文档，例如只保留 product == "降噪耳机" 的文档；Routing 是在检索之前选择不同的数据源或检索器。两者可以组合使用：先路由到售后知识库，再在售后知识库内部按产品过滤。

Routing 可以使用规则实现，例如检测到型号就走产品库；也可以使用模型分类。使用的代码示例如下：

```Plain Text
# 1.使用模型结构化输出问题对应的资料库
class RouteResult(BaseModel):
    route: Literal["product", "after_sale", "logistics"]


route_model = deepseek_llm_flash.with_structured_output(RouteResult)
route_result = route_model.invoke(
    "问题：AB-120是什么型号？请选择product、after_sale、logistics中的一个路由。"
)

#2.按路由结果选择文档
routed_documents = [
    document
    for document in documents
    if document.metadata["route"] == route_result.route
]

routed_store = InMemoryVectorStore(embedding_model)
routed_store.add_documents(routed_documents)
route_documents = routed_store.similarity_search("AB-120是什么型号？", k=1)
```

使用 Routing 时要注意：

1. 路由错误会导致正确文档根本不会进入候选范围，所以必须设置默认路由或回退策略。

2. 一个问题可能同时涉及多个数据源，例如“退货后物流怎么处理”，这时需要多路路由，而不是只选择一个。

3. 路由结果应该记录到日志，方便分析召回失败是路由问题还是检索问题。

4. 规则路由稳定、成本低；模型路由灵活，但需要评估准确率。

### 3\.4\.5\. Reranking\-重排

Reranking是一种检索后处理技术。无论候选文档来自向量检索、BM25还是Hybrid Search，都可以在召回Top N之后使用Reranker重新排序。

Reranker的完整原理、DashScopeRerank接入方式和案例已经在前面小节讲解，本节不再重复。实际使用时，先通过Hybrid Search完成召回和融合，再把融合后的候选文档交给Reranker处理。

### 3\.4\.6\. Contextual Compression\-上下文压缩

Contextual Compression 解决的是“检索结果太长、无关内容太多”的问题。它的做法是在检索之后，从候选文档中提取和当前问题真正相关的内容，再把压缩后的文本交给大模型。例如候选文档是：

```Plain Text
耳机退款：仓库验收后发起退款，通常三个工作日内到账。退货申请需要保持包装完整。
```

用户问：“退款多久到账？”，Contextual Compression压缩器可以只保留如下内容，然后把这段内容交给大模型，减少 Token，也让模型更容易关注关键信息。

```Plain Text
仓库验收后发起退款，通常三个工作日内到账。
```

Contextual Compression 有两种实现方式。

1. 抽取式压缩从原文中选出相关句子或段落，不改变原文措辞，适合售后规则、合同、法规等不能改写的文档。

2. 抽象式压缩让模型用自己的话重新总结。这种方式的表达更简洁，但可能改变原文条件，例如把“通常三个工作日”改成“三个工作日”，丢失“通常”这个限定词。对事实准确性要求高的文档，不建议只使用抽象式压缩。

如下示例是使用 LLM 做抽取式压缩：

```Plain Text
compressed_context = deepseek_llm_flash.invoke(
    "从下面资料中只提取回答‘退款多久到账’需要的原文信息，不要补充资料外内容。\n"
    f"资料：{reranked_documents[0].page_content}"
).content
```

使用 Contextual Compression 时要注意：

1. 压缩器可能删除限制条件，法规、合同和售后规则要保留原文校验。

2. 压缩结果和原始文档都要保留，方便追溯来源。

3. 压缩只减少上下文，不改变候选文档的排序。

4. 如果压缩后资料不足以回答，应该拒答或转人工，而不是让模型自行补充。

### 3\.4\.7\. 技术组合与选型

通过以上学习，检索前查询转换与检索后处理技术相关技术点解决的问题和使用位置总结如下：

使用哪些技术取决于系统当前的问题。例如：

- 用户表达不固定:Multi\-Query或HyDE

- 用户问题包含多个条件:查询分解

- 系统有多个互不相关的知识库:Routing

- 召回正确但排序不好:Reranking

- 上下文太长:Contextual Compression

这些技术在实际业务中也可以组合使用，并不是全部需要用上，也不是用的越多越好。一个完整的检索流程可以是：

![C41NG2j2\.jpg](图片和附件/C41NG2j2.jpg)

### 3\.4\.8\. 各类型实操示例

如下代码演示Multi\-Query、查询分解、HyDE、Routing、Reranking 和 Contextual Compression 使用，并没有特别的业务逻辑。

```Plain Text
import osfrom typing import Literalfrom langchain_community.embeddings import DashScopeEmbeddingsfrom langchain_core.documents import Documentfrom langchain_core.vectorstores import InMemoryVectorStorefrom pydantic import BaseModel, Fieldfrom init_llm import deepseek_llm_flash

# ============================================================
# 第一步：构建Embedding模型
# ============================================================embedding_model = DashScopeEmbeddings(
    model="text-embedding-v1",
    dashscope_api_key=os.environ["DASHSCOPE_API_KEY"],
)

# ============================================================
# 第二步：定义结构化输出格式
# ============================================================
# 用于 Multi-Queryclass QueryList(BaseModel):
    queries: list[str] = Field(description="用于检索的查询列表")


# 用于 Routingclass RouteResult(BaseModel):
    route: Literal["product", "after_sale", "logistics"]

# 用于 Rerankerclass RankResult(BaseModel):
    sources: list[str] = Field(description="按相关性从高到低排列的来源名称")


# ============================================================
# 第三步：创建真实语义知识库
# ============================================================documents = [
    Document(
        "耳机退货：收货后七日内可以申请退货，包装和配件需要完整。",
        metadata={"source": "耳机售后.md", "route": "after_sale"},
    ),
    Document(
        "耳机退款：仓库验收后发起退款，通常三个工作日内到账。",
        metadata={"source": "耳机退款.md", "route": "after_sale"},
    ),
    Document(
        "产品型号：AB-120 是降噪耳机，AB-121 是运动耳机。",
        metadata={"source": "产品型号.md", "route": "product"},
    ),
    Document(
        "物流查询：订单发货后可以在订单详情查看物流轨迹。",
        metadata={"source": "物流规则.md", "route": "logistics"},
    ),
]

vector_store = InMemoryVectorStore(embedding_model)
vector_store.add_documents(documents)


if __name__ == "__main__":
    # ========================================================
    # 第四步：Multi-Query——真实模型生成多个检索表达
    # 假设用户问题为“耳机怎么退”
    # ========================================================multi_query_model = deepseek_llm_flash.with_structured_output(QueryList)

    multi_query_result = multi_query_model.invoke(
        "针对问题‘耳机怎么退’，生成3个不同表达的中文检索查询。"
    )

    multi_query_documents = []
    seen_sources = set()

    for query in multi_query_result.queries[:3]:
        for document in vector_store.similarity_search(query, k=1):
            source = document.metadata["source"]

            if source not in seen_sources:
                multi_query_documents.append(document)
                seen_sources.add(source)

    print("Multi-Query：", multi_query_result.queries[:3])
    print("Multi-Query召回：", [document.metadata["source"] for document in multi_query_documents])


    # ========================================================
    # 第五步：查询分解——真实模型拆成两个子问题
    # ========================================================decomposition_result = multi_query_model.invoke(
        "把问题‘耳机能否退货，退款多久到账’拆成2个独立中文子问题。"
    )

    decomposition_documents = []
    seen_sources = set()

    for question in decomposition_result.queries[:2]:
        for document in vector_store.similarity_search(question, k=1):
            source = document.metadata["source"]

            if source not in seen_sources:
                decomposition_documents.append(document)
                seen_sources.add(source)

    print("查询分解：", decomposition_result.queries[:2])
    print("查询分解召回：", [document.metadata["source"] for document in decomposition_documents])


    # ========================================================
    # 第六步：HyDE——真实模型生成假设性答案并用它检索
    # ========================================================hypothetical_document = deepseek_llm_flash.invoke(
        "针对问题‘耳机怎么退’，生成一段不超过50字的假设性售后答案，用于向量检索。"
    ).contenthyde_documents = vector_store.similarity_search(
        hypothetical_document,
        k=2,
    )

    print("HyDE假设文档：", hypothetical_document)
    print("HyDE召回：", [document.metadata["source"] for document in hyde_documents])


    # ========================================================
    # 第七步：Routing——真实模型选择知识库
    # ========================================================route_model = deepseek_llm_flash.with_structured_output(RouteResult)

    route_result = route_model.invoke(
        "问题：AB-120是什么型号？请选择product、after_sale、logistics中的一个路由。"
    )

    routed_documents = [
        documentfor document in documentsif document.metadata["route"] == route_result.route
    ]

    routed_store = InMemoryVectorStore(embedding_model)
    routed_store.add_documents(routed_documents)

    route_documents = routed_store.similarity_search(
        "AB-120是什么型号？",
        k=1,
    )

    print("Routing结果：", route_result.route)
    print("Routing召回：", [document.metadata["source"] for document in route_documents])


    # ========================================================
    # 第八步：Reranking——真实模型重新排列候选来源
    # ========================================================candidates = vector_store.similarity_search("耳机", k=4)

    candidate_text = "\n".join(
        f"来源={document.metadata['source']}，内容={document.page_content}"for document in candidates
    )

    rank_model = deepseek_llm_flash.with_structured_output(RankResult)

    rank_result = rank_model.invoke(
        "用户问题：耳机退款多久到账？\n""请按相关性从高到低排列下面来源，只返回来源名称。\n"f"候选资料：\n{candidate_text}"
    )

    source_map = {
        document.metadata["source"]: documentfor document in candidates
    }

    reranked_documents = [
        source_map[source]
        for source in rank_result.sourcesif source in source_map
    ]

    print("重排前：", [document.metadata["source"] for document in candidates])
    print("重排后：", [document.metadata["source"] for document in reranked_documents])


    # ========================================================
    # 第九步：Contextual Compression——提取必要证据
    # ========================================================compressed_context = deepseek_llm_flash.invoke(
        "从下面资料中只提取回答‘退款多久到账’需要的原文信息，不要补充资料外内容。\n"f"资料：{reranked_documents[0].page_content}"
    ).contentprint("上下文压缩：", compressed_context)
```

以上代码运行结果如下：

![SeisxngM\.jpg](图片和附件/SeisxngM.jpg)

## 3\.5\. create\_agent构建RAG Agent

RAG经常和LangGraph一起出现，主要原因是Graph更底层，对显式控制文档相关性评分、查询改写、条件循环等操作更灵活。当然通过LangChain中create\_agent创建的Agent我们也可以构建RAG，这种RAG实际上就是第一章中讲解的“Agentic RAG”，这里我们不再使用InMemoryVectorStore，而是使用Milvus进行文档及向量化存储。

在构建Milvus向量库的时候有两种方式：

1. 通过Milvus\.from\_documents\(\) 创建 LangChain 向量库，通过配置LangChain 把 Document 和 Embedding 交给 Milvus，进而实现文档的写入和检索。这种方式适合纯稠密向量检索场景，如果需要 BM25 稀疏向量或混合检索，应使用原生 pymilvus 建表。

2. 通过pymilvus 原生方式建库、写入数据，再用 langchain\_milvus 封装层挂载同一个 Collection，接入 LangChain 的 Retriever 体系。这种方式更靠底层，适合Milvus中有BM25 \+ 稠密向量混合检索的构建。

以上两种方式都要用到langchain\_milvus ，所以需要提前安装该依赖：

```Plain Text
pip install langchain_milvus
```

### 3\.5\.1\. 使用langchain\_milvus构建Agentis RAG案例

这种方式直接使用Milvus\.from\_documents\(\) 创建 LangChain 向量库，并写入数据和检索。

```Plain Text
import osfrom langchain.agents import create_agentfrom langchain_community.embeddings import DashScopeEmbeddingsfrom langchain_core.documents import Documentfrom langchain_core.prompts import PromptTemplatefrom langchain_core.tools import create_retriever_toolfrom langchain_milvus import Milvusfrom init_llm import deepseek_llm_flash


# ============================================================
# 第一步：连接 Milvus 并使用真实 Embedding 建立售后知识库
# ============================================================MILVUS_URI = os.getenv("MILVUS_URI", "http://192.168.179.5:19530")
MILVUS_DB_NAME = os.getenv("MILVUS_DB_NAME", "default")
COLLECTION_NAME = "rag_course_create_agent_milvus"def build_vector_store() -> Milvus:
    """把售后规则写入 Milvus，返回可检索的向量库对象。"""embedding_model = DashScopeEmbeddings(
        model="text-embedding-v1",
        dashscope_api_key=os.environ["DASHSCOPE_API_KEY"],
    )

    documents = [
        Document(
            page_content="退款规则：仓库验收后发起原路退款，通常三个工作日内到账。",
            metadata={"source": "退款规则.md"},
        ),
        Document(
            page_content="物流规则：订单发货后可以在订单详情查看物流轨迹。",
            metadata={"source": "物流规则.md"},
        ),
    ]

    # drop_old=True 让每次运行都从干净集合开始，避免重复写入干扰演示结果。
    return Milvus.from_documents(
        documents, # 待写入的 Document 列表
        embedding_model, # 用于计算向量的模型
        collection_name=COLLECTION_NAME, # 指定要挂载的集合名
        connection_args={"uri": MILVUS_URI, "db_name": MILVUS_DB_NAME}, # 连接 Milvus 的参数
        drop_old=True, # 每次运行都从干净集合开始
        auto_id=True, # 主键由 Milvus 自动生成
        index_params={"index_type": "AUTOINDEX", "metric_type": "COSINE", "params": {}}, # 索引配置：AUTOINDEX + COSINEsearch_params={"metric_type": "COSINE", "params": {}}, # 检索参数为 COSINE
    )


# ============================================================
# 第二步：把 Milvus Retriever 包装成 Agent 工具
# ============================================================vector_store = build_vector_store()

document_prompt = PromptTemplate.from_template("{page_content}\n来源：{source}")

retriever_tool = create_retriever_tool(
    vector_store.as_retriever(search_kwargs={"k": 1}),
    name="retrieve_after_sale_rules",
    description="检索退款到账和物流规则。遇到退款、到账或物流问题必须调用。",
    document_prompt=document_prompt,
)


if __name__ == "__main__":
    # ========================================================
    # 第三步：使用 create_agent 创建 Agent
    # ========================================================agent = create_agent(
        model=deepseek_llm_flash,
        tools=[retriever_tool],
        system_prompt=(
            "你是电商售后 Agent。涉及退款、到账或物流问题时必须先调用检索工具。""只能根据工具结果回答，回答末尾列出来源。"
        ),
    )

    # ========================================================
    # 第五步：调用 Agent 并观察消息循环
    # ========================================================result = agent.invoke(
        {"messages": [{"role": "user", "content": "退款多久到账？"}]}
    )

    print("result：", result)

    print("\n最终回答：", result["messages"][-1].content)
```

以上代码运行结果如下：

![DSrJOh4t\.jpg](图片和附件/DSrJOh4t.jpg)

以上代码注意如下几点：

1. Milvus\.from\_documents执行流程中会用 Embedding 模型将每个 Document 的 page\_content 转换为向量，若 drop\_old=True 且集合已存在，先删除旧集合，然后创建集合、建立索引，最后将向量、正文和 metadata 写入集合，返回一个可用的Milvus对象。

2. from\_documents\(\) 会自动使用默认字段名（pk、text、vector）。如果你需要自定义字段名，可以按照如下形式传入from\_documents。

```Plain Text
#显式指定 primary_field、text_field、vector_fieldMilvus.from_documents(documents,embedding_model,collection_name=COLLECTION_NAME,primary_field="id",text_field="text",vector_field="vector",...)
```

3. index\_params 与 search\_params 的 metric\_type 必须一致，二者都使用 COSINE，否则检索时会报错或返回不正确的相似度分数。

### 3\.5\.2\. 使用pymilvus构建Agentis RAG案例

Milvus\.from\_documents\(\)与原生pymilvus的区别: from\_documents\(\)是一步到位的高层封装，自动完成建表、建索引、向量化和写入，适合简单场景。如果需要精细控制Schema（如添加BM25函数、自定义分词器），则需要原生pymilvus建表，再用Milvus\(\.\.\.\)封装层挂载。

如下案例中使用 pymilvus 原生方式建库、写入数据，再用 langchain\_milvus 封装层挂载同一个 Collection，接入 LangChain 的 Retriever 体系，最终构建一个 Agentic RAG。

```Plain Text
# 原生 pymilvus 建库写入 + langchain_milvus 封装层挂载检索的 Agentic RAGimport os
from langchain.agents import create_agent
from langchain_community.embeddings import DashScopeEmbeddings
from langchain_core.prompts import PromptTemplate
from langchain_core.tools import create_retriever_tool
from langchain_milvus import Milvus
from pymilvus import DataType, MilvusClient
from init_llm import deepseek_llm_flash


MILVUS_URI = os.getenv("MILVUS_URI", "http://192.168.179.5:19530")
MILVUS_DB_NAME = os.getenv("MILVUS_DB_NAME", "default")
COLLECTION_NAME = "rag_course_native_setup_agent"# ============================================================# 第一步：初始化真实 Embedding 模型（建库和检索共用同一个）# ============================================================
embedding_model = DashScopeEmbeddings(
    model="text-embedding-v1",
    dashscope_api_key=os.environ["DASHSCOPE_API_KEY"],
)


# ============================================================# 第二步：用 pymilvus 原生方式建表 + 建索引 + 写入# ============================================================def build_collection_natively(client: MilvusClient, dimension: int) -> None:"""原生创建Collection，字段名必须与后面挂载封装层时的参数严格一致。"""if client.has_collection(COLLECTION_NAME):
        client.drop_collection(COLLECTION_NAME)

    # 开启动态字段，source 可作为动态字段写入并自动回到 Document.metadata
    schema = client.create_schema(auto_id=True, enable_dynamic_field=True)
    schema.add_field("id", DataType.INT64, is_primary=True, auto_id=True)
    schema.add_field("text", DataType.VARCHAR, max_length=1000)
    schema.add_field("vector", DataType.FLOAT_VECTOR, dim=dimension)

    index_params = client.prepare_index_params()
    index_params.add_index(
        field_name="vector",
        index_type="AUTOINDEX",
        metric_type="COSINE",
    )

    client.create_collection(
        collection_name=COLLECTION_NAME,
        schema=schema,
        index_params=index_params,
    )


def insert_documents(client: MilvusClient) -> None:"""用原生 insert 写入售后规则。"""
    rows = [
        {"text": "退款规则：仓库验收后发起原路退款，通常三个工作日内到账。", "source": "退款规则.md"},
        {"text": "物流规则：订单发货后可以在订单详情查看物流轨迹。", "source": "物流规则.md"},
    ]

    vectors = embedding_model.embed_documents([row["text"] for row in rows])

    client.insert(
        collection_name=COLLECTION_NAME,
        data=[{**row, "vector": vector} for row, vector in zip(rows, vectors)],
    )

    # 刷新 Collection，确保写入生效
    client.flush(COLLECTION_NAME)
    # 加载 Collection，确保索引生效
    client.load_collection(COLLECTION_NAME)


# 原生建库 + 原生写入
milvus_client = MilvusClient(uri=MILVUS_URI, db_name=MILVUS_DB_NAME)
dimension = len(embedding_model.embed_query("测试文本"))
build_collection_natively(milvus_client, dimension)
insert_documents(milvus_client)


# ============================================================# 第三步：用 LangChain 封装层挂载同一个已存在的 Collection# ============================================================
vector_store = Milvus(
    embedding_function=embedding_model, # 用于将查询文本转换为向量
    collection_name=COLLECTION_NAME, # 指定要挂载的集合名
    connection_args={"uri": MILVUS_URI, "db_name": MILVUS_DB_NAME}, # Milvus 连接信息
    auto_id=True, # 主键自动生成
    primary_field="id", # 主键字段名
    text_field="text", # 文本字段名
    vector_field="vector", # 向量字段名
    enable_dynamic_field=True, # 允许动态字段# index_params：告诉 LangChain 本集合用的是哪种度量，用于把原始余弦距离换算成相关性分数
    index_params={"index_type": "AUTOINDEX", "metric_type": "COSINE"},
    # search_params：发给 Milvus 服务端的检索参数，决定用哪种度量做近邻搜索
    search_params={"metric_type": "COSINE", "params": {}}, #检索参数
)


# ============================================================# 第四步：把 Retriever 包装成 Agent 工具# ============================================================
document_prompt = PromptTemplate.from_template("{page_content}\n来源：{source}")

retriever_tool = create_retriever_tool(
    vector_store.as_retriever(search_kwargs={"k": 1}),
    name="retrieve_after_sale_rules",
    description="检索退款到账和物流规则。遇到退款、到账或物流问题必须调用。",
    document_prompt=document_prompt,
)


if __name__ == "__main__":
    # ========================================================# 第五步：使用 create_agent 创建 Agent# ========================================================
    agent = create_agent(
        model=deepseek_llm_flash,
        tools=[retriever_tool],
        system_prompt=("你是电商售后 Agent。涉及退款、到账或物流问题时必须先调用检索工具。只能根据工具结果回答，回答末尾列出来源。"),
    )

    # ========================================================# 第六步：调用 Agent 并观察消息循环# ========================================================
    result = agent.invoke(
        {"messages": [{"role": "user", "content": "退款多久到账？"}]}
    )

    print("result：", result)

    print("\n最终回答：",result["messages"][-1].content)
```

以上代码运行结果如下：

![xd59WyxV\.jpg](图片和附件/xd59WyxV.jpg)

以上代码注意如下几点：

1. 用原生 pymilvus 建表时定义的字段名（id、text、vector），必须与 langchain\_milvus\.Milvus 封装层中 primary\_field、text\_field、vector\_field 参数一一对应。任何不匹配都会导致封装层读取数据失败。

2. enable\_dynamic\_field=True 的作用：Schema 中只定义了 id、text、vector 三个字段，但 source 字段通过动态字段机制写入。封装层也需设置 enable\_dynamic\_field=True，否则无法读取动态字段。

3. 建库时使用的 embedding\_model 与封装层 Milvus 的 embedding\_function 必须是同一个模型。否则查询向量与文档向量不在同一空间，检索结果会失效。

4. 原生 Schema 中 auto\_id=True，封装层中也需要设置 auto\_id=True。否则插入数据时可能因主键生成方式不一致而报错。

5. Milvus\(\.\.\.\) 只是挂载已存在的 Collection，不会重新创建集合或重新生成向量。数据写入需要由原生 client\.insert\(\) 完成。

6. document\_prompt 使用了\{page\_content\}和\{source\}，封装层需要能读取到该字段。\{page\_content\} 对应 Document\.page\_content，source 作为动态字段写入 Milvus，检索时封装层会将其还原到 Document\.metadata\["source"\] 中，document\_prompt 才能正确渲染。

7. 原生建索引时使用 COSINE，封装层 search\_params 中也必须使用 COSINE。否则检索时可能报错或返回不正确的相似度分数。

# LangGraph RAG应用

RAG 的在线流程可以分成三段：检索前、检索、检索后。2\-Step RAG 只覆盖中间一段；Agentic RAG 把“是否检索”也交给模型；而真实业务往往还要处理“检索前要不要改写问题”“检索回来的文档不相关怎么办”“重试几次仍失败怎么办”。这些控制逻辑用固定链或高层 Agent 都很难表达清楚。

LangGraph 的作用是把这三段流程显式拆成节点和条件边，让每一步的输入、输出和跳转条件都能被观察和控制，它不替代检索，也不替代模型，只负责编排。LangGraph 可以用来构建三种 RAG 架构中的任意一种。其中，Hybrid RAG 由于需要精确控制检索、评估、改写和重试等环节，用 LangGraph 编排比手写条件判断更清晰。本章节聚焦于用 LangGraph 实现 Hybrid RAG。

## 4\.1\. 固定检索节点与自适应检索工具

LangGraph 中触发检索有两种方式:固定检索节点和自适应检索工具。固定检索节点是 2\-Step RAG 的典型实现，也可以作为 Hybrid RAG 的检索入口；自适应检索工具对应 Agentic RAG。

固定检索节点把检索写死成图里的一个节点，用户问题进入图后一定先执行检索，再把文档交给生成节点：

```Plain Text
def retrieve_node(state: RAGState) -> dict:
    documents = retriever.invoke(state["question"])
    return {"documents": documents}

builder.add_edge(START, "retrieve")
builder.add_edge("retrieve", "generate")
builder.add_edge("generate", END)
```

这种方式对应 2\-Step RAG，路径确定、延迟可预测、便于缓存，适合问题类型稳定、必须检索的场景。Lang Graph RAG中固定检索节点可以作为Graph图中的一个节点来使用。

自适应检索工具把 Retriever 包装成 Tool，由模型决定是否调用：

```Plain Text
retriever_tool = create_retriever_tool(
    retriever,
    name="retrieve_after_sale_rules",
    description="检索退款到账和物流规则。涉及退款、到账或物流问题时必须调用。",
    document_prompt=PromptTemplate.from_template("{page_content}\n来源：{source}"),
)
```

这种方式对应 Agentic RAG，模型通过 bind\_tools\(\) 获得工具描述，在决策节点中生成或不生成 tool\_calls，再由 ToolNode 执行。它的价值在于模型可以跳过不必要的检索，也可以在多个工具之间选择。

需要明确的是，ToolNode 是一个通用的工具执行节点。它读取 messages 最后一条 AIMessage 中的 tool\_calls，执行对应工具，把结果写成 ToolMessage 追加回消息列表，当工具是 Retriever Tool 时，ToolNode 就承担了检索执行的职责。

固定检索节点和自适应检索工具各有适用场景。如果问题类型稳定、必须检索，固定检索节点更简单可控；如果问题类型多样、需要模型自主决策，自适应检索工具更灵活，选择哪种方式取决于业务需求。

## 4\.2\. 检索前查询处理

检索前的处理都发生在用户问题进入检索器之前，目的是让检索查询更接近知识库的表达方式。这些技术在前面章节中已经讲过原理，这里只说明它们在Graph图中的位置和边界。

### 4\.2\.1\. 查询改写节点

查询改写节点把口语化或含糊的问题改写成明确的检索查询，写入 State 的是普通字符串：

```Plain Text
def rewrite_node(state: RAGState) -> dict:
    response = deepseek_llm_flash.invoke(
        "把下面的售后问题改写成适合检索知识库的一行查询，只输出查询。\n"
        f"原始问题：{state['question']}"
    )
    return {"retrieval_query": response.content.strip()}
```

改写节点只改变“检索什么”，不执行检索。原始问题要单独保留，最终回答仍然面向用户原始问题。

### 4\.2\.2\. Multi\-Query与查询分解

Multi\-Query 生成同一意图的多个查询变体，查询分解把复杂问题拆成若干子问题。两者在Graph图中都是独立节点，输出查询列表，由后续检索节点逐条检索并合并结果。合并去重逻辑要显式写回 State，不要依赖隐式行为。

### 4\.2\.3\. Routing

Routing 先用模型或规则判断问题类型，再路由到对应的知识库或检索策略。路由函数只返回路由字符串，真正的分支由 conditional edge 完成：

```Plain Text
builder.add_conditional_edges(
    "route_question",
    route_question,
    {"product": "retrieve_product", "after_sale": "retrieve_after_sale"},
)
```

## 4\.3\. 检索执行

### 4\.3\.1\. Milvus检索节点

检索节点内部调用什么向量库与 LangGraph 无关。本章统一使用 Milvus，因为它同时支持元数据过滤、混合检索和多向量能力。最常见的是使用 langchain\_milvus\.Milvus，它内部持有 pymilvus\.MilvusClient，对上层提供标准的 VectorStore 和 Retriever 接口；需要 BM25、RRF 等原生能力时，直接使用 pymilvus\.MilvusClient。

检索节点的写法和普通函数一致，只是把向量库换成 Milvus：

```Plain Text
def retrieve_node(state: RAGState) -> dict:
    documents = vector_store.similarity_search(state["retrieval_query"], k=2)
    return {"documents": documents}
```

### 4\.3\.2\. 混合检索节点

Hybrid Search 把关键词检索和向量检索结合起来，解决语义相近但用词不同、以及型号编号精确匹配两类需求。在 LangGraph 中，把它封装成检索节点，内部使用 Milvus 原生 API：

```Plain Text
def hybrid_retrieve_node(state: RAGState) -> dict:
    dense_request = AnnSearchRequest(
        data=[embedding_model.embed_query(state["retrieval_query"])],
        anns_field="dense_vector",
        param={"metric_type": "COSINE", "params": {}},
        limit=5,
    )
    sparse_request = AnnSearchRequest(
        data=[state["retrieval_query"]],
        anns_field="sparse_vector",
        param={"metric_type": "BM25", "params": {}},
        limit=5,
    )
    hits = client.hybrid_search(
        collection_name=COLLECTION_NAME,
        reqs=[dense_request, sparse_request],
        ranker=RRFRanker(k=60),
        limit=5,
        output_fields=["doc_id", "text"],
    )[0]
    return {"documents": [Document(hit["entity"]["text"]) for hit in hits]}
```

### 4\.3\.3\. Reranker精排节点

混合检索负责扩大召回，Reranker 负责对少量候选重新精排。它属于召回后、生成前的处理，在图里是一个独立节点：

```Plain Text
def rerank_node(state: RAGState) -> dict:
    reranked = reranker.compress_documents(state["documents"], state["question"])
    return {"documents": reranked}
```

如果候选来自 ToolNode，需要先解析 ToolMessage\.content 才能精排；如果来自固定检索节点，候选已经在 documents 字段中，可以直接使用。

## 4\.4\. 检索后评估与自纠错

### 4\.4\.1\. 文档相关性评估

检索回来的文档不一定能回答问题。评估节点用真实模型判断文档与问题的相关性，输出稳定的布尔字段：

```Plain Text
def grade_node(state: RAGState) -> dict:
    context = "\n\n".join(
        f"{document.page_content}\n来源：{document.metadata.get('source', '')}"for document in state["documents"]
    )
    response = deepseek_llm_flash.invoke(
        "判断检索资料能否回答用户问题，只输出 YES 或 NO。\n"
        f"用户问题：{state['question']}\n检索资料：\n{context}"
    )
    result = response.content.strip().upper()
    return {"relevant": result.startswith("YES") or result.startswith("是")}
```

评估节点只做判断，不执行路由。路由由后续 conditional edge 根据 relevant 字段完成。

### 4\.4\.2\. 查询改写与重试

文档不相关时，改写节点重新生成检索查询，再回到检索节点。为了让重试次数可控，通常单独设置一个计数节点，或者在改写节点中累加 attempts：

```Plain Text
def rewrite_node(state: RAGState) -> dict:
    response = deepseek_llm_flash.invoke(
        "把下面的问题改写成适合检索知识库的一行查询，只输出查询。\n"
        f"原始问题：{state['question']}"
    )
    return {
        "retrieval_query": response.content.strip(),
        "attempts": state.get("attempts", 0) + 1,
    }
```

改写后必须回到检索节点重新执行检索，再由评估节点重新判断。不要让改写节点直接生成答案，也不要手工伪造工具调用。

### 4\.4\.3\. 循环控制与fallback

自纠错循环必须设置上限，路由函数同时判断相关性和重试次数：

```Plain Text
def route_after_grade(state: RAGState) -> str:
    if state.get("relevant"):
        return "generate"if state.get("attempts", 0) < 1:
        return "rewrite"return "fallback"
```

超过上限后进入独立的 fallback 节点，返回“资料不足”、要求补充产品型号或订单号、转人工客服，或路由到其他数据源。把失败路径写成独立节点，而不是在生成节点内部用 if 判断，可以让执行轨迹和状态快照保持一致。

## 4\.5\. 自适应检索的自纠错 RAG案例

下面的案例采用“模型决定检索 \+ ToolNode 执行 \+ 评估 \+ 改写重试 \+ fallback”的完整控制流，检索后端使用 Milvus。该案例LangGraph RAG 拓扑图如下：

![8kk3PKGz\.jpg](图片和附件/8kk3PKGz.jpg)

代码实现如下：

```Plain Text
import osfrom typing import Annotated, TypedDictfrom env_utils import DASHSCOPE_API_KEYfrom langchain_community.embeddings import DashScopeEmbeddingsfrom langchain_core.documents import Documentfrom langchain_core.messages import AIMessage, AnyMessage, HumanMessage, SystemMessage, ToolMessagefrom langchain_core.prompts import PromptTemplatefrom langchain_core.tools import create_retriever_toolfrom langchain_milvus import Milvusfrom langgraph.graph import END, START, StateGraphfrom langgraph.graph.message import add_messagesfrom langgraph.prebuilt import ToolNodefrom init_llm import deepseek_llm_flashMILVUS_URI = os.getenv("MILVUS_URI", "http://192.168.179.5:19530")
MILVUS_DB_NAME = os.getenv("MILVUS_DB_NAME", "default")
COLLECTION_NAME = "rag_course_self_correcting"embedding_model = DashScopeEmbeddings(
    model="text-embedding-v1",
    dashscope_api_key=DASHSCOPE_API_KEY,
)

vector_store = Milvus.from_documents(
    [
        Document("AB-120 耳机退货规则：收货后七日内可以申请无理由退货，需要保持商品和包装完整。", metadata={"source": "耳机退货.md"}),
        Document("AB-120 耳机退款规则：仓库验收退回商品后发起原路退款，通常三个工作日内到账。", metadata={"source": "耳机退款.md"}),
        Document("AB-120 蓝牙连接说明：长按功能键三秒进入配对模式。", metadata={"source": "耳机连接.md"}),
    ],
    embedding_model,
    collection_name=COLLECTION_NAME, # Milvus 集合名称
    connection_args={"uri": MILVUS_URI, "db_name": MILVUS_DB_NAME}, # 连接参数
    drop_old=True, # 每次运行是否删除旧集合
    auto_id=True, # 是否自动分配 IDindex_params={"index_type": "AUTOINDEX", "metric_type": "COSINE", "params": {}}, # 索引参数
    search_params={"metric_type": "COSINE", "params": {}}, # 搜索参数
)

# 构建检索工具
retriever_tool = create_retriever_tool(
    vector_store.as_retriever(search_kwargs={"k": 2}),
    name="retrieve_ab120_docs",
    description="检索 AB-120 耳机的退货、退款和连接说明。检索 AB-120 耳机的退货、退款和连接说明。无需改写任何参数，直接调用就可以",
    document_prompt=PromptTemplate.from_template("{page_content}\n来源：{source}"),
)

# 绑定工具到模型
model_with_tools = deepseek_llm_flash.bind_tools([retriever_tool])


class State(TypedDict, total=False):
    messages: Annotated[list[AnyMessage], add_messages] # 与模型交互的消息列表
    question: str # 用户原始问题
    relevant: bool # 检索资料是否相关
    attempts: int # 已尝试次数
    trace: list[str] # 调试用的执行轨迹

def call_model(state: State) -> dict:
    prompt = f"你是 AB-120 耳机售后助手。涉及退货、退款、到账、连接问题时必须调用检索工具。用户原始问题：{state['question']}"response = model_with_tools.invoke([SystemMessage(content=prompt), *state["messages"]])
    return {"messages": [response],
            "trace": [*state.get("trace", []), f"call_model(tool_calls={len(response.tool_calls or [])})"]}

def route_after_model(state: State) -> str:
    last = state["messages"][-1]
    if isinstance(last, AIMessage) and last.tool_calls:
        return "tools"return "end"

# 判断检索资料是否相关
def grade_documents(state: State) -> dict:
    tool_messages = [m for m in state["messages"] if isinstance(m, ToolMessage)]
    context = tool_messages[-1].content if tool_messages else "没有检索结果。"response = deepseek_llm_flash.invoke(
        "判断检索资料能否回答用户问题，只输出 YES 或 NO。\n"f"用户问题：{state['question']}\n检索资料：\n{context}"
    )
    result = response.content.strip().upper()
    relevant = result.startswith("YES")
    return {"relevant": relevant, "trace": [*state.get("trace", []), f"grade_documents({result})"]}

def route_after_grade(state: State) -> str:
    if state.get("relevant"):
        return "answer"if state.get("attempts", 0) < 1:
        return "rewrite_and_retrieve"return "fallback"def rewrite_and_retrieve(state: State) -> dict:
    response = deepseek_llm_flash.invoke(
        "把下面的售后问题改写成更适合检索 AB-120 耳机知识库的一行查询，只输出查询。\n"f"原始问题：{state['question']}"
    )
    query = response.content.strip().replace("\n", " ")
    docs = vector_store.similarity_search(query, k=2)
    context = "\n".join(f"{d.page_content}\n来源：{d.metadata['source']}" for d in docs)
    return {"messages": [ToolMessage(content=context, tool_call_id="rewrite-retrieval")],
            "attempts": state.get("attempts", 0) + 1,
            "trace": [*state.get("trace", []), f"rewrite_and_retrieve({query})"]}

def answer(state: State) -> dict:
    tool_messages = [m for m in state["messages"] if isinstance(m, ToolMessage)]
    context = tool_messages[-1].content if tool_messages else "没有资料。"response = deepseek_llm_flash.invoke(
        "你是售后助手。只根据资料回答，保留时间限定，回答末尾列出来源。\n"f"用户问题：{state['question']}\n资料：\n{context}"
    )
    return {"messages": [response], "trace": [*state.get("trace", []), "answer"]}

def fallback(state: State) -> dict:
    return {"messages": [AIMessage(content="资料不足，请转人工客服。")],
            "trace": [*state.get("trace", []), "fallback"]}

if __name__ == "__main__":
    builder = StateGraph(State)
    builder.add_node("call_model", call_model)
    builder.add_node("tools", ToolNode([retriever_tool]))
    builder.add_node("grade_documents", grade_documents)
    builder.add_node("rewrite_and_retrieve", rewrite_and_retrieve)
    builder.add_node("answer", answer)
    builder.add_node("fallback", fallback)

    builder.add_edge(START, "call_model")
    builder.add_conditional_edges("call_model", route_after_model, {"tools": "tools", "end": END})
    builder.add_edge("tools", "grade_documents")
    builder.add_conditional_edges("grade_documents", route_after_grade,
                                  {"answer": "answer", "rewrite_and_retrieve": "rewrite_and_retrieve", "fallback": "fallback"})
    builder.add_edge("rewrite_and_retrieve", "grade_documents")
    builder.add_edge("answer", END)
    builder.add_edge("fallback", END)
    graph = builder.compile()

    question = "耳机坏了想退，钱什么时候回来？"result = graph.invoke({"messages": [HumanMessage(content=question)], "question": question,"attempts": 0, "trace": []})

    print("用户问题：", question)
    print("执行轨迹：")
    for item in result["trace"]:
        print("-", item)
    print("\n最终回答：",result["messages"][-1].content)
```

以上代码运行结果如下：

![qY4RZkxJ\.jpg](图片和附件/qY4RZkxJ.jpg)

以上代码需要注意：如果检索由 ToolNode 执行，评估节点应从最新 ToolMessage\.content 读取资料

## 4\.6\. 固定检索节点的自纠错 RAG案例

下面把检索前改写、固定检索、相关性评估、改写重试和失败兜底组合成一条完整流程。检索后端使用 Milvus，所有模型调用、检索和失败处理都在图内执行。案例的拓扑图如下：

![OHDFuBQF\.jpg](图片和附件/OHDFuBQF.jpg)

代码实现：

```Plain Text
import os
from typing import TypedDict

from env_utils import DASHSCOPE_API_KEY
from langchain_community.embeddings import DashScopeEmbeddings
from langchain_core.documents import Document
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_milvus import Milvus
from langgraph.graph import END, START, StateGraph
from init_llm import deepseek_llm_flash

MILVUS_URI = os.getenv("MILVUS_URI", "http://192.168.179.5:19530")
MILVUS_DB_NAME = os.getenv("MILVUS_DB_NAME", "default")
COLLECTION_NAME = "rag_course_self_correcting"

embedding_model = DashScopeEmbeddings(
    model="text-embedding-v1",
    dashscope_api_key=DASHSCOPE_API_KEY,
)

vector_store = Milvus.from_documents(
    [
        Document("AB-120 耳机退货规则：收货后七日内可以申请无理由退货，需要保持商品和包装完整。", metadata={"source": "耳机退货.md"}),
        Document("AB-120 耳机退款规则：仓库验收退回商品后发起原路退款，通常三个工作日内到账。", metadata={"source": "耳机退款.md"}),
        Document("AB-120 蓝牙连接说明：长按功能键三秒进入配对模式。", metadata={"source": "耳机连接.md"}),
    ],
    embedding_model,
    collection_name=COLLECTION_NAME,
    connection_args={"uri": MILVUS_URI, "db_name": MILVUS_DB_NAME},
    drop_old=True, # 每次运行删除旧集合
    auto_id=True, # 自动生成 ID
    index_params={"index_type": "AUTOINDEX", "metric_type": "COSINE", "params": {}}, # 自动索引，使用余弦相似度
    search_params={"metric_type": "COSINE", "params": {}}, # 搜索参数，使用余弦相似度
)


class RAGState(TypedDict, total=False):
    question: str # 用户问题
    retrieval_query: str # 检索查询
    documents: list[Document] # 检索到的文档
    relevant: bool # 检索资料是否能回答问题
    attempts: int # 尝试次数
    answer: str # 回答
    trace: list[str] # 跟踪记录def rewrite_node(state: RAGState) -> dict:"""把口语化问题改写成适合检索的一行查询。"""
    response = deepseek_llm_flash.invoke(
        "把下面的售后问题改写成适合检索耳机知识库的一行查询，只输出查询。\n"f"原始问题：{state['question']}"
    )
    query = response.content.strip().replace("\n", " ")
    return {"retrieval_query": query, "trace": [*state.get("trace", []), f"rewrite_node({query})"]}

# 构建 MMR 检索器
retriever = vector_store.as_retriever(
    search_type="mmr",
    search_kwargs={"k": 2, "fetch_k": 5}, # 召回5个候选文档，最终返回2个最相关的文档
)

def retrieve_node(state: RAGState) -> dict:"""使用 Milvus 执行一次真实向量检索。"""
    documents = retriever.invoke(state["retrieval_query"])
    return {"documents": documents, "trace": [*state.get("trace", []), f"retrieve_node(k={len(documents)})"]}


def grade_node(state: RAGState) -> dict:"""用真实模型判断检索资料是否能回答问题。"""
    context = "\n\n".join(
        f"{document.page_content}\n来源：{document.metadata.get('source', '')}"for document in state["documents"]
    )

    response = deepseek_llm_flash.invoke(
        "判断检索资料能否回答用户问题，只输出 YES 或 NO。\n"f"用户问题：{state['question']}\n检索资料：\n{context}"
    )

    result = response.content.strip().upper()
    relevant = result.startswith("YES")
    return {"relevant": relevant, "trace": [*state.get("trace", []), f"grade_node({result})"]}


def route_after_grade(state: RAGState) -> str:if state.get("relevant"):
        return "generate_node"# 尝试次数小于1次，重写查询，最多重试1次if state.get("attempts", 0) < 1:
        return "rewrite_node"return "fallback_node"def increment_attempts(state: RAGState) -> dict:"""进入重试前累加重试次数，避免无限循环。"""return {"attempts": state.get("attempts", 0) + 1}


def generate_node(state: RAGState) -> dict:"""根据检索文档调用真实模型生成回答。"""
    context = "\n\n".join(
        f"来源：{document.metadata.get('source', '')}\n{document.page_content}"for document in state["documents"]
    )
    response = deepseek_llm_flash.invoke(
        [
            SystemMessage(content="你是售后助手，只能根据参考资料回答，回答末尾列出来源。"),
            HumanMessage(content=f"参考资料：\n{context}\n\n用户问题：{state['question']}"),
        ]
    )
    return {"answer": response.content, "trace": [*state.get("trace", []), "generate_node"]}


def fallback_node(state: RAGState) -> dict:"""重试超过上限后的失败兜底。"""return {"answer": "资料不足，请转人工客服。", "trace": [*state.get("trace", []), "fallback_node"]}


if __name__ == "__main__":
    builder = StateGraph(RAGState)
    builder.add_node("rewrite_node", rewrite_node)
    builder.add_node("retrieve_node", retrieve_node)
    builder.add_node("grade_node", grade_node)
    builder.add_node("increase_attempts", increment_attempts)
    builder.add_node("generate_node", generate_node)
    builder.add_node("fallback_node", fallback_node)

    builder.add_edge(START, "rewrite_node")
    builder.add_edge("rewrite_node", "retrieve_node")
    builder.add_edge("retrieve_node", "grade_node")
    builder.add_conditional_edges(
        "grade_node",
        route_after_grade,
        {"generate_node": "generate_node", "rewrite_node": "increase_attempts", "fallback_node": "fallback_node"},
    )
    builder.add_edge("increase_attempts", "rewrite_node")
    builder.add_edge("generate_node", END)
    builder.add_edge("fallback_node", END)
    graph = builder.compile()

    question = "耳机坏了想退，钱什么时候回来？"

    result = graph.invoke({"question": question, "attempts": 0, "trace": []})

    print("用户问题：", question)
    print("执行轨迹：")
    for item in result["trace"]:
        print("-", item)
    print("\n最终回答：",result["answer"])
```

以上代码运行结果如下：

![1f1ec0Gn\.jpg](图片和附件/1f1ec0Gn.jpg)

代码注意点：

1. rewrite\_node 只负责改写查询，retrieve\_node 只负责检索，grade\_node 只负责评估，generate\_node 只负责生成，每个节点职责单一。

2. 路由函数 route\_after\_grade 只读取 relevant 和 attempts，不执行模型调用或检索，真正的跳转由 conditional edge 完成。

3. 重试次数在进入改写前累加，达到上限后进入 fallback，不会无限循环。

4. 固定检索节点把文档写入 State 的 documents 字段，后续评估和生成节点直接读取该字段，不需要解析 ToolMessage。

## 4\.7\. 综合案例

该综合案例在LangGraph中综合使用之前学习的技术点，构建Milvus 混合检索 \+ 查询改写分解 \+ 精排 \+ 自纠错的 LangGraph RAG。

该案例模拟电商售后场景，知识库同时包含 AB\-120 耳机专属规则和通用规则（物流、发票）。用户问题为“AB\-120 耳机退回去之后，钱多久能到账？”，完整流程如下：

1. 使用原生 pymilvus 建表，定义稠密向量字段、BM25 稀疏向量字段和动态字段，写入 5 条售后规则，其中 product 字段用于文档过滤。

2. 使用 langchain\_milvus\.Milvus 挂载同一个 Collection，使 LangChain 封装层能够读取原生写入的数据。

3. rewrite\_and\_decompose 节点用真实模型把口语化问题改写并拆成两条子查询。

4. hybrid\_retrieve 节点对每条子查询分别执行向量检索和 BM25 检索，用 RRF 融合，并加上 product == "AB\-120" 的过滤条件。

5. rerank 节点用 DashScope Reranker 对候选文档重新精排。

6. grade 节点用真实模型判断精排后的文档是否能回答问题。

7. 文档相关则 generate 生成回答；不相关则改写后重试；达到上限则进入 fallback。

总体拓扑图如下：

![l84Rmw31\.jpg](图片和附件/l84Rmw31.jpg)

代码实现：

```Plain Text
import osfrom typing import TypedDictfrom pydantic import BaseModel, Fieldimport dashscopefrom langchain_community.document_compressors import DashScopeRerankfrom langchain_community.embeddings import DashScopeEmbeddingsfrom langchain_core.documents import Documentfrom langchain_core.messages import HumanMessage, SystemMessagefrom langchain_milvus import Milvusfrom langgraph.graph import END, START, StateGraphfrom pymilvus import AnnSearchRequest, DataType, Function, FunctionType, MilvusClient, RRFRankerfrom init_llm import deepseek_llm_flash

# ============================================================
# 第一步：读取配置并加载真实模型
# ============================================================MILVUS_URI = os.getenv("MILVUS_URI", "http://192.168.179.5:19530")
MILVUS_DB_NAME = os.getenv("MILVUS_DB_NAME", "default")
COLLECTION_NAME = "rag_course_comprehensive"DASHSCOPE_API_KEY = os.environ["DASHSCOPE_API_KEY"]

embedding_model = DashScopeEmbeddings(
    model="text-embedding-v1",
    dashscope_api_key=DASHSCOPE_API_KEY,
)


# ============================================================
# 第二步：使用原生 pymilvus 建表并写入数据
# ============================================================DOCUMENTS = [
    {"doc_id": "refund-rule", "text": "AB-120 耳机退款规则：仓库验收退回商品后发起原路退款，通常三个工作日内到账。", "product": "AB-120", "category": "退款"},
    {"doc_id": "return-rule", "text": "AB-120 耳机退货规则：收货后七日内可以申请无理由退货，需要保持商品和包装完整。", "product": "AB-120", "category": "退货"},
    {"doc_id": "connect-guide", "text": "AB-120 蓝牙连接说明：长按功能键三秒进入配对模式，指示灯闪烁表示可被搜索。", "product": "AB-120", "category": "连接"},
    {"doc_id": "logistics-rule", "text": "物流规则：订单发货后可以在订单详情查看物流轨迹，超过四十八小时未更新联系客服。", "product": "通用", "category": "物流"},
    {"doc_id": "invoice-rule", "text": "发票规则：订单完成后可以在订单详情申请电子发票，通常一个工作日内开具。", "product": "通用", "category": "发票"},
]


def build_collection_natively() -> MilvusClient:
    """使用原生 pymilvus 创建同时包含稠密向量和 BM25 稀疏向量的 Collection，并写入数据。"""client = MilvusClient(uri=MILVUS_URI, db_name=MILVUS_DB_NAME)

    if client.has_collection(COLLECTION_NAME):
        client.drop_collection(COLLECTION_NAME)

    # 开启动态字段，product、category、doc_id 等作为动态字段写入
    schema = client.create_schema(auto_id=True, enable_dynamic_field=True)
    schema.add_field("id", DataType.INT64, is_primary=True, auto_id=True)
    schema.add_field(
        "text",
        DataType.VARCHAR,
        max_length=1000,
        enable_analyzer=True,
        analyzer_params={"tokenizer": "jieba"},
        enable_match=True,
    )
    schema.add_field("dense_vector", DataType.FLOAT_VECTOR, dim=1536)
    schema.add_field("sparse_vector", DataType.SPARSE_FLOAT_VECTOR)
    schema.add_function(
        Function(
            name="bm25_function",
            function_type=FunctionType.BM25,
            input_field_names=["text"],
            output_field_names=["sparse_vector"],
        )
    )

    index_params = client.prepare_index_params()
    index_params.add_index(field_name="dense_vector", index_type="AUTOINDEX", metric_type="COSINE")
    index_params.add_index(field_name="sparse_vector", index_type="SPARSE_INVERTED_INDEX", metric_type="BM25")
    client.create_collection(collection_name=COLLECTION_NAME, schema=schema, index_params=index_params)

    # 将数据转换成稠密向量
    dense_vectors = embedding_model.embed_documents([document["text"] for document in DOCUMENTS])
    # 写入数据
    client.insert(
        collection_name=COLLECTION_NAME,
        data=[{**document, "dense_vector": vector} for document, vector in zip(DOCUMENTS, dense_vectors)],
    )
    # 刷新 Collection，确保写入生效
    client.flush(COLLECTION_NAME)
    # 加载 Collection，确保索引生效
    client.load_collection(COLLECTION_NAME)
    return client

# 创建 Collection 并写入数据
client = build_collection_natively()


# ============================================================
# 第三步：使用 langchain_milvus 封装层挂载同一个 Collection
# ============================================================vector_store = Milvus(
    embedding_function=embedding_model,
    collection_name=COLLECTION_NAME,
    connection_args={"uri": MILVUS_URI, "db_name": MILVUS_DB_NAME},
    auto_id=True,
    primary_field="id",
    text_field="text",
    vector_field="dense_vector",
    enable_dynamic_field=True,
    search_params={"metric_type": "COSINE", "params": {}},
)


# ============================================================
# 第四步：初始化 Reranker
# ============================================================reranker = DashScopeRerank(
    client=dashscope.TextReRank,
    model="gte-rerank-v2",
    top_n=3,
    api_key=DASHSCOPE_API_KEY,
)


# ============================================================
# 第五步：定义图状态
# ============================================================class RAGState(TypedDict, total=False):
    question: str          # 用户原始问题
    product: str           # 文档过滤使用的产品标识
    queries: list[str]     # 改写和分解后的检索查询
    candidates: list[Document]  # 混合检索召回候选
    documents: list[Document]   # 精排后的文档
    relevant: bool         # 文档是否相关
    attempts: int          # 重试次数
    answer: str            # 最终回答
    trace: list[str]       # 执行轨迹


# ============================================================
# 第六步：定义查询改写与分解节点
# ============================================================
# 定义结构化输出模型：把查询条数和每条查询的类型固定下来
class RetrievalQueries(BaseModel):
    """改写和分解后的检索查询。"""queries: list[str] = Field(description="1到2条适合检索知识库的查询，每条是完整自然语言短句",min_length=1,max_length=2)


# 把模型包装成“必须输出 RetrievalQueries”的 Runnablestructured_model = deepseek_llm_flash.with_structured_output(RetrievalQueries)


def rewrite_and_decompose(state: RAGState) -> dict:
    """把口语化问题改写并拆成最多两条子查询。"""result = structured_model.invoke(
        "把用户问题改写成适合检索耳机知识库的查询，并拆成最多2条子查询，保留型号等关键信息。\n"f"用户问题：{state['question']}"
    )
    return {
        "queries": result.queries,
        "trace": [*state.get("trace", []), f"rewrite_and_decompose({result.queries})"],
    }

# ============================================================
# 第七步：定义混合检索节点
# ============================================================def hybrid_retrieve(state: RAGState) -> dict:
    """对每条子查询执行向量与 BM25 混合检索，使用 RRF 融合并做产品过滤。"""expr = f'product == "{state["product"]}"'merged: list[Document] = []
    seen: set[int] = set()          # 用 Milvus 主键 id 去重

    for query in state["queries"]:
        dense_request = AnnSearchRequest(
            data=[embedding_model.embed_query(query)],
            anns_field="dense_vector",
            param={"metric_type": "COSINE", "params": {}},
            limit=5,
        )
        sparse_request = AnnSearchRequest(
            data=[query],
            anns_field="sparse_vector",
            param={"metric_type": "BM25", "params": {}},
            limit=5,
        )
        hits = client.hybrid_search(
            collection_name=COLLECTION_NAME,
            reqs=[dense_request, sparse_request],
            ranker=RRFRanker(k=60),
            limit=5,
            filter=expr,
            output_fields=["doc_id", "chunk_index", "text", "product", "category"],
        )[0]

        for hit in hits:
            entity = hit["entity"]
            # hit["id"] 是 Milvus 主键，行级唯一
            if hit["id"] in seen:
                continueseen.add(hit["id"])
            merged.append(
                Document(
                    page_content=entity["text"],
                    metadata={
                        "chunk_pk": hit["id"],
                        "doc_id": entity["doc_id"],
                        "source": f"{entity['doc_id']}.md",
                        "product": entity["product"],
                        "category": entity["category"],
                    },
                )
            )

    return {
        "candidates": merged,
        "trace": [*state.get("trace", []), f"hybrid_retrieve(filter={expr}, candidates={len(merged)})"],
    }


# ============================================================
# 第八步：定义 Reranker 精排节点
# ============================================================def rerank(state: RAGState) -> dict:
    """对混合检索候选执行 Reranker 精排。"""
    # 返回的 ranked 是一个list[Document]列表，每个元素是一个文档对象，包含文档内容和元数据
    ranked = reranker.compress_documents(state["candidates"], state["question"])
    return {
        "documents": ranked,
        "trace": [*state.get("trace", []), f"rerank(top={len(ranked)})"],
    }


# ============================================================
# 第九步：定义检索评估节点
# ============================================================def grade(state: RAGState) -> dict:
    """用真实模型判断精排后的文档能否回答问题。"""context = "\n".join(document.page_content for document in state["documents"])
    response = deepseek_llm_flash.invoke(
        "判断检索资料能否回答用户问题，只输出 YES 或 NO。\n"f"用户问题：{state['question']}\n检索资料：\n{context}"
    )
    result = response.content.strip().upper()
    relevant = result.startswith("YES") or result.startswith("是")
    return {
        "relevant": relevant,
        "trace": [*state.get("trace", []), f"grade({result})"],
    }


def route_after_grade(state: RAGState) -> str:
    if state.get("relevant"):
        return "generate"if state.get("attempts", 0) < 1:
        return "retry_rewrite"return "fallback"


# ============================================================
# 第十步：定义重试改写节点
# ============================================================def retry_rewrite(state: RAGState) -> dict:
    """评估不相关时，改写查询后重新检索。"""response = deepseek_llm_flash.invoke(
        "上一次检索没有找到相关资料。请把用户问题改写成更贴近知识库用词的一条查询，只输出查询。\n"f"用户问题：{state['question']}"
    )
    query = response.content.strip().replace("\n", " ")
    return {
        "queries": [query],
        "attempts": state.get("attempts", 0) + 1,
        "trace": [*state.get("trace", []), f"retry_rewrite({query})"],
    }


# ============================================================
# 第十一步：定义生成与兜底节点
# ============================================================def generate(state: RAGState) -> dict:
    """根据精排后的文档生成最终回答。"""context = "\n\n".join(
        f"来源：{document.metadata.get('source', '')}\n{document.page_content}"for document in state["documents"]
    )
    response = deepseek_llm_flash.invoke(
        [
            SystemMessage(content="你是电商售后助手。只根据参考资料回答，保留时间与条件限定，回答末尾列出来源。"),
            HumanMessage(content=f"参考资料：\n{context}\n\n用户问题：{state['question']}"),
        ]
    )
    return {"answer": response.content, "trace": [*state.get("trace", []), "generate"]}


def fallback(state: RAGState) -> dict:
    """重试超过上限后的失败兜底。"""return {
        "answer": "多次检索后仍没有足够可靠的资料，请补充订单信息或转人工客服。",
        "trace": [*state.get("trace", []), "fallback"],
    }


# ============================================================
# 第十二步：组装并运行 LangGraph
# ============================================================if __name__ == "__main__":
    builder = StateGraph(RAGState)
    builder.add_node("rewrite_and_decompose", rewrite_and_decompose)
    builder.add_node("hybrid_retrieve", hybrid_retrieve)
    builder.add_node("rerank", rerank)
    builder.add_node("grade", grade)
    builder.add_node("retry_rewrite", retry_rewrite)
    builder.add_node("generate", generate)
    builder.add_node("fallback", fallback)

    builder.add_edge(START, "rewrite_and_decompose")
    builder.add_edge("rewrite_and_decompose", "hybrid_retrieve")
    builder.add_edge("hybrid_retrieve", "rerank")
    builder.add_edge("rerank", "grade")
    builder.add_conditional_edges(
        "grade",
        route_after_grade,
        {"generate": "generate", "retry_rewrite": "retry_rewrite", "fallback": "fallback"},
    )
    builder.add_edge("retry_rewrite", "hybrid_retrieve")
    builder.add_edge("generate", END)
    builder.add_edge("fallback", END)
    graph = builder.compile()


    question = "AB-120 耳机退回去之后，钱多久能到账？"result = graph.invoke(
        {"question": question, "product": "AB-120", "attempts": 0, "trace": []}
    )

    print("用户问题：", question)
    print("执行轨迹：")
    for item in result["trace"]:
        print("-", item)
    print("\n最终回答：",result["answer"])
```

以上代码运行结果如下：

![LyAiO3lQ\.jpg](图片和附件/LyAiO3lQ.jpg)

代码注意问题如下：

1. enable\_dynamic\_field=True 两边都要开。 doc\_id、product、category 是通过动态字段写入的，封装层也设置 enable\_dynamic\_field=True，检索时才能还原到 Document\.metadata。

2. 混合检索的过滤条件必须与索引能力匹配。 本案例用 product == "AB\-120" 过滤，通用规则（product == "通用"）不会进入候选集，这是“文档过滤”的实现位置。

3. Reranker 在混合检索之后执行。 先由混合检索扩大召回，再由 Reranker 对候选重新精排，两个阶段职责不同，顺序不能颠倒。

4. 查询改写与查询分解在同一个节点内完成。 改写负责换一种表达，分解负责拆成多条子查询，两者都只输出查询字符串，不执行检索。

5. 评估节点读取的是 documents 字段。 因为本案例使用固定检索节点，文档已经显式写入 State，不需要解析 ToolMessage。

6. 循环必须有上限。 attempts 达到上限后进入 fallback，避免“改写 → 检索 → 评估 → 改写”无限循环。

7. Reranker 与 Embedding 的调用都会产生外部请求。 真实项目中要关注 QPS、超时和成本，必要时增加缓存和降级策略。

# RAG评估

## 5\.1\. RAG评估介绍

### 5\.1\.1\. 什么是RAG评估

RAG 评估就是用一套可以重复执行的方法，回答下面三个问题：

1. 这个 RAG 系统现在到底好不好？

2. 如果不好，是检索错了、排序错了、上下文错了，还是模型生成错了？

3. 改完之后，它有没有真的变好，而不是只在某一条问题上碰巧变好？

评估不是“我看了一条回答，感觉还可以”，也不是“模型回答得很流畅，所以应该没问题”。流畅只能说明语言自然，不能说明资料找对了、事实正确、引用可信、权限安全。

假设用户问：“退款通常多久到账？”，系统回答“保证三天内到账。”，这句话看起来很像正确答案，但有可能是错误的，原因至少可能来自五种不同的问题：

1. 知识库里根本没有退款规则，模型凭参数记忆编了一个答案。

2. 知识库有退款规则，但检索器没有召回。

3. 检索器召回了一份无关文档，模型照着无关文档回答。

4. 正确文档被召回了，但排在第三位，而程序只把前一条交给模型。

5. 正确文档和“通常三个工作日、具体以支付渠道为准”都进了上下文，但模型把“通常”改成了“保证”。

以上这五种不同的问题如何定位，这就需要进行RAG的评估，如果没有评估，只能靠猜。评估的作用就是把“答案不好”拆成可以定位的环节。

RAG 评估的对象也不是单独一个模型，而是一条完整链路，链路上任何一环出问题，最终答案都可能出错，所以评估必须分层进行。

```Plain Text
用户问题
  → 查询改写
  → 检索
  → 过滤/重排
  → 组装上下文
  → 模型生成
  → 引用与输出
  → 工具调用、权限、延迟、成本
```

### 5\.1\.2\. RAG评估的目标

评估目标不是“给系统打一个大分”，而是根据当前阶段选择要回答的问题。RAG评估常见目标有：

同一套数据可以服务多个目标，但不同目标关注的指标不同。例如优化召回时先看 Hit@K 和 Recall@K；降低幻觉时先看 Faithfulness 和引用正确性；控制生产风险时先看权限、拒答和错误率。

### 5\.1\.3\. 评估数据集和评估样本

评估数据集不是知识库本身，也不是用户线上日志的简单堆积。它是一组经过整理的评估样本，用来反复测试系统。

一条最小的评估样本通常包含：

- 一个用户问题；

- 这个问题的参考答案；

- 回答这个问题需要的参考证据；

- 这条样本是否在知识库范围内；

- 产品、版本、租户、问题类型等元数据。

系统运行之后，再往同一条样本上追加：

- 实际召回了哪些文档、顺序是什么；

- 最终送给模型的上下文是什么；

- 模型实际回答了什么；

- 回答引用了哪些来源；

- 执行了哪些工具、走了哪些节点；

- 延迟、Token、成本和错误信息。

所以可以先记住一句话：

```Plain Text
评估样本 = 期望值（人工准备） + 实际值（系统运行产生）
```

期望值回答“本来应该是什么”，实际值回答“这次实际做成了什么”。两者放在一起，才可能计算指标、定位问题。

下面举例说明评估数据集中的评估样本。如下是一条售后 RAG 的评估样本。前半部分是人工准备的期望值：

```Plain Text
{
  "question": "退货条件是什么，退款多久可以到账？",
  "reference_answer": "收货后七日内可以申请退货，商品、包装和配件需要保持完整；仓库验收通过后发起原路退款，通常三个工作日内到账，具体以支付渠道为准。",
  "reference_contexts": ["售后规则.md", "退款规则.md"],
  "answerable": true,
  "metadata": {
    "product": "商城售后",
    "version": "2026-09",
    "tenant": "demo",
    "category": "售后"
  }
}
```

字段解释：

RAG系统运行后，同一条样本会追加实际值：

```Plain Text
{
  "retrieved_contexts": ["退款规则.md", "售后规则.md"],
  "answer": "退货条件是……",
  "rewritten_query": "……",
  "citations": ["售后规则.md", "退款规则.md"], #引文、引用
  "trace": ["rewrite", "retrieve", "generate"],
  "latency_ms": 842,
  "input_tokens": 120,
  "output_tokens": 58,
  "error": null
}
```

这里要先区分三个容易混淆的概念：

- 参考答案 reference\_answer：最终回答应该包含哪些事实、条件和边界。它服务于答案正确性和事实正确性。

- 参考上下文 reference\_contexts：回答这个问题需要哪些文档或 chunk。它服务于检索命中、召回和上下文质量。

- 实际上下文 retrieved\_contexts：系统这次真正召回了什么、顺序是什么。它和参考上下文比较，才能知道有没有漏、有没有噪声。

参考答案和参考上下文不是一回事。一个参考答案可能需要多份参考上下文共同支撑；一个参考上下文也可能只支撑答案中的一句话。

初始评估集不需要几千条，但必须覆盖不同类型。一个可用的初始集合至少包含：

1. 单文档直接问答：答案只在一份资料里。

2. 多文档组合问答：答案需要两份或多份资料。

3. 口语化、同义改写、错别字和不完整问题。

4. 相似产品、相似规则和不同版本的区分。

5. 知识库没有答案的问题，用于检查拒答。

6. 需要调用工具或转人工的问题。

7. 越权、提示注入和敏感字段问题。

8. 检索噪声、重复 chunk 和工具失败问题。

建议初始评估集先做 30 到 100 条，覆盖上面的主要类型。样本入库时要保存版本，不要一边修改样本一边比较分数，否则无法判断是系统变好了还是题目变简单了。

### 5\.1\.4\. RAG四层评估

RAG 评估可以分成四层。每层回答不同的问题，不能互相替代。

关于以上四层的理解：

1. 检索层是基础。检索层没找到正确证据，答案层再强也只能依靠模型记忆或猜测。

2. 答案层是结果。检索正确不代表答案一定正确，模型可能答非所问、条件丢失、编造事实或引用错误。

3. Agent/工作流层关注过程。工具选错、参数传错、循环次数失控，最终都可能表现为答案错误。

4. 系统与安全层关注能不能上线。一个回答质量很高但延迟 30 秒、成本过高、或者会泄露他人订单的系统，仍然不能直接投入使用。

### 5\.1\.5\. 离线评估和在线评估

离线评估就是“上线前的评估”，流程如下：

```Plain Text
准备一份固定评估集
  → 让当前版本逐条运行
  → 保存检索、回答、引用和轨迹
  → 计算指标
  → 和基线版本对比
  → 决定是否上线
```

它的特点是可重复。同一份评估集、同一个知识库版本、同一个模型版本，跑出来的结果可以比较。

在线评估就是“上线后的真实监控”。面对真实用户问题、真实知识库变化、真实权限和真实故障。在线评估不一定要求每条请求都有标准答案，它可以先做轻量检查：

- 格式是否正确；

- 是否超时或报错；

- 是否越权；

- 用户是否点踩、追问或转人工。

离线评估回答“这个版本在已知问题上有没有变好”，在线评估回答“这个版本在真实环境里是否稳定”。两者之间的关系是：

```Plain Text
在线发现问题
  → 人工或业务系统补充正确答案
  → 变成新的离线评估样本
  → 离线验证修复
  → 灰度上线
  → 在线继续观察
```

这条链路就是生产反馈闭环。

## 5\.2\. 检索层评估

检索层评估只关心一件事：“给一个用户问题，系统返回的资料对不对、全不全、排序好不好？”

在计算任何指标之前，要先理解三个基础词：相关结果、排名、K。

1\) **相关结果**

相关结果不是“看起来像”的文档，而是人工判断后认为“这份资料确实包含回答问题所需要的事实”。例如用户问：“退款一般多久到账？”，假设系统返回：

```Plain Text
第1条：退款规则：原路退款通常在三个工作日内到账，具体以支付渠道为准。
第2条：售后规则：收货后七日内可以申请退货，商品、包装和配件需要保持完整。
第3条：物流规则：订单发货后可以在订单详情查看物流轨迹。
```

人工判断后，退款规则 是直接相关，售后规则 与退货有关但不直接回答退款到账时间，物流规则 不相关。于是可以标注：“相关结果集合 = \{退款规则\}”，后续所有指标都基于这个“相关结果集合”计算。如果相关结果标注错了，指标再精确也没有意义。

2\) **K**

检索器可能返回 10 条结果，但程序通常只会把前几条交给模型。K 表示“只看前 K 条”。

```Plain Text
K=3：只评估前 3 条结果
K=5：只评估前 5 条结果
```

K 不是越大越好。K 太小可能漏掉正确资料，K 太大可能引入噪声、增加 Token 和延迟，评估时可以先用同一批问题比较不同 K。

3\) **排名**

返回结果是有顺序的：“第1条、第2条、第3条……”，同一个相关结果排在第 1 位和第 5 位，对回答质量的影响完全不同。因为很多 RAG 流程只把前几条交给模型，所以排序本身也是检索质量的一部分。

掌握了“相关结果、K、排名”这三个词，再看后面的指标就会清楚很多。

### 5\.2\.1\. Hit@K

Hit@K回答的问题是：“前 K 条结果里，有没有至少一条是相关结果？”，也就是前K条结果中有没有找到至少一条相关的结果。

当且仅当前 K 条中存在至少一个相关结果，记为Hit@K = 1；当前 K 条中一个相关结果都没有，记为Hit@K = 0。用集合表示如下：

![xLeK5Wbz\.png](图片和附件/xLeK5Wbz.png)

以上公式解释如下：

计算示例：

```Plain Text
K=3
返回检索结果：[A,B,C]
人工准备的正确相关集合：{B,D}
前三条命中了B，那么Hit@3=1

再如：

K=3
返回结果：[A,C,E]
人工准备的正确相关集合：{B,D}
前3条中没有命中任何相关结果，那么Hit@3=0
```

Hit@K 能发现检索器有没有找到答案来源，但是并不能发现：

- 相关结果排在第几位

- 除了一条相关结果之外，还混入了多少无关结果

- 所有相关结果是不是都被找回来

所以 Hit@K 适合作为第一道检查：如果 Hit@K 都很低，说明检索器连正确资料都没找到，应该先解决召回问题。

计算Hit@K案例：

```Plain Text
# 用固定检索结果演示检索层指标from dataclasses import dataclass

@dataclass(frozen=True)class RetrievalCase:"""一条检索评估样本。"""
    question: str # 用户问题
    retrieved_sources: tuple[str, ...] # 检索结果
    relevant_sources: frozenset[str] # 相关来源def hit_at_k(case: RetrievalCase, k: int) -> int:"""前K个结果中只要有一个相关来源，就返回1，否则返回0。"""
    true_or_false = bool(set(case.retrieved_sources[:k]) & case.relevant_sources)
    if true_or_false:
        return 1else:
        return 0def print_case(case: RetrievalCase, k: int) -> None:"""打印单条样本的完整指标和逐步说明。"""
    top_k = case.retrieved_sources[:k]

    # 前K个结果中命中相关来源的数量
    relevant_in_top_k = [source for source in top_k if source in case.relevant_sources]

    # 第一个相关来源的排名
    first_relevant_rank = Nonefor rank, source in enumerate(top_k, start=1):
        if source in case.relevant_sources:
            first_relevant_rank = rank
            breakprint(f"问题：{case.question}")
    print(f"返回顺序：{list(top_k)}")
    print(f"相关来源：{sorted(case.relevant_sources)}")
    print(f"前{k}条命中相关来源：{relevant_in_top_k}")
    print(f"第一个相关来源排名：{first_relevant_rank if first_relevant_rank else '无'}")
    print(
        f"Hit@{k}={hit_at_k(case, k)}，"
    )
    print()


if __name__ == "__main__":
    cases = [
        RetrievalCase(
            question="退货条件和退款时间是什么？",
            retrieved_sources=("售后规则.md", "退款规则.md", "物流规则.md"),
            relevant_sources=frozenset({"售后规则.md", "退款规则.md"}),
        ),
        RetrievalCase(
            question="订单物流轨迹怎么查？",
            retrieved_sources=("物流规则.md", "发票规则.md", "售后规则.md"),
            relevant_sources=frozenset({"物流规则.md"}),
        ),
        RetrievalCase(
            question="退货后退款多久到账？",
            retrieved_sources=("发票规则.md", "物流规则.md", "退款规则.md"),
            relevant_sources=frozenset({"售后规则.md", "退款规则.md"}),
        ),
        RetrievalCase(
            question="电子发票发到哪里？",
            retrieved_sources=("发票规则.md", "物流规则.md", "售后规则.md"),
            relevant_sources=frozenset({"退款规则.md"}),
        ),
    ]

    k = 3
    metric_names = ("hit",)

    totals = {name: 0.0 for name in metric_names}

    print(f"评估样本数：{len(cases)}，K={k}")

    print("=" * 72)
    for case in cases:
        print_case(case, k)
        totals["hit"] += hit_at_k(case, k)

    count = len(cases)
    print("=" * 72)
    print(
        f"汇总：Hit@{k}={totals['hit'] / count:.4f},"
    )
```

以上代码运行结果如下：

![zTAT4zaL\.jpg](图片和附件/zTAT4zaL.jpg)

代码注意问题如下:

1. frozenset 是 Python 内置的 不可变集合 类型，可以理解为“冻结的 set”,表示 relevant\_sources 是一个 元素为字符串的不可变集合。

2. 最后计算多条样本的平均值来评价系统整体的分数作为参考。

### 5\.2\.2\. Precision@K

Precision@K回答的问题是：“前 K 条结果里，有多少条是相关结果？”,即：找回来的结果干不干净。

Precision@K = 前K条中的相关结果数量/K。用集合表示如下：

![B76LoyCW\.png](图片和附件/B76LoyCW.png)

以上公式解释如下：

计算示例：

```Plain Text
K=4
返回结果：[A,B,C,D]
人工准备的正确相关集合：{B,D}
前 4 条中有 2 条相关，那么Precision@4 = 2 / 4 = 0.5
```

Precision@K 可以发现上下文有多“吵”，Precision@K低，说明模型上下文里混入了很多无关资料。但是并不能发现：有没有漏掉相关结果。如果系统只返回了一条相关结果，而真实相关结果有 5 条，Precision 可能仍然很高，但 Recall 很低。

计算Precision@K案例：

```Plain Text
# 用固定检索结果演示检索层指标#from dataclasses import dataclass
import math


@dataclass(frozen=True)class RetrievalCase:"""一条检索评估样本。"""
    question: str # 用户问题
    retrieved_sources: tuple[str, ...] # 检索结果
    relevant_sources: frozenset[str] # 相关来源def hit_at_k(case: RetrievalCase, k: int) -> int:"""前K个结果中只要有一个相关来源，就返回1，否则返回0。"""
    true_or_false = bool(set(case.retrieved_sources[:k]) & case.relevant_sources)
    if true_or_false:
        return 1else:
        return 0def precision_at_k(case: RetrievalCase, k: int) -> float:"""前K个结果中相关来源所占的比例。"""
    top_k = case.retrieved_sources[:k]
    if not top_k:
        return 0.0return sum(source in case.relevant_sources for source in top_k) / len(top_k)


def print_case(case: RetrievalCase, k: int) -> None:"""打印单条样本的完整指标和逐步说明。"""
    top_k = case.retrieved_sources[:k]

    # 前K个结果中命中相关来源的数量
    relevant_in_top_k = [source for source in top_k if source in case.relevant_sources]

    # 第一个相关来源的排名
    first_relevant_rank = Nonefor rank, source in enumerate(top_k, start=1):
        if source in case.relevant_sources:
            first_relevant_rank = rank
            breakprint(f"问题：{case.question}")
    print(f"返回顺序：{list(top_k)}")
    print(f"相关来源：{sorted(case.relevant_sources)}")
    print(f"前{k}条命中相关来源：{relevant_in_top_k}")
    print(f"第一个相关来源排名：{first_relevant_rank if first_relevant_rank else '无'}")
    print(
        f"Hit@{k}={hit_at_k(case, k)}，"f"Precision@{k}={precision_at_k(case, k):.4f}，"
    )
    print()


if __name__ == "__main__":
    cases = [
        RetrievalCase(
            question="退货条件和退款时间是什么？",
            retrieved_sources=("售后规则.md", "退款规则.md", "物流规则.md"),
            relevant_sources=frozenset({"售后规则.md", "退款规则.md"}),
        ),
        RetrievalCase(
            question="订单物流轨迹怎么查？",
            retrieved_sources=("物流规则.md", "发票规则.md", "售后规则.md"),
            relevant_sources=frozenset({"物流规则.md"}),
        ),
        RetrievalCase(
            question="退货后退款多久到账？",
            retrieved_sources=("发票规则.md", "物流规则.md", "退款规则.md"),
            relevant_sources=frozenset({"售后规则.md", "退款规则.md"}),
        ),
        RetrievalCase(
            question="电子发票发到哪里？",
            retrieved_sources=("发票规则.md", "物流规则.md", "售后规则.md"),
            relevant_sources=frozenset({"退款规则.md"}),
        ),
    ]

    k = 3
    metric_names = (
        "hit", "precision", "recall", "rr", "ndcg", "context_precision", "context_recall"
    )
    totals = {name: 0.0 for name in metric_names}

    print(f"评估样本数：{len(cases)}，K={k}")
    print("=" * 72)
    for case in cases:
        print_case(case, k)
        totals["hit"] += hit_at_k(case, k)
        totals["precision"] += precision_at_k(case, k)

    count = len(cases)
    print("=" * 72)
    print(
        f"汇总：Hit@{k}={totals['hit'] / count:.4f}，"f"Precision@{k}={totals['precision'] / count:.4f}，"
    )
```

以上代码运行结果如下：

![QVClAjsW\.jpg](图片和附件/QVClAjsW.jpg)

### 5\.2\.3\. Recall@K

Recall@K 回答的问题是“所有相关结果里，前 K 条找回了多少？”，即：该找回来的有没有漏掉。

Recall@K = 前 K 条中命中的相关结果数量 / 全部相关结果数量。用集合表示如下：

![SXaLyDCG\.png](图片和附件/SXaLyDCG.png)

以上公式解释如下：

计算示例：

```Plain Text
K=4
返回结果：[A,B,C,D]
人工准备的正确相关集合：{B,D,F}
前 4 条命中了 B 和 D，共 2 条，那么Recall@4 = 2 / 3 ≈ 0.667
```

Recall@K 可以发现有没有漏掉召回，常用于同时读取多份来源的情况。分子要按唯一评估 ID 计数。一个来源被切成三个相似 chunk，不能因为返回了三个 chunk 就把一个相关来源算成三次召回。

计算Recall@K案例：

```Plain Text
# 用固定检索结果演示检索层指标from dataclasses import dataclass
import math


@dataclass(frozen=True)class RetrievalCase:"""一条检索评估样本。"""
    question: str # 用户问题
    retrieved_sources: tuple[str, ...] # 检索结果
    relevant_sources: frozenset[str] # 相关来源def hit_at_k(case: RetrievalCase, k: int) -> int:"""前K个结果中只要有一个相关来源，就返回1，否则返回0。"""
    true_or_false = bool(set(case.retrieved_sources[:k]) & case.relevant_sources)
    if true_or_false:
        return 1else:
        return 0def precision_at_k(case: RetrievalCase, k: int) -> float:"""前K个结果中相关来源所占的比例。"""
    top_k = case.retrieved_sources[:k]
    if not top_k:
        return 0.0return sum(source in case.relevant_sources for source in top_k) / len(top_k)


def recall_at_k(case: RetrievalCase, k: int) -> float:"""全部相关来源中，被前K个结果覆盖的比例。"""if not case.relevant_sources:
        return 0.0
    hit_sources = set(case.retrieved_sources[:k]) & case.relevant_sources
    return len(hit_sources) / len(case.relevant_sources)

def print_case(case: RetrievalCase, k: int) -> None:"""打印单条样本的完整指标和逐步说明。"""
    top_k = case.retrieved_sources[:k]

    # 前K个结果中命中相关来源的数量
    relevant_in_top_k = [source for source in top_k if source in case.relevant_sources]

    # 第一个相关来源的排名
    first_relevant_rank = Nonefor rank, source in enumerate(top_k, start=1):
        if source in case.relevant_sources:
            first_relevant_rank = rank
            breakprint(f"问题：{case.question}")
    print(f"返回顺序：{list(top_k)}")
    print(f"相关来源：{sorted(case.relevant_sources)}")
    print(f"前{k}条命中相关来源：{relevant_in_top_k}")
    print(f"第一个相关来源排名：{first_relevant_rank if first_relevant_rank else '无'}")
    print(
        f"Hit@{k}={hit_at_k(case, k)}，"f"Precision@{k}={precision_at_k(case, k):.4f}，"f"Recall@{k}={recall_at_k(case, k):.4f}，"
    )
    print()


if __name__ == "__main__":
    cases = [
        RetrievalCase(
            question="退货条件和退款时间是什么？",
            retrieved_sources=("售后规则.md", "退款规则.md", "物流规则.md"),
            relevant_sources=frozenset({"售后规则.md", "退款规则.md"}),
        ),
        RetrievalCase(
            question="订单物流轨迹怎么查？",
            retrieved_sources=("物流规则.md", "发票规则.md", "售后规则.md"),
            relevant_sources=frozenset({"物流规则.md"}),
        ),
        RetrievalCase(
            question="退货后退款多久到账？",
            retrieved_sources=("发票规则.md", "物流规则.md", "退款规则.md"),
            relevant_sources=frozenset({"售后规则.md", "退款规则.md"}),
        ),
        RetrievalCase(
            question="电子发票发到哪里？",
            retrieved_sources=("发票规则.md", "物流规则.md", "售后规则.md"),
            relevant_sources=frozenset({"退款规则.md"}),
        ),
    ]

    k = 3
    metric_names = (
        "hit", "precision", "recall", "rr", "ndcg", "context_precision", "context_recall"
    )
    totals = {name: 0.0 for name in metric_names}

    print(f"评估样本数：{len(cases)}，K={k}")
    print("=" * 72)
    for case in cases:
        print_case(case, k)
        totals["hit"] += hit_at_k(case, k)
        totals["precision"] += precision_at_k(case, k)
        totals["recall"] += recall_at_k(case, k)

    count = len(cases)
    print("=" * 72)
    print(
        f"汇总：Hit@{k}={totals['hit'] / count:.4f}，"f"Precision@{k}={totals['precision'] / count:.4f}，"f"Recall@{k}={totals['recall'] / count:.4f}，"
    )
```

以上代码运行结果如下：

![UWQyj6HE\.jpg](图片和附件/UWQyj6HE.jpg)

### 5\.2\.4\. MRR

先解释两个词：

- 相关结果：人工判断确实能帮助回答问题的资料。

- 排名：它在返回列表中的位置，第 1 位、第 2 位、第 3 位……

MRR可以回答问题是：“用户最想要的那条相关结果，排得靠不靠前？”，即：MRR 看的是第一条相关结果出现的位置。

单条检索结果MRR评估的公式： RR = 1 / rank，其中：

整个评估集上的MRR公式：MRR = 所有问题的 RR 平均值。

MRR能发现相关结果是不是被排到了后面。MRR 高，说明第一条相关结果通常出现在靠前位置。不能发现后面还有没有其他相关结果，也没有考虑除了第一条之外的相关结果。

计算MRR案例：

```Plain Text
# 用固定检索结果演示检索层指标#from dataclasses import dataclass


@dataclass(frozen=True)class RetrievalCase:"""一条检索评估样本。"""
    question: str # 用户问题
    retrieved_sources: tuple[str, ...] # 检索结果
    relevant_sources: frozenset[str] # 相关来源def hit_at_k(case: RetrievalCase, k: int) -> int:"""前K个结果中只要有一个相关来源，就返回1，否则返回0。"""
    true_or_false = bool(set(case.retrieved_sources[:k]) & case.relevant_sources)
    if true_or_false:
        return 1else:
        return 0def precision_at_k(case: RetrievalCase, k: int) -> float:"""前K个结果中相关来源所占的比例。"""
    top_k = case.retrieved_sources[:k]
    if not top_k:
        return 0.0return sum(source in case.relevant_sources for source in top_k) / len(top_k)


def recall_at_k(case: RetrievalCase, k: int) -> float:"""全部相关来源中，被前K个结果覆盖的比例。"""if not case.relevant_sources:
        return 0.0
    hit_sources = set(case.retrieved_sources[:k]) & case.relevant_sources
    return len(hit_sources) / len(case.relevant_sources)


def reciprocal_rank(case: RetrievalCase, k: int) -> float:"""第一个相关来源的排名倒数。"""for rank, source in enumerate(case.retrieved_sources[:k], start=1):
        if source in case.relevant_sources:
            return 1.0 / rank
    return 0.0def print_case(case: RetrievalCase, k: int) -> None:"""打印单条样本的完整指标和逐步说明。"""
    top_k = case.retrieved_sources[:k]

    # 前K个结果中命中相关来源的数量
    relevant_in_top_k = [source for source in top_k if source in case.relevant_sources]

    # 第一个相关来源的排名
    first_relevant_rank = Nonefor rank, source in enumerate(top_k, start=1):
        if source in case.relevant_sources:
            first_relevant_rank = rank
            breakprint(f"问题：{case.question}")
    print(f"返回顺序：{list(top_k)}")
    print(f"相关来源：{sorted(case.relevant_sources)}")
    print(f"前{k}条命中相关来源：{relevant_in_top_k}")
    print(f"第一个相关来源排名：{first_relevant_rank if first_relevant_rank else '无'}")
    print(
        f"Hit@{k}={hit_at_k(case, k)}，"f"Precision@{k}={precision_at_k(case, k):.4f}，"f"Recall@{k}={recall_at_k(case, k):.4f}，"f"RR={reciprocal_rank(case, k):.4f}，"
    )
    print()


if __name__ == "__main__":
    cases = [
        RetrievalCase(
            question="退货条件和退款时间是什么？",
            retrieved_sources=("售后规则.md", "退款规则.md", "物流规则.md"),
            relevant_sources=frozenset({"售后规则.md", "退款规则.md"}),
        ),
        RetrievalCase(
            question="订单物流轨迹怎么查？",
            retrieved_sources=("物流规则.md", "发票规则.md", "售后规则.md"),
            relevant_sources=frozenset({"物流规则.md"}),
        ),
        RetrievalCase(
            question="退货后退款多久到账？",
            retrieved_sources=("发票规则.md", "物流规则.md", "退款规则.md"),
            relevant_sources=frozenset({"售后规则.md", "退款规则.md"}),
        ),
        RetrievalCase(
            question="电子发票发到哪里？",
            retrieved_sources=("发票规则.md", "物流规则.md", "售后规则.md"),
            relevant_sources=frozenset({"退款规则.md"}),
        ),
    ]

    k = 3
    metric_names = (
        "hit", "precision", "recall", "rr", "ndcg", "context_precision", "context_recall"
    )
    totals = {name: 0.0 for name in metric_names}

    print(f"评估样本数：{len(cases)}，K={k}")
    print("=" * 72)
    for case in cases:
        print_case(case, k)
        totals["hit"] += hit_at_k(case, k)
        totals["precision"] += precision_at_k(case, k)
        totals["recall"] += recall_at_k(case, k)
        totals["rr"] += reciprocal_rank(case, k)

    count = len(cases)
    print("=" * 72)
    print(
        f"汇总：Hit@{k}={totals['hit'] / count:.4f}，"f"Precision@{k}={totals['precision'] / count:.4f}，"f"Recall@{k}={totals['recall'] / count:.4f}，"f"MRR={totals['rr'] / count:.4f}，"
    )
```

以上代码运行结果如下：

![a2T4lZM1\.jpg](图片和附件/a2T4lZM1.jpg)

### 5\.2\.5\. NDCG@K

NDCG@K 是检索评估里最“绕”的一个指标，因为它同时考虑两件事：**相关性有多强和排在什么位置**。下面通过一个场景的几个步骤来说明NDCG@K计算原理。

1\) **第一步：标记相关性等级**

前面几个指标（Hit@K、Precision@K、Recall@K、MRR）都把文档分成两类：相关或不相关。但真实业务里，相关性有强弱。比如用户问“退款多久到账”，返回三条文档：

```Plain Text
第1条：退款规则.md → 直接回答了“三个工作日”，非常相关
第2条：售后规则.md → 提到了退款，但没有说时间，有点相关
第3条：物流规则.md → 和退款没关系，不相关
```

如果把“非常相关”和“有点相关”都算成“相关”，就丢失了信息。所以引入相关性等级（需要人工在样本中标记）：

```Plain Text
3 = 非常相关（直接回答问题）
2 = 相关（提供重要补充）
1 = 有点相关（只能作为背景）
0 = 不相关
```

现在假设某次检索返回 4 条结果，人工标注的相关性等级是：

```Plain Text
检索结果的排名:  1  2  3  4对应相关性等级:  3  2  0  1
```

意思是：第 1 条非常相关，第 2 条相关，第 3 条不相关，第 4 条有点相关。

2\) **第二步：计算DCG（折损累计增益）**

![pCbaVM9i\.png](图片和附件/pCbaVM9i.png)

以上公式中，rel\_i表示第 i 条结果的相关性等级。log2\(i \+ 1\)表示位置折损，排名越靠后，分母越大，贡献越小。那么根据前面举例，针对返回的四条检索内容可以得到如下表格：

把以上贡献加起来得到：DCG@4 = 3 \+ 1\.262 \+ 0 \+ 0\.431 = 4\.693，从这个计算中可以得到DCG的核心思想：

- 等级越高，贡献越大；

- 排名越靠后，分母越大，贡献被“折损”得越厉害。

- 第 1 名等级 3 贡献是 3，如果它排到第 4 名，贡献就只有 3 / 2\.322 ≈ 1\.292，缩水了一大半。

3\) **第三步：计算IDCG（理想排序的DCG）**

IDCG 是“如果按最理想的方式排序，DCG 最大能是多少”。理想排序就是把同一批等级从高到低排列：

```Plain Text
检索结果的排名:  1  2  3  4原始相关性等级:  3  2  0  1离线相关性等级:  3  2  1  0
```

用同样的方式计算理想排序的 DCG：

可以得到IDCG@4 = 3 \+ 1\.262 \+ 0\.5 \+ 0 = 4\.762。

IDCG 的作用：它是这个问题的“满分线”。同一批等级，无论怎么排，DCG 都不可能超过 IDCG。

4\) **第四步：计算NDCG**

NDCG@4 = DCG@4 / IDCG@4 = 4\.693 / 4\.762 ≈ 0\.985

NDCG的取值范围是0到1，越接近1，说明排序越接近理想排序；等于1，说明当前排序就是理想排序；越接近0，说明高等级的相关内容被排到了后面。

为了更好的理解NDCG，假设有另一个Agent RAG对于相同问题返回了同样的4条文档，但顺序不同：

```Plain Text
系统 A 的排序：3, 2, 0, 1  → NDCG = 0.985
系统 B 的排序：0, 1, 3, 2  → NDCG = ?
```

可以计算B系统的NDCG结果：

得到DCG@4 = 0 \+ 0\.631 \+ 1\.5 \+ 0\.861 = 2\.992 ，进而计算得到NDCG@4 = 2\.992 / 4\.762 ≈ 0\.628。

对比系统A和系统B都是返回了相同的文档集合，但高等级排在前面的系统A的结果得到的NDCG结果0\.985 \> 高等级排在后面的系统B的NDCG结果0\.628。

综上所述：Hit@K、Precision@K、Recall@K 只看“有没有找到”，不关心“排得好不好”。NDCG 同时看“等级多高”和“排得多前”，它可以发现排序质量，尤其是“高相关内容有没有排在前面”，但是需要更细的相关性等级标注，标注成本比“相关/不相关”高。

如下是计算NDCG@K案例，特别提示:以上用分级相关性解释 NDCG 的原理，如下案例代码为了简化，使用二值相关性（相关=1，不相关=0）计算 NDCG@K。两种口径的公式相同，区别只在于 rel\_i 的取值。如果需要分级 NDCG，需要为每个位置标注相关性等级，而不是只用“相关/不相关”。

```Plain Text
# 用固定检索结果演示检索层指标#from dataclasses import dataclass
import math


@dataclass(frozen=True)class RetrievalCase:"""一条检索评估样本。"""
    question: str # 用户问题
    retrieved_sources: tuple[str, ...] # 检索结果
    relevant_sources: frozenset[str] # 相关来源def hit_at_k(case: RetrievalCase, k: int) -> int:"""前K个结果中只要有一个相关来源，就返回1，否则返回0。"""
    true_or_false = bool(set(case.retrieved_sources[:k]) & case.relevant_sources)
    if true_or_false:
        return 1else:
        return 0def precision_at_k(case: RetrievalCase, k: int) -> float:"""前K个结果中相关来源所占的比例。"""
    top_k = case.retrieved_sources[:k]
    if not top_k:
        return 0.0return sum(source in case.relevant_sources for source in top_k) / len(top_k)


def recall_at_k(case: RetrievalCase, k: int) -> float:"""全部相关来源中，被前K个结果覆盖的比例。"""if not case.relevant_sources:
        return 0.0
    hit_sources = set(case.retrieved_sources[:k]) & case.relevant_sources
    return len(hit_sources) / len(case.relevant_sources)


def reciprocal_rank(case: RetrievalCase, k: int) -> float:"""第一个相关来源的排名倒数。"""for rank, source in enumerate(case.retrieved_sources[:k], start=1):
        if source in case.relevant_sources:
            return 1.0 / rank
    return 0.0def ndcg_at_k(case: RetrievalCase, k: int) -> float:"""二值相关性下的NDCG@K。"""
    gains = [
        1.0 if source in case.relevant_sources else 0.0for source in case.retrieved_sources[:k]
    ]
    dcg = sum(gain / math.log2(rank + 1) for rank, gain in enumerate(gains, start=1))
    ideal_count = min(len(case.relevant_sources), k)
    idcg = sum(1.0 / math.log2(rank + 1) for rank in range(1, ideal_count + 1))
    return dcg / idcg if idcg else 0.0def print_case(case: RetrievalCase, k: int) -> None:"""打印单条样本的完整指标和逐步说明。"""
    top_k = case.retrieved_sources[:k]

    # 前K个结果中命中相关来源的数量
    relevant_in_top_k = [source for source in top_k if source in case.relevant_sources]

    # 第一个相关来源的排名
    first_relevant_rank = Nonefor rank, source in enumerate(top_k, start=1):
        if source in case.relevant_sources:
            first_relevant_rank = rank
            breakprint(f"问题：{case.question}")
    print(f"返回顺序：{list(top_k)}")
    print(f"相关来源：{sorted(case.relevant_sources)}")
    print(f"前{k}条命中相关来源：{relevant_in_top_k}")
    print(f"第一个相关来源排名：{first_relevant_rank if first_relevant_rank else '无'}")
    print(
        f"Hit@{k}={hit_at_k(case, k)}，"f"Precision@{k}={precision_at_k(case, k):.4f}，"f"Recall@{k}={recall_at_k(case, k):.4f}，"f"RR={reciprocal_rank(case, k):.4f}，"f"NDCG@{k}={ndcg_at_k(case, k):.4f}，"
    )
    print()


if __name__ == "__main__":
    cases = [
        RetrievalCase(
            question="退货条件和退款时间是什么？",
            retrieved_sources=("售后规则.md", "退款规则.md", "物流规则.md"),
            relevant_sources=frozenset({"售后规则.md", "退款规则.md"}),
        ),
        RetrievalCase(
            question="订单物流轨迹怎么查？",
            retrieved_sources=("物流规则.md", "发票规则.md", "售后规则.md"),
            relevant_sources=frozenset({"物流规则.md"}),
        ),
        RetrievalCase(
            question="退货后退款多久到账？",
            retrieved_sources=("发票规则.md", "物流规则.md", "退款规则.md"),
            relevant_sources=frozenset({"售后规则.md", "退款规则.md"}),
        ),
        RetrievalCase(
            question="电子发票发到哪里？",
            retrieved_sources=("发票规则.md", "物流规则.md", "售后规则.md"),
            relevant_sources=frozenset({"退款规则.md"}),
        ),
    ]

    k = 3
    metric_names = (
        "hit", "precision", "recall", "rr", "ndcg", "context_precision", "context_recall"
    )
    totals = {name: 0.0 for name in metric_names}

    print(f"评估样本数：{len(cases)}，K={k}")
    print("=" * 72)
    for case in cases:
        print_case(case, k)
        totals["hit"] += hit_at_k(case, k)
        totals["precision"] += precision_at_k(case, k)
        totals["recall"] += recall_at_k(case, k)
        totals["rr"] += reciprocal_rank(case, k)
        totals["ndcg"] += ndcg_at_k(case, k)

    count = len(cases)
    print("=" * 72)
    print(
        f"汇总：Hit@{k}={totals['hit'] / count:.4f}，"f"Precision@{k}={totals['precision'] / count:.4f}，"f"Recall@{k}={totals['recall'] / count:.4f}，"f"MRR={totals['rr'] / count:.4f}，"f"NDCG@{k}={totals['ndcg'] / count:.4f}，"
    )
```

以上运行结果如下：

![5Dw3f4gn\.jpg](图片和附件/5Dw3f4gn.jpg)

以上案例中计算NDCG@K时，rel\_i只有0或者1取值，这里采取的是二值NDCG，没有特别对每个相关文档进行相关性等级标注。

### 5\.2\.6\. Context Precision\-上下文精度

Context Precision 回答的问题是“进入上下文的资料里，是否干净且靠前”，它和 Precision@K 的区别在于：Precision@K 只看“前 K 条里有几条相关”，不看位置；Context Precision 看的是“相关结果出现时，它前面的内容有多干净”。

下面举例说明Context Precision与 Precision@K 差异，以及Context Precision统计原理。假设K=4，表示检索返回4条结果，人工标准的相关性如下：

```Plain Text
检索结果的排名:  1  2  3  4对应相关性标记:  相关  不相关  相关  相关
```

注意，以上用的是二值标记（相关/不相关），不是分级。其中3条相关（第1、3、4位），1条不相关（第2位）。

如果用Precision@4指标来评估：Precision@4 = 3 / 4 = 0\.75，但Precision@4不关心顺序，如果把相关结果都挪到后面：

```Plain Text
检索结果的排名:  1  2  3  4对应相关性标记:  不相关  相关  相关  相关
```

Precision@4 仍然是 3 / 4 = 0\.75，因为相关总数没变。Context Precision 就是为了区分这两种情况而设计的。

Context Precision的核心思想是：对每个相关结果，计算它出现时“当前前缀的精度”，然后取平均。其公式如下：

![DUpN0maU\.png](图片和附件/DUpN0maU.png)

以上公式解释如下：

继续之前的例子，计算Context Precision@K 评估指标：

```Plain Text
检索结果的排名:  1  2  3  4对应相关性标记:  相关  不相关  相关  相关
```

第一位相关：Precision@1 = 前1条中相关数 / 1 = 1 / 1 = 1，v\_1 = 1，贡献 = 1 × 1 = 1。

第二位不相关：v\_2 = 0，贡献 = 0（不参与加权）。

第三位相关：Precision@3 = 前3条中相关数 / 3 = 2 / 3 ≈ 0\.667，v\_3 = 1,贡献 = 0\.667 × 1 = 0\.667

第四位相关：Precision@4 = 前4条中相关数 / 4 = 3 / 4 = 0\.75，v\_4 = 1，贡献 = 0\.75 × 1 = 0\.75

前4条中，相关项总数=3，所以，Context Precision@4 = \(1 \+ 0\.667 \+ 0\.75\) / 3 = 2\.417 / 3 ≈ 0\.806

对比另一种排序，把相关结果都挪到后面，计算得到Context Precision@4过程如下：

```Plain Text
检索结果的排名:  1  2  3  4对应相关性标记:  不相关  相关  相关  相关
```

第一位不相关：v\_1 = 0，贡献 = 0（不参与加权）。

第二位相关：Precision@2 = 前2条中相关数 / 2 = 1 / 2 = 0\.5,v\_2 = 1,贡献 = 0\.5 × 1=0\.5

第三位相关：Precision@3 = 前3条中相关数 / 3 = 2 / 3 ≈ 0\.667，v\_3 = 1,贡献 = 0\.667 × 1 = 0\.667

第四位相关：Precision@4 = 前4条中相关数 / 4 = 3 / 4 = 0\.75，v\_4 = 1，贡献 = 0\.75 × 1 = 0\.75

前4条中，相关项总数=3，所以，Context Precision@4 = \(0\.5 \+ 0\.667 \+ 0\.75\) / 3 = 1\.917 / 3 ≈ 0\.639

以上两种排序，可以直观得到如下对比结果：

Precision@4 完全相同，因为它只看“前 4 条中有几条相关”。Context Precision 明显不同，因为它惩罚了“相关结果被排到后面”的情况。所以，相关结果越靠前，Context Precision 越高。这正好弥补了 Precision@K 不关心顺序的缺陷。

计算Context Precision案例：

```Plain Text
# 用固定检索结果演示检索层指标from dataclasses import dataclass
import math


@dataclass(frozen=True)class RetrievalCase:"""一条检索评估样本。"""
    question: str # 用户问题
    retrieved_sources: tuple[str, ...] # 检索结果
    relevant_sources: frozenset[str] # 相关来源def hit_at_k(case: RetrievalCase, k: int) -> int:"""前K个结果中只要有一个相关来源，就返回1，否则返回0。"""
    true_or_false = bool(set(case.retrieved_sources[:k]) & case.relevant_sources)
    if true_or_false:
        return 1else:
        return 0def precision_at_k(case: RetrievalCase, k: int) -> float:"""前K个结果中相关来源所占的比例。"""
    top_k = case.retrieved_sources[:k]
    if not top_k:
        return 0.0return sum(source in case.relevant_sources for source in top_k) / len(top_k)


def recall_at_k(case: RetrievalCase, k: int) -> float:"""全部相关来源中，被前K个结果覆盖的比例。"""if not case.relevant_sources:
        return 0.0
    hit_sources = set(case.retrieved_sources[:k]) & case.relevant_sources
    return len(hit_sources) / len(case.relevant_sources)


def reciprocal_rank(case: RetrievalCase, k: int) -> float:"""第一个相关来源的排名倒数。"""for rank, source in enumerate(case.retrieved_sources[:k], start=1):
        if source in case.relevant_sources:
            return 1.0 / rank
    return 0.0def ndcg_at_k(case: RetrievalCase, k: int) -> float:"""二值相关性下的NDCG@K。"""
    gains = [
        1.0 if source in case.relevant_sources else 0.0for source in case.retrieved_sources[:k]
    ]
    dcg = sum(gain / math.log2(rank + 1) for rank, gain in enumerate(gains, start=1))
    ideal_count = min(len(case.relevant_sources), k)
    idcg = sum(1.0 / math.log2(rank + 1) for rank in range(1, ideal_count + 1))
    return dcg / idcg if idcg else 0.0def context_precision_at_k(case: RetrievalCase, k: int) -> float:"""按Ragas口径计算Context Precision：相关结果越靠前，分值越高。"""
    top_k = case.retrieved_sources[:k]
    # 统计前K个结果中命中相关来源的数量
    relevant_in_top_k = sum(source in case.relevant_sources for source in top_k)
    if relevant_in_top_k == 0:
        return 0.0

    weighted_precision = 0.0
    running_relevant = 0# running_relevant 统计当前已命中相关来源的数量，rank 是第几条数据# weighted_precision 计算的就是 Precision@ifor rank, source in enumerate(top_k, start=1):
        if source in case.relevant_sources:
            running_relevant += 1
            weighted_precision += running_relevant / rank
    return weighted_precision / relevant_in_top_k


def print_case(case: RetrievalCase, k: int) -> None:"""打印单条样本的完整指标和逐步说明。"""
    top_k = case.retrieved_sources[:k]

    # 前K个结果中命中相关来源的数量
    relevant_in_top_k = [source for source in top_k if source in case.relevant_sources]

    # 第一个相关来源的排名
    first_relevant_rank = Nonefor rank, source in enumerate(top_k, start=1):
        if source in case.relevant_sources:
            first_relevant_rank = rank
            breakprint(f"问题：{case.question}")
    print(f"返回顺序：{list(top_k)}")
    print(f"相关来源：{sorted(case.relevant_sources)}")
    print(f"前{k}条命中相关来源：{relevant_in_top_k}")
    print(f"第一个相关来源排名：{first_relevant_rank if first_relevant_rank else '无'}")
    print(
        f"Hit@{k}={hit_at_k(case, k)}，"f"Precision@{k}={precision_at_k(case, k):.4f}，"f"Recall@{k}={recall_at_k(case, k):.4f}，"f"RR={reciprocal_rank(case, k):.4f}，"f"NDCG@{k}={ndcg_at_k(case, k):.4f}，"f"Context Precision@{k}={context_precision_at_k(case, k):.4f}，"
    )
    print()


if __name__ == "__main__":
    cases = [
        RetrievalCase(
            question="退货条件和退款时间是什么？",
            retrieved_sources=("售后规则.md", "退款规则.md", "物流规则.md"),
            relevant_sources=frozenset({"售后规则.md", "退款规则.md"}),
        ),
        RetrievalCase(
            question="订单物流轨迹怎么查？",
            retrieved_sources=("物流规则.md", "发票规则.md", "售后规则.md"),
            relevant_sources=frozenset({"物流规则.md"}),
        ),
        RetrievalCase(
            question="退货后退款多久到账？",
            retrieved_sources=("发票规则.md", "物流规则.md", "退款规则.md"),
            relevant_sources=frozenset({"售后规则.md", "退款规则.md"}),
        ),
        RetrievalCase(
            question="电子发票发到哪里？",
            retrieved_sources=("发票规则.md", "物流规则.md", "售后规则.md"),
            relevant_sources=frozenset({"退款规则.md"}),
        ),
    ]

    k = 3
    metric_names = (
        "hit", "precision", "recall", "rr", "ndcg", "context_precision", "context_recall"
    )
    totals = {name: 0.0 for name in metric_names}

    print(f"评估样本数：{len(cases)}，K={k}")
    print("=" * 72)
    for case in cases:
        print_case(case, k)
        totals["hit"] += hit_at_k(case, k)
        totals["precision"] += precision_at_k(case, k)
        totals["recall"] += recall_at_k(case, k)
        totals["rr"] += reciprocal_rank(case, k)
        totals["ndcg"] += ndcg_at_k(case, k)
        totals["context_precision"] += context_precision_at_k(case, k)

    count = len(cases)
    print("=" * 72)
    print(
        f"汇总：Hit@{k}={totals['hit'] / count:.4f}，"f"Precision@{k}={totals['precision'] / count:.4f}，"f"Recall@{k}={totals['recall'] / count:.4f}，"f"MRR={totals['rr'] / count:.4f}，"f"NDCG@{k}={totals['ndcg'] / count:.4f}，"f"Context Precision@{k}={totals['context_precision'] / count:.4f}，"
    )
```

以上代码运行结果如下：

![B1Q7mAUr\.jpg](图片和附件/B1Q7mAUr.jpg)

### 5\.2\.7\. Context Recall\-上下文召回

Context Recall回答的问题是“参考答案需要的信息，是否都能在本次检索上下文里找到？”，如果参考上下文就是参考文档（文档名称/id等），那么Context Recall 就是 Recall@K 。

Context Recall 有两种常见口径：

第一种：ID级Context Recall

如果已经标注了参考上下文，可以比较“参考上下文集合”和“实际召回集合”：ID级 Context Recall = \|实际召回 ∩ 参考上下文\| / \|参考上下文\|。

计算示例：

```Plain Text
参考上下文：{A,B,C}
实际召回：{A,C}
那么ID级 Context Recall = 2 / 3 ≈ 0.667
```

第二种：LLM声明级Context Recall

由大模型LLM先把参考答案拆成若干事实声明，再判断每个声明能否从检索上下文推出：Context Recall= 检索上下文支持的参考答案声明数 / 参考答案声明总数。

计算示例：

```Plain Text
参考答案拆成4个事实声明
检索上下文支持其中3个
Context Recall = 3 / 4 ≈ 0.75
```

计算Context Recall案例：

```Plain Text
# 用固定检索结果演示检索层指标from dataclasses import dataclass
import math


@dataclass(frozen=True)class RetrievalCase:"""一条检索评估样本。"""
    question: str # 用户问题
    retrieved_sources: tuple[str, ...] # 检索结果
    relevant_sources: frozenset[str] # 相关来源def hit_at_k(case: RetrievalCase, k: int) -> int:"""前K个结果中只要有一个相关来源，就返回1，否则返回0。"""
    true_or_false = bool(set(case.retrieved_sources[:k]) & case.relevant_sources)
    if true_or_false:
        return 1else:
        return 0def precision_at_k(case: RetrievalCase, k: int) -> float:"""前K个结果中相关来源所占的比例。"""
    top_k = case.retrieved_sources[:k]
    if not top_k:
        return 0.0return sum(source in case.relevant_sources for source in top_k) / len(top_k)


def recall_at_k(case: RetrievalCase, k: int) -> float:"""全部相关来源中，被前K个结果覆盖的比例。"""if not case.relevant_sources:
        return 0.0
    hit_sources = set(case.retrieved_sources[:k]) & case.relevant_sources
    return len(hit_sources) / len(case.relevant_sources)


def reciprocal_rank(case: RetrievalCase, k: int) -> float:"""第一个相关来源的排名倒数。"""for rank, source in enumerate(case.retrieved_sources[:k], start=1):
        if source in case.relevant_sources:
            return 1.0 / rank
    return 0.0def ndcg_at_k(case: RetrievalCase, k: int) -> float:"""二值相关性下的NDCG@K。"""
    gains = [
        1.0 if source in case.relevant_sources else 0.0for source in case.retrieved_sources[:k]
    ]
    dcg = sum(gain / math.log2(rank + 1) for rank, gain in enumerate(gains, start=1))
    ideal_count = min(len(case.relevant_sources), k)
    idcg = sum(1.0 / math.log2(rank + 1) for rank in range(1, ideal_count + 1))
    return dcg / idcg if idcg else 0.0def context_precision_at_k(case: RetrievalCase, k: int) -> float:"""按Ragas口径计算Context Precision：相关结果越靠前，分值越高。"""
    top_k = case.retrieved_sources[:k]
    # 统计前K个结果中命中相关来源的数量
    relevant_in_top_k = sum(source in case.relevant_sources for source in top_k)
    if relevant_in_top_k == 0:
        return 0.0

    weighted_precision = 0.0
    running_relevant = 0# running_relevant 统计当前已命中相关来源的数量，rank 是第几条数据# weighted_precision 计算的就是 Precision@ifor rank, source in enumerate(top_k, start=1):
        if source in case.relevant_sources:
            running_relevant += 1
            weighted_precision += running_relevant / rank
    return weighted_precision / relevant_in_top_k


def context_recall_at_k(case: RetrievalCase, k: int) -> float:"""按来源ID口径计算Context Recall，属于ID级代理，不是LLM声明级口径。"""if not case.relevant_sources:
        return 0.0
    hit_sources = set(case.retrieved_sources[:k]) & case.relevant_sources
    return len(hit_sources) / len(case.relevant_sources)


def print_case(case: RetrievalCase, k: int) -> None:"""打印单条样本的完整指标和逐步说明。"""
    top_k = case.retrieved_sources[:k]

    # 前K个结果中命中相关来源的数量
    relevant_in_top_k = [source for source in top_k if source in case.relevant_sources]

    # 第一个相关来源的排名
    first_relevant_rank = Nonefor rank, source in enumerate(top_k, start=1):
        if source in case.relevant_sources:
            first_relevant_rank = rank
            breakprint(f"问题：{case.question}")
    print(f"返回顺序：{list(top_k)}")
    print(f"相关来源：{sorted(case.relevant_sources)}")
    print(f"前{k}条命中相关来源：{relevant_in_top_k}")
    print(f"第一个相关来源排名：{first_relevant_rank if first_relevant_rank else '无'}")
    print(
        f"Hit@{k}={hit_at_k(case, k)}，"f"Precision@{k}={precision_at_k(case, k):.4f}，"f"Recall@{k}={recall_at_k(case, k):.4f}，"f"RR={reciprocal_rank(case, k):.4f}，"f"NDCG@{k}={ndcg_at_k(case, k):.4f}，"f"Context Precision@{k}={context_precision_at_k(case, k):.4f}，"f"Context Recall@{k}={context_recall_at_k(case, k):.4f}"
    )
    print()


if __name__ == "__main__":
    cases = [
        RetrievalCase(
            question="退货条件和退款时间是什么？",
            retrieved_sources=("售后规则.md", "退款规则.md", "物流规则.md"),
            relevant_sources=frozenset({"售后规则.md", "退款规则.md"}),
        ),
        RetrievalCase(
            question="订单物流轨迹怎么查？",
            retrieved_sources=("物流规则.md", "发票规则.md", "售后规则.md"),
            relevant_sources=frozenset({"物流规则.md"}),
        ),
        RetrievalCase(
            question="退货后退款多久到账？",
            retrieved_sources=("发票规则.md", "物流规则.md", "退款规则.md"),
            relevant_sources=frozenset({"售后规则.md", "退款规则.md"}),
        ),
        RetrievalCase(
            question="电子发票发到哪里？",
            retrieved_sources=("发票规则.md", "物流规则.md", "售后规则.md"),
            relevant_sources=frozenset({"退款规则.md"}),
        ),
    ]

    k = 3
    metric_names = (
        "hit", "precision", "recall", "rr", "ndcg", "context_precision", "context_recall"
    )
    totals = {name: 0.0 for name in metric_names}

    print(f"评估样本数：{len(cases)}，K={k}")
    print("=" * 72)
    for case in cases:
        print_case(case, k)
        totals["hit"] += hit_at_k(case, k)
        totals["precision"] += precision_at_k(case, k)
        totals["recall"] += recall_at_k(case, k)
        totals["rr"] += reciprocal_rank(case, k)
        totals["ndcg"] += ndcg_at_k(case, k)
        totals["context_precision"] += context_precision_at_k(case, k)
        totals["context_recall"] += context_recall_at_k(case, k)

    count = len(cases)
    print("=" * 72)
    print(
        f"汇总：Hit@{k}={totals['hit'] / count:.4f}，"f"Precision@{k}={totals['precision'] / count:.4f}，"f"Recall@{k}={totals['recall'] / count:.4f}，"f"MRR={totals['rr'] / count:.4f}，"f"NDCG@{k}={totals['ndcg'] / count:.4f}，"f"Context Precision@{k}={totals['context_precision'] / count:.4f}，"f"Context Recall@{k}={totals['context_recall'] / count:.4f}"
    )
```

以上代码运行结果如下：

![DJUu83Nl\.jpg](图片和附件/DJUu83Nl.jpg)

以上代码注意如下几点：

1. 该评估代码与Recall@K代码一样，这里 relevant\_sources 同时作为“全部相关文档”和“参考上下文”。

2. 本案例使用 ID 级口径，LLM 声明级口径需要额外调用 LLM。

### 5\.2\.8\. 检索层评估指标总结

## 5\.3\. 答案层评估

答案层评估主要回答三类问题：

### 5\.3\.1\. 答案正确性

答案正确性包括两部分：Answer Correctness（答案正确性）和Factual Correctness（事实准确性）。

- **Answer Correctness（答案正确性）**

Answer Correctness 是业务层的判断：“这个回答，和业务认可的正确答案相比，事实是否一致、内容是否完整？”它不要求逐字一致。例如：

```Plain Text
参考答案：原路退款通常在三个工作日内到账，具体以支付渠道为准。
系统回答：退款一般三个工作日左右到账，实际到账时间看支付渠道。
```

这两句话用词不同，但事实一致，可以认为答案正确。

再看反例：

```Plain Text
参考答案：原路退款通常在三个工作日内到账，具体以支付渠道为准。
系统回答：保证三天内到账。
```

关键词“退款”和“三天”都出现了，但“通常”和“以支付渠道为准”两个条件丢失了，所以不能算正确答案。

- **Factual Correctness（事实准确性）**

Factual Correctness 是把 Answer Correctness 落到事实声明层面的可计算指标：“系统回答里的事实，和参考答案里的事实，重合了多少？”，做法是先把回答和参考答案拆成事实声明，再比较。

```Plain Text
设:
```

> TP：回答和参考答案都有的正确事实；
> 
> FP：回答里有、但参考答案不支持的事实；
> 
> FN：参考答案有、但回答漏掉的事实。
> 
> 

公式：

```Plain Text
Precision = TP / (TP + FP)
Recall = TP / (TP + FN)
F1 = 2 × Precision × Recall / (Precision + Recall)参考答案：原路退款通常在三个工作日内到账，具体以支付渠道为准。
系统回答：保证三天内到账。
```

以上解释如下：

计算示例：

```Plain Text
参考答案事实：{A, B, C}
系统回答事实：{A, B, D}

A、B 正确匹配：TP = 2
D 是回答额外引入的错误：FP = 1
C 被回答遗漏：FN = 1

Precision = 2 / (2 + 1) ≈ 0.667
Recall = 2 / (2 + 1) ≈ 0.667
F1 ≈ 0.667
```

Answer Correctness（答案正确性）和Factual Correctness（事实准确性）的关系如下：

### 5\.3\.2\. 答案相关性\-Answer Relevancy

答案相关性回答的问题是“回答有没有正面回应用户的问题？有没有答非所问？”,其不负责判断事实对不对，它只看“方向对不对”。

例如用户问：“电子发票发到哪里？”，系统回答了一大段退货政策。内容可能都是真实的，但没有回答发票问题，所以 Answer Relevancy 很低。

统计答案相关性可以使用如下做法，或者直接由大模型根据回答和标准回答进行评估：

1. 根据系统回答，反向生成若干“这段回答可能在回答什么问题”；

2. 把这些生成的问题和用户原始问题做 Embedding 相似度比较；

3. 计算平均相似度。

特别提示：Ragas 官方实现使用反向生成问题 \+ Embedding 相似度计算 Answer Relevancy。

### 5\.3\.3\. 答案忠实性与引用质量

忠实性（Faithfulness）：回答中的每个事实，能否从本次检索到的上下文中推出。

引用正确性：回答中的某个声明，是否真的被它标注的来源支持。把“物流规则\.md”标在退款时间后面，就是引用正确性错误。

引用完整性：回答中所有需要证据的关键声明，是否都提供了可以回溯的引用。回答包含“七日内退货”和“通常三个工作日到账”两个事实，却只引用其中一份文档，就是完整性不足。

以上三点可以由大模型进行推理得到，一般可以同时使用以上三种指标。

### 5\.3\.4\. LLM\-as\-judge

答案层的很多指标无法用字符串匹配直接计算，例如 Faithfulness（忠实性）、Answer Relevancy（答案相关性） 和 Factual Correctness（事实准确性）。常见做法是使用 LLM\-as\-judge，让一个能力足够强的模型按照明确标准给候选回答评分。

基本流程是：

1. 准备用户问题、参考答案、本次检索上下文和候选回答；

2. 把评分维度、取值范围和判断规则写进评估提示词；

3. 使用结构化输出约束返回格式；

4. 保存每个维度的分数和判断理由；

5. 抽样人工复核，校准模型裁判的偏差。

LLM\-as\-judge 不是绝对真值，它可能受到以下影响：

- 位置偏差：总是偏好第一个候选答案；

- 长度偏差：偏好更长、更详细的答案；

- 自偏好：偏好与自己风格相似的答案；

- 不可复现：同一批数据重复运行时分数可能波动；

- 评分标准漂移：提示词不明确时，不同批次的评分口径不一致。

所以它适合做批量筛查和回归对比，不适合在没有人工抽检的情况下直接作为高风险场景的唯一判据。

### 5\.3\.5\. 答案层评估指标总结

答案层指标看起来很多，但主要就是三类，可以使用如下图来表示：

![AbUOmPNw\.jpg](图片和附件/AbUOmPNw.jpg)

各个指标含义和示例如下表所示：

### 5\.3\.6\. 答案层评估案例

下面的案例使用 DeepSeek 作为裁判，对三条候选回答分别评估 Faithfulness、Answer Relevancy、Factual Correctness、引用正确性和引用完整性。

```Plain Text
# 使用deepseek做答案层LLM-as-judge评估# 结构化输出只保证格式稳定，不保证判断一定正确；高风险场景仍需人工复核。from pydantic import BaseModel, Field
from init_llm import deepseek_llm_flash


class JudgeResult(BaseModel):"""LLM裁判对一条RAG回答的结构化评分。"""# Faithfulness - 忠实性
    faithfulness: float = Field(ge=0.0, le=1.0, description="回答中的事实声明能被检索上下文支持的比例")
    # Answer Relevancy - 答案相关性
    answer_relevancy: float = Field(ge=0.0, le=1.0, description="回答是否切题并完整回应问题")
    # Factual Correctness - 事实准确性
    factual_correctness: float = Field(ge=0.0, le=1.0, description="回答与参考答案的事实一致性")
    # 引用正确性
    citation_correctness: float = Field(ge=0.0, le=1.0, description="引用是否真的支撑对应声明；无引用时为0")
    # 引用完整性
    citation_completeness: float = Field(ge=0.0, le=1.0, description="关键声明是否都有引用；无引用时为0")
    verdict: str = Field(description="一句话结论")
    reasoning: str = Field(description="按事实声明逐条说明评分依据")


judge = deepseek_llm_flash.with_structured_output(JudgeResult)


def evaluate_answer(
    question: str,
    reference_answer: str,
    contexts: list[str],
    candidate_answer: str,
) -> JudgeResult:"""让真实DeepSeek按固定维度评估一条候选回答。"""
    context_text = "\n\n".join(contexts)
    prompt = f"""你是严格的RAG答案质量评估员。请按以下标准评分，取值范围0到1。

            【用户问题】
            {question}
  
            【参考答案】
            {reference_answer}
  
            【本次检索上下文】
            {context_text}
  
            【候选回答】
            {candidate_answer}
  
            评分规则：
            1. faithfulness（忠实性）：把回答拆成事实声明，逐条判断能否由检索上下文推出，输出支持比例。
            2. answer_relevancy（答案相关性）：是否正面回答用户问题；答非所问或遗漏关键问题时降低。
            3. factual_correctness（事实准确性）：与参考答案的事实是否一致；丢失“通常”“以支付渠道为准”等条件要降低。
            4. citation_correctness（引用正确性）：回答中每个引用是否真的支撑它旁边的声明；没有引用时输出0。
            5. citation_completeness（引用完整性）：需要证据的关键声明是否都带引用；没有引用时输出0。
            6. verdict和reasoning用中文，reasoning要指出支持与不支持的具体声明。"""return judge.invoke(prompt)


if __name__ == "__main__":
    question = "退货条件是什么，退款多久能到账？"# 参考答案
    reference_answer = (
        "收货后七日内可以申请退货，商品、包装和配件需要保持完整；""仓库验收通过后发起原路退款，通常三个工作日内到账，具体以支付渠道为准。"
    )
    # 检索上下文
    contexts = [
        "售后规则：收货后七日内可以申请退货，商品、包装和配件需要保持完整；仓库验收后平台会发起退款。[售后规则.md]",
        "退款规则：原路退款通常在三个工作日内到账，具体以支付渠道为准。[退款规则.md]",
    ]
    # 候选回答
    candidates = {
        "答案A（完整且带引用）": (
            "收货后七日内可以申请退货，商品、包装和配件需要保持完整；""仓库验收通过后发起原路退款，通常三个工作日内到账，具体以支付渠道为准。""[售后规则.md][退款规则.md]"
        ),
        "答案B（有幻觉且引用错误）": (
            "平台保证三个工作日内到账，退货后运费由平台承担。[退款规则.md]"
        ),
        "答案C（答非所问）": (
            "收货后七日内可以申请退货，但需要保持商品完整。[售后规则.md]"
        ),
    }

    print("用户问题：", question)
    print("评估维度：Faithfulness、Answer Relevancy、Factual Correctness、引用正确性、引用完整性")
    print("=" * 72)
    for name, candidate in candidates.items():
        result = evaluate_answer(question, reference_answer, contexts, candidate)
        print(f"\n{name}")
        print(f"候选回答：{candidate}")
        print(f"Faithfulness（忠实性）={result.faithfulness:.2f}")
        print(f"Answer Relevancy（答案相关性）={result.answer_relevancy:.2f}")
        print(f"Factual Correctness（事实准确性）={result.factual_correctness:.2f}")
        print(f"Citation Correctness（引用正确性）={result.citation_correctness:.2f}")
        print(f"Citation Completeness（引用完整性）={result.citation_completeness:.2f}")
        print(f"结论：{result.verdict}")
        print(f"理由：{result.reasoning}")
```

以上代码运行结果如下：

![JFV9scOz\.jpg](图片和附件/JFV9scOz.jpg)

特别注意：如果对于多条样本进行评估，可以取各个指标的平均值作为最终的答案层评估结果。

## 5\.4\. Agent、工作流和系统指标

### 5\.4\.1\. 工具调用指标

当 RAG 以 Agent 或工作流形式运行时，系统可能需要在“检索知识库”“查询订单”“计算退款金额”“转人工”等工具之间选择。工具选择的评估不能只看最终文本，还要记录：

- 是否选中了允许使用的工具；

- 工具名称是否正确；

- 参数是否完整、类型正确、范围合法；

- 是否先执行必要的前置步骤，例如先鉴权再查询；

- 是否调用了不必要或不允许的工具。

如果业务流程有唯一正确工具序列，可以使用严格的调用准确率；如果多个工具可以并行或存在多条等价路径，应使用允许乱序的集合匹配，或者改为评价目标是否完成，不能把一条“可接受但不同”的路径简单判成错误。

设期望工具集合为E，实际调用工具集合为A：

```Plain Text
TP = |E ∩ A|  # 两个集合的交集，正确调用的工具数
FP = |A - E|  # 实际调用了但不在期望集合中的工具数
FN = |E - A|  # 期望调用了但实际没调用的工具数


Precision_tool = TP / (TP + FP)
Recall_tool = TP / (TP + FN)
Tool Call F1 = 2 × Precision_tool × Recall_tool / (Precision_tool + Recall_tool)
```

以上参数解释如下：

计算示例：期望调用工具\{检索工具, 订单工具\}，实际只调用了\{检索工具, 天气工具\}。

```Plain Text
TP = 1（检索工具）
FP = 1（天气工具）
FN = 1（订单工具）
Precision_tool = 1/2 = 0.5Recall_tool = 1/2 = 0.5Tool Call F1 = 0.5
```

工具调用评估案例：

```Plain Text
# 使用Agent评估工具选择# 工具选择评估读取真实AIMessage.tool_callsfrom langchain.agents import create_agent
from langchain_core.messages import AIMessage
from langchain_core.tools import tool
from init_llm import deepseek_llm_flash


@tooldef search_after_sale_rules(query: str) -> str:"""检索退款、退货和到账规则。"""return (
        "退款规则：仓库验收通过后发起原路退款，通常三个工作日内到账，具体以支付渠道为准。""退货规则：收货后七日内可以申请退货，商品、包装和配件需要保持完整。"
    )


@tooldef query_order_status(order_id: str) -> str:"""查询指定订单的物流和退款状态。"""return f"订单{order_id}状态：已签收；退款状态：仓库验收通过，已发起原路退款。"def actual_tool_names(result: dict) -> list[str]:"""从Agent消息轨迹中按首次出现顺序提取真实工具名。"""
    call_tool_names: list[str] = []
    for message in result["messages"]:
        if isinstance(message, AIMessage):
            for call in message.tool_calls or []:
                name = call["name"]
                if name not in call_tool_names:
                    call_tool_names.append(name)
    return call_tool_names


def set_metrics(expected: set[str], actual: list[str]) -> tuple[float, float, float]:"""计算工具调用精确率、Tool Call F1和必需工具召回率。"""
    actual_set = set(actual)
    tp = len(expected & actual_set)
    fp = len(actual_set - expected)
    fn = len(expected - actual_set)
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0return precision, f1, recall


if __name__ == "__main__":
    agent = create_agent(
        model=deepseek_llm_flash,
        tools=[search_after_sale_rules, query_order_status],
        system_prompt=(
            "你是电商售后Agent。涉及退款、退货、到账规则时调用search_after_sale_rules；""涉及具体订单的物流或退款状态时调用query_order_status。""可以同时调用多个工具。最终回答必须依据工具结果。"
        ),
    )

    cases = [
        ("退款多久到账？", {"search_after_sale_rules"}),
        ("订单ORD-1001现在到哪了？", {"query_order_status"}),
        (
            "订单ORD-1001的退款什么时候到账？",
            {"query_order_status", "search_after_sale_rules"},
        ),
    ]

    print("评估方式：真实Agent运行后读取AIMessage.tool_calls")
    print("=" * 72)

    total_precision = 0.0  # 工具调用精确率
    total_f1 = 0.0         # Tool Call F1
    total_recall = 0.0     # 必需工具召回率for question, expected_call_tools in cases:
        result = agent.invoke({"messages": [{"role": "user", "content": question}]})
        actual_call_tools = actual_tool_names(result)
        precision, f1, recall = set_metrics(expected_call_tools, actual_call_tools)
        total_precision += precision
        total_f1 += f1
        total_recall += recall

        print(f"\n问题：{question}")
        print(f"期望工具：{sorted(expected_call_tools)}")
        print(f"真实工具：{actual_call_tools}")
        print(f"工具调用精确率：{precision:.2f}")
        print(f"Tool Call F1：{f1:.2f}")
        print(f"必需工具召回率：{recall:.2f}")
        print("最终回答：", result["messages"][-1].content.replace("\n", " "))

    count = len(cases)
    print("\n" + "=" * 72)
    print(
        f"汇总：工具调用精确率={total_precision / count:.2f}，"f"Tool Call F1={total_f1 / count:.2f}，"f"必需工具召回率={total_recall / count:.2f}"
    )
```

以上代码运行结果如下：

![rIkT1fRX\.jpg](图片和附件/rIkT1fRX.jpg)

### 5\.4\.2\. Agent Goal Accuracy\-目标完成率

有些 Agent 任务存在多条可接受路径，硬性比较工具序列反而不合理。这时更适合评估目标是否完成：

```Plain Text
Agent Goal Accuracy = 目标成功完成的样本数 / 参与评估的样本总数
```

计算示例：三条任务分别是“查到退款规则”“查到订单状态”“同时查到订单状态和退款规则”。如果前两条成功，第三条只查到了订单状态但没有查到规则，则：

```Plain Text
Agent Goal Accuracy = 2 / 3 ≈ 0.667
```

目标是否完成可以由业务规则判断，也可以由 LLM\-as\-judge 判断。涉及订单、退款、付款等高风险业务时，应优先使用业务系统返回的真实结果，不能只靠模型自评。

### 5\.4\.3\. 延迟、成本和错误率

RAG 的质量达标后，还要判断它是否满足服务级目标。常用指标包括：

- 延迟：记录端到端耗时以及检索、重排、模型、工具各阶段耗时，至少观察 p50 和 p95；高峰期还应观察 p99。

- 错误率：失败请求数 / 总请求数。超时、模型 API 错误、工具错误、格式解析失败和权限拒绝要分开统计。

- 成本：按请求记录 Embedding 次数、输入输出 Token、工具调用费用和重试次数，观察平均成本与高分位成本。

- 吞吐与并发：观察高并发时是否出现队列堆积、限流、连接池耗尽或上下文截断。

- 格式合规率：结构化输出能否被解析，必需字段是否齐全，引用 ID 是否存在。

### 5\.4\.4\. 拒答、权限和安全

无答案、越权和提示注入不能只作为普通质量分数的一部分，而应设置独立门禁：

- 拒答准确率：应该拒答的样本中，系统正确拒答的比例。

- 误回答率：应该拒答的样本中，系统返回事实性答案或编造答案的比例。

- 权限泄露率：未授权测试请求中，系统返回了受保护文档、字段或工具结果的比例。

- 敏感信息泄露率：答案、日志、追踪数据和错误信息中出现敏感字段的比例。

- 数据新鲜度：答案使用的文档版本是否达到业务规定的有效期；过期规则即使内容正确，也可能是生产错误。

## 5\.5\. 离线评估流程

### 5\.5\.1\. 离线评估解决的问题

离线评估的输入是固定数据集和当前版本的应用，输出是每条样本的实际结果、各项指标和错误记录。它主要解决四个问题：

1. Benchmarking：比较不同 Embedding、切分方式、检索器、Prompt 或模型。

2. Regression testing：确认新版本没有让已有能力退化。

3. Unit testing：单独验证检索器、格式化器、路由节点或工具参数。

4. Backtesting：把历史真实问题重新跑一遍，检查新版本对过去流量的影响。

它的价值在于可重复，只要评估集、知识库版本、模型版本、参数和指标口径保持记录，就能比较两个实验，而不是凭印象看几条回答。

### 5\.5\.2\. 离线评估流程图

![DWuf81r1\.jpg](图片和附件/DWuf81r1.jpg)

### 5\.5\.3\. 离线评估工具选型

本章主线使用本地 Python 实现，因为这样可以逐项看清楚公式和数据流，对于以上离线评估流程图，不依赖具体平台，可以按以下步骤组织一个离线评估脚本：

1. 确定目标：这次是优化召回、降低幻觉、提高拒答，还是降低延迟和成本。

2. 准备样本：为可回答问题维护参考答案和参考上下文，为无答案问题维护 answerable=false 和拒答标准。

3. 固定版本：记录知识库快照、切分参数、Embedding 模型、Retriever 参数、Prompt、Chat Model 和代码版本。

4. 执行应用：逐条运行 RAG，保存改写查询、召回顺序、最终上下文、回答、引用和轨迹。

5. 计算确定性指标：先计算 Hit@K、Precision@K、Recall@K、MRR、NDCG、格式正确率、工具参数校验和延迟。

6. 计算语义指标：再按预算选择人工审核、LLM\-as\-judge 或 Ragas 等可选评估器，计算事实正确性、相关性和忠实性。

7. 按切片分析：分别看不同版本、不同租户和高风险问题，不要只看总平均。

8. 设置门禁：安全、权限泄露和格式错误通常是硬门禁；质量指标可以设置最低值或相对基线的退化阈值。

9. 保存结果：把配置、原始输出、指标、异常样本和人工结论存档，便于后续回归。

### 5\.5\.4\. 离线评估建议

刚开始做 RAG 评估时，建议按下面的顺序推进：

1. 先建立检索层基线：Hit@K、Recall@K。如果正确资料没有被召回，先调答案生成通常是浪费时间。

2. 再看答案忠实性：Faithfulness。它回答“模型是不是在用本次检索到的资料回答”。

3. 再看答案正确性：Factual Correctness 或业务版 Answer Correctness。它回答“答案与业务认可的事实是否一致”。

4. 再看引用质量：引用正确性和引用完整性，确保答案可以回溯到真实来源。

5. 再看 Agent 与工作流指标：工具选择、轨迹约束、目标完成率和重试次数。

6. 最后看系统指标与安全门禁：延迟、成本、错误率、拒答准确率、权限泄露率和敏感信息泄露率。

安全、权限和格式门禁可以并行设置，不必等到最后。它们不是“质量分数”，而是上线资格。

此外，评估集本身也会变化。新增一个容易通过的样本，可能让总分上涨，但并不代表系统真的变好。因此需要区分：

- 固定回归集：用于比较版本，尽量保持稳定。

- 探索集：用于快速加入新问题和新故障，验证后再合并到回归集。

- 高风险集：权限、拒答、版本冲突和敏感数据，单独作为上线门禁。

一次实验尽量只调整一个主要变量。例如先只改变 k，再只改变 chunk 策略；不要同时替换 Embedding、Retriever、Prompt 和 Chat Model，否则即使分数变化，也无法判断收益来自哪里。

## 5\.6\. 在线评估流程

### 5\.6\.1\. 在线评估解决的问题

在线评估针对真实运行记录，重点观察离线数据集没有覆盖的情况：用户真实说法、知识库实时变化、流量高峰、工具异常、权限边界、缓存污染、模型偶发输出和多轮对话。

在线评估的目标不是给每个实时请求都生成一个昂贵的“标准答案”，而是持续发现质量下降和风险信号。它应当尽量不阻塞用户请求：轻量规则实时执行，昂贵的语义评估采用采样、异步队列（把评估任务丢到后台队列，用户请求先返回）或延迟审核（不是实时评估，而是事后定期审核）。

### 5\.6\.2\. 最小Trace结构

在线评估中，每个请求至少要有一个trace\_id，并保存以下信息：

```Plain Text
trace_id                          # 本次请求的唯一追踪标识
request_time                      # 请求发生的时间戳
user_input                        # 用户输入的原始问题
conversation_id                   # 对话会话ID，用于关联同一会话的多轮请求
application_version               # 当前RAG应用的版本号
knowledge_base_version            # 本次使用的知识库版本
embedding_version                 # 使用的Embedding模型版本
model_version                     # 使用的生成模型版本
retrieved_documents               # 检索到的文档列表，每个文档包含 document_id、chunk_id、source、rank、score、version
final_context                     # 最终拼接后送入模型的完整上下文
answer                            # 模型生成的最终回答
citations                         # 回答中引用的来源列表
tool_calls / workflow_steps       # Agent调用的工具记录或工作流执行步骤
latency_by_stage                  # 各阶段耗时，如检索、重排、生成、工具调用等
input_tokens / output_tokens / estimated_cost  # 输入Token数、输出Token数及估算成本
error_type                        # 如果出错，记录错误类型（如超时、工具错误、格式解析失败等）
answerable_prediction             # 系统预测该问题是否可由知识库回答
user_feedback                     # 用户反馈，如点赞、点踩、追问、转人工等
```

这些字段解决三个问题：Trace 用于事后回放和定位；版本字段用于确认知识库和模型是否发生变化；user\_feedback 和 answerable\_prediction 用于把线上样本回流为离线评估样本。

此外，日志必须脱敏，不要因为“为了评估”就把完整身份证号、订单隐私、企业机密和受保护文档直接写入公共日志。生产追踪可以保存哈希 ID、版本、类别和必要的摘要；需要人工复核时再通过受控权限回查原文。

### 5\.6\.3\. 在线评估流程图

![qx1f9G7t\.jpg](图片和附件/qx1f9G7t.jpg)

### 5\.6\.4\. 在线评估建议

对于在线无参考样本，可以先做以下检查：

1. 格式检查：答案是否为空，JSON 是否可解析，必需字段是否存在。

2. 引用检查：引用 ID 是否真实存在，引用版本是否与实际上下文一致。

3. 忠实性代理：把回答拆成声明，检查声明是否能从本次检索上下文中找到依据。

4. 相关性代理：检查回答是否回应用户问题，必要时使用抽样的 LLM 评估或人工审核。

5. 安全检查：提示注入、敏感信息、越权字段、违规工具调用。

6. 系统指标：延迟、错误率、重试次数、成本、上下文长度和超时。

7. 数据质量：检索结果是否来自有效版本，答案是否使用过期资料，是否出现大量空召回。

8. 用户行为：点赞、点踩、重复追问、转人工、会话中断和后续业务是否成功。

这些指标能够发现异常和退化，但没有参考答案时，不能直接证明“回答事实正确”。用户点了赞也不等于答案经过事实核验，只能作为一种反馈信号。

这些检查的共同特点是：不需要事先准备参考答案。它们能发现异常和退化，但不能替代离线评估中基于参考答案的事实正确性判断。

### 5\.6\.5\. 生产反馈闭环

在线评估发现的问题可以回流到离线数据集进行补充离线评估集，从而进行离线评估验证修复，完整闭环如下：

![QqsbJ7dt\.jpg](图片和附件/QqsbJ7dt.jpg)

在线样本回流后，不能全部直接加入固定回归集。应先去重、合并同类问题、确认标签和权限，再按来源和风险分层：

- 反复出现的问题进入固定回归集。

- 只用于某版本或某租户的问题保留 metadata，不污染其他切片。

- 尚未确认的样本放入探索集，避免不可靠标签变成错误标准。

- 已废弃的业务规则保留历史版本测试，但不能和当前版本门禁混在一起。

## 5\.7\. Ragas RAG指标评估框架

### 5\.7\.1\. Ragas是什么

Ragas 是一个开源的 RAG 评估框架。它不负责加载文档、不负责检索、也不负责生成回答，它专门负责一件事：“给 RAG 系统算标准评估指标。”

Ragas 提供了很多 RAG 常用指标，例如：

- Faithfulness：回答是否忠实于检索上下文；

- Answer Relevancy：回答是否切题；

- Context Precision：相关内容是否排在上下文前面；

- Context Recall：参考答案需要的信息是否都在上下文里；

- Factual Correctness：回答与参考答案的事实重合程度。

原生 Python 实现指标的好处是透明，能看到每一步怎么算；Ragas 的好处是标准指标已经实现好，适合快速验证、学术实验和与外部结果对比。

使用Ragas时，必须在对应的python环境中先安装Ragas：

```Plain Text
pip install ragas == 0.4.3
```

Ragas 官方文档：https://docs\.ragas\.io/en/stable/

### 5\.7\.2\. Ragas 常用指标

Ragas 指标不是简单的字符串匹配，大多数需要使用 LLM 或 Embedding。因此它们依赖模型质量、提示词和运行环境，分数可能波动。

### 5\.7\.3\. Ragas使用案例

如下案例使用Ragas进行五种指标的评估，代码如下：

```Plain Text
import asyncioimport sysimport types

# ------------------------------------------------------------
# ragas 0.4.3 会导入 langchain-community 0.4.2 已移除的 vertexai 模块
# 该模块在 langchain-community 0.4.2 中已被移除；ChatVertexAI 只参与 ragas 内部的多完成类型列表，用空类占位即可绕过导入错误。
# 必须放在导入 ragas 0.4.3 之前，否则会报错
# ------------------------------------------------------------if "langchain_community.chat_models.vertexai" not in sys.modules:
    # 创建一个空的模块对象
    _vertexai_stub = types.ModuleType("langchain_community.chat_models.vertexai")
    # 定义一个空的类，用于占位 ChatVertexAI_vertexai_stub.ChatVertexAI = type("ChatVertexAIStub", (), {})
    # 将空模块对象添加到 sys.modules 中，模拟 langchain-community.chat_models.vertexai 模块
    sys.modules["langchain_community.chat_models.vertexai"] = _vertexai_stubfrom env_utils import DASHSCOPE_BASE_URL, DASHSCOPE_API_KEY, DEEPSEEK_API_KEY, DEEPSEEK_BASE_URLfrom openai import AsyncOpenAIfrom ragas.embeddings.base import embedding_factoryfrom ragas.llms import llm_factoryfrom ragas.metrics.collections import AnswerRelevancy, ContextPrecision, ContextRecall, FactualCorrectness, Faithfulnessdef build_ragas_components():
    """构建 Ragas 现代 LLM 与 Embedding 组件。"""
    # DeepSeek 提供 OpenAI 兼容接口
    deepseek_client = AsyncOpenAI(
        api_key=DEEPSEEK_API_KEY,
        base_url=DEEPSEEK_BASE_URL,
    )

    # max_tokens=4096：结构化输出默认 1024 容易被截断
    # extra_body 关闭 DeepSeek 思考模式，避免思考内容占用输出长度
    ragas_llm = llm_factory(
        "deepseek-v4-flash",
        client=deepseek_client,
        max_tokens=4096,
        extra_body={"thinking": {"type": "disabled"}},
    )

    # DashScope 同样提供 OpenAI 兼容接口
    dashscope_client = AsyncOpenAI(
        api_key=DASHSCOPE_API_KEY,
        base_url=DASHSCOPE_BASE_URL,
    )

    ragas_embeddings = embedding_factory(
        "openai",
        model="text-embedding-v1",
        client=dashscope_client,
    )

    return ragas_llm, ragas_embeddingsasync def main():
    llm, embeddings = build_ragas_components()

    # 五个常用指标
    # Faithfulness：忠实性，回答中的每个事实能否从本次检索到的上下文中推出
    faithfulness = Faithfulness(llm=llm)
    # AnswerRelevancy：答案相关性，回答是否正面回应用户问题，有没有答非所问
    answer_relevancy = AnswerRelevancy(llm=llm, embeddings=embeddings)
    # ContextPrecision：上下文精度，进入上下文的资料里，是否干净且靠前
    context_precision = ContextPrecision(llm=llm)
    # ContextRecall：上下文召回率，进入上下文的资料里，是否包含所有相关信息
    context_recall = ContextRecall(llm=llm)
    # FactualCorrectness：事实准确性，评估模型生成的响应是否与用户查询相关
    factual_correctness = FactualCorrectness(llm=llm)


    question = "退货条件是什么，退款多久能到账？"retrieved_contexts = [
        "售后规则：收货后七日内可以申请退货，商品、包装和配件需要保持完整；仓库验收后平台会发起退款。",
        "退款规则：原路退款通常在三个工作日内到账，具体以支付渠道为准。",
    ]
    response = "收货后七日内可以申请退货，商品、包装和配件需要保持完整；仓库验收通过后发起原路退款，通常三个工作日内到账，具体以支付渠道为准。"reference = "收货后七日内可以申请退货，商品、包装和配件需要保持完整；仓库验收通过后发起原路退款，通常三个工作日内到账，具体以支付渠道为准。"print("开始评估，请耐心等待（每个指标都是多次 LLM 调用）", flush=True)

    # Faithfulness：忠实性，回答中的每个事实能否从本次检索到的上下文中推出
    f = await faithfulness.ascore(
        user_input=question,
        response=response,
        retrieved_contexts=retrieved_contexts
    )
    print("Faithfulness 完成", flush=True)

    # AnswerRelevancy：答案相关性，回答是否正面回应用户问题，有没有答非所问
    ar = await answer_relevancy.ascore(
        user_input=question,
        response=response
    )
    print("AnswerRelevancy 完成", flush=True)

    # ContextPrecision：上下文精度，进入上下文的资料里，是否干净且靠前
    cp = await context_precision.ascore(
        user_input=question,
        reference=reference,
        retrieved_contexts=retrieved_contexts
    )
    print("ContextPrecision 完成", flush=True)

    # ContextRecall：上下文召回率，进入上下文的资料里，是否包含所有相关信息
    cr = await context_recall.ascore(
        user_input=question,
        retrieved_contexts=retrieved_contexts,
        reference=reference
    )
    print("ContextRecall 完成", flush=True)

    # FactualCorrectness：事实准确性，评估模型生成的响应是否与用户查询相关
    fc = await factual_correctness.ascore(
        response=response,
        reference=reference
    )
    print("FactualCorrectness 完成", flush=True)

    print("=" * 60)
    print(f"Faithfulness（忠实性）:           {f.value:.4f}")
    print(f"Answer Relevancy（答案相关性）:       {ar.value:.4f}")
    print(f"Context Precision（上下文精度）:      {cp.value:.4f}")
    print(f"Context Recall（上下文召回率）:         {cr.value:.4f}")
    print(f"Factual Correctness（事实准确性）:    {fc.value:.4f}")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
```

代码运行后结果如下：

![Ge5Z5551\.jpg](图片和附件/Ge5Z5551.jpg)

以上代码注意如下几点：

1. Ragas 0\.4\.3 内部会导入 langchain\_community\.chat\_models\.vertexai，但该模块在 langchain\-community 0\.4\.2 中已被移除。必须提前手动注册一个假的空模块，否则会在 import ragas 时直接报 ModuleNotFoundError。shim 一旦放在 ragas 导入之后，就来不及生效。

2. AnswerRelevancy 额外需要 Embedding，其他四个指标只用 LLM，AnswerRelevancy 同时需要 LLM 和 Embedding，因为它用反向生成问题 \+ 向量相似度计算。

3. 代码中用五个 await 依次执行。每个指标内部会多次调用 LLM，所以总耗时是五个指标之和。Faithfulness、ContextRecall、FactualCorrectness 都需要把文本拆成声明并逐条判断，一个指标可能调用多次 LLM，耗时和成本不可忽略。

4. Ragas 底层用 LLM\-as\-judge，受位置偏差、长度偏差、自偏好、不可复现等影响。分数适合做批量筛查和回归对比，不适合作为高风险场景的唯一判据。

5. 单条样本的分数只能说明这一次评估的结果，不能代表系统整体质量。生产环境需要多条覆盖不同问题类型的样本，可以对每个指标分别计算平均值。





